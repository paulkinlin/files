$TargetFile = "C:\_DEV\intelliJ\bin\idea64.exe"
$ShortcutFile = "C:\Users\Public\Desktop\intelliJ.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.Save()

$TargetFile = "C:\_DEV\eclipse\eclipse.exe"
$ShortcutFile = "C:\Users\Public\Desktop\eclipse.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.Save()

$TargetFile = "C:\Program Files\Postman\Postman.exe"
$ShortcutFile = "C:\Users\Public\Desktop\Postman.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.Save()

$TargetFile = "C:\_DEV\sqldeveloper\sqldeveloper.exe"
$ShortcutFile = "C:\Users\Public\Desktop\sqlDeveloper.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.Save()