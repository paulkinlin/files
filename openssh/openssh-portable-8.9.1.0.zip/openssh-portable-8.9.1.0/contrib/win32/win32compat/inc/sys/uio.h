#pragma once

struct iovec
{
	void *iov_base;
	size_t iov_len;
};
