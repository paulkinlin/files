#ifndef COMPAT_IN_H
#define COMPAT_IN_H 1

/* Compatibility header to avoid lots of #ifdef _WIN32's in includes.h */

#endif
