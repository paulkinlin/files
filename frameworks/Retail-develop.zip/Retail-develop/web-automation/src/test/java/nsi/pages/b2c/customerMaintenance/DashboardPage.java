package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

import static nsi.utils.CustomCommands.waitUntilVisible;

@Getter
public class DashboardPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[contains(@class, 'account-tile')]")
    private ElementsCollection productTileWidget;

    @FindBy(xpath = "//*[@id='hero-main-content']/div/h1")
    private SelenideElement productNameHeader;

    @FindBy(xpath = "//div[contains(@class, 'theme-nsi-skyblue')]")
    private SelenideElement disaAccountTitleText;

    @FindBy(xpath = "//div[contains(@class, 'theme-nsi-orange')]")
    private SelenideElement ibAccountTitleText;

    @FindBy(xpath = "//div[contains(@class, 'theme-nsi-duckegg')]")
    private SelenideElement dsAccountTitleText;

    @FindBy(xpath = "//div[contains(@class, 'theme-nsi-yellow')]")
    private SelenideElement pbAccountTitleText;

    @FindBy(xpath = "//strong[@class='value customer-name']")
    private SelenideElement titleAndSurnameText;

    @FindBy(xpath = "(//strong[@class='value'])[1]")
    private SelenideElement amountInvestedText;

    @FindBy(xpath = "(//strong[@class='value'])[2]")
    private SelenideElement amountFirstProductText;

    @FindBy(xpath = "(//strong[@class='value'])[3]")
    private SelenideElement amountSecondProductText;

    @FindBy(xpath = "(//strong[@class='value'])[2]/..")
    private SelenideElement balanceWordingFirstProductText;

    @FindBy(xpath = "//div[contains(@id,'birthCity')]/div")
    private SelenideElement birthCityText;

    @FindBy(xpath = "//div[contains(@id,'birthCountry')]/div")
    private SelenideElement birthCountryText;

    @FindBy(xpath = "//label[text()='Tax country']/following-sibling::div")
    private SelenideElement taxCountryText;

    @FindBy(xpath = "//label[contains(text(), 'Tax identification number')]//following-sibling::div")
    private SelenideElement taxIdentificationNumberText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//input[@class='btn Logout']")
    private SelenideElement logOutButton;

    @FindBy(xpath = "//a[@class='btn btn--small']")
    private SelenideElement cookieConsentButton;

    // LINKS
    @FindBy(xpath = "//a[contains(.,'Log out')]")
    private SelenideElement logOutLink;

    @FindBy(xpath = "//a[contains(.,'Your details')]")
    private SelenideElement yourDetailsLink;

    @FindBy(xpath = "//a[contains(.,'Your profile')]")
    private SelenideElement yourProfileLink;

    @FindBy(xpath = "//a[contains(.,'Paperless options')]")
    private SelenideElement paperlessOptionsLink;

    @FindBy(xpath = "//a[contains(.,'Your dashboard')]")
    private SelenideElement yourDashboardLink;

    @FindBy(xpath = "//a[contains(.,'Your accounts')]")
    private SelenideElement yourAccountsLink;

    @FindBy(xpath = "//a[contains(@aria-label,'Pay money in')]")
    private ElementsCollection payMoneyInLinks;

    @FindBy(xpath = "//a[contains(@aria-label,'Make a transfer')]")
    private ElementsCollection makeATransferLinks;

    @FindBy(xpath = "//a[contains(@aria-label,'Take money out')]")
    private ElementsCollection takeMoneyOutLinks;

    @FindBy(xpath = "//a[contains(@aria-label,'Open a new account')]")
    private ElementsCollection openNewAccountLinks;

    @FindBy(xpath = "//a[contains(@aria-label,'Buy more Bonds')]")
    private ElementsCollection buyMoreBondsLinks;

    @FindBy(xpath = "//a[contains(@aria-label,'Cash in')]")
    private ElementsCollection cashInLinks;

    @FindBy(xpath = "//a[contains(@aria-label,'View account')]")
    private ElementsCollection viewAccountLinks;

    @FindBy(xpath = "//*[contains(@class,'logo')]")
    private SelenideElement logoNSILinks;

    @FindBy(xpath = "//*[contains(@class,'logo active')]")
    private SelenideElement logoNSIactive;

    // ----------------------------------------------------

    public void clickPayMoneyInLinkFor(Condition condition) {
        payMoneyInLinks.filter(condition).first().execute(waitUntilVisible).click();
    }

    public void clickMakeATransferLinkFor(Condition condition) {
        makeATransferLinks.filter(condition).first().execute(waitUntilVisible).click();
    }
}