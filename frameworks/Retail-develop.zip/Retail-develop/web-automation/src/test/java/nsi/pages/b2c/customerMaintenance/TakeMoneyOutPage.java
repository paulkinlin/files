package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class TakeMoneyOutPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    @FindBy(className = "error")
    private SelenideElement errorText;

    @FindBy(id = "availableAmount")
    private SelenideElement availableAmountText;

    @FindBy(id = "currentBalance")
    private SelenideElement currentBalanceText;

    // FIELDS
    @FindBy(id = "movementAmount")
    private SelenideElement amountField;

    // DROPDOWNS
    @FindBy(id = "optionMenuForWithdrawals")
    private SelenideElement payToSelect;

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}