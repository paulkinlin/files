package nsi.utils;


import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import nsi.pojos.ClientDataPojo;
import nsi.pojos.Context;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.junit.Assert;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

@Slf4j
public class JsonUtils {
    private static final String PATH_TO_DIRECTORY = ".\\target\\json\\";

    public static void writeContextToJsonfile(Context context) throws IOException {
        File file = new File(PATH_TO_DIRECTORY + (context.getScenarioName().substring(0, StringUtils.ordinalIndexOf(context.getScenarioName(), "-", 2)).replace(".", "") + ".json"));
        if (file.exists()) {
            updateJsonFile(context);
        } else
            createJsonFile(context);
        log.info("JSON data saved: {}", context);
    }

    public static void addDataToExistingJson(Context context) {
        Path filePath = Paths.get(PATH_TO_DIRECTORY + context.getScenarioName() + ".json");
        Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
        List<Context> contextList;

        try (final BufferedWriter out = Files.newBufferedWriter(
                filePath,
                StandardCharsets.UTF_8,
                StandardOpenOption.APPEND
        )) {
            contextList = gson
                    .fromJson(PATH_TO_DIRECTORY + context.getScenarioName() + ".json", new TypeToken<List<Context>>() {
                    }.getType());
            contextList.add(context);

            gson.toJson(context, out);

        } catch (Exception e) {
            log.error(e.toString());
        }
    }

    private static void createJsonFile(Context context) throws IOException {
        Path filePath = Paths.get(PATH_TO_DIRECTORY + (context.getScenarioName().substring(0, StringUtils.ordinalIndexOf(context.getScenarioName(), "-", 2)).replace(".", "") + ".json"));
        Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

        Files.createDirectories(filePath.getParent());
        try (final BufferedWriter out = Files.newBufferedWriter(
                filePath,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE
        )) {
            gson.toJson(context, out);

        } catch (Exception e) {
            log.error(e.toString());
        }
    }

    private static void updateJsonFile(Context context) throws IOException {
        Path filePath = Paths.get(PATH_TO_DIRECTORY + (context.getScenarioName().substring(0, StringUtils.ordinalIndexOf(context.getScenarioName(), "-", 2)).replace(".", "") + ".json"));
        Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
        Files.createDirectories(filePath.getParent());
        try (final BufferedWriter out = Files.newBufferedWriter(
                filePath,
                StandardCharsets.UTF_8,
                StandardOpenOption.TRUNCATE_EXISTING,
                StandardOpenOption.CREATE
        )) {
            gson.toJson(context, out);

        } catch (Exception e) {
            log.error(e.toString());
        }
    }

    public static void updateJsonFile(String fileName, String property, String value) {
        try {
            File file = new File(PATH_TO_DIRECTORY + fileName + ".json");
            String jsonString = FileUtils.readFileToString(file);
            JSONArray jsonArray = new JSONArray(jsonString);
            JSONObject jsonObject = (JSONObject) jsonArray.get(0);
            jsonObject.put(property, value);
            jsonArray.remove(0);
            jsonArray.put(jsonObject);
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(jsonArray.toString());
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean doesIdentifierExist(String identifier, String jsonFile)
            throws FileNotFoundException, ParseException {
        Object object = new JSONParser().parse(new FileReader(PATH_TO_DIRECTORY + jsonFile + ".json"));
        JSONObject jo = (JSONObject) object;
        return jo.getAsString(identifier) != null;
    }

    private static boolean doesIdentifierExistInArray(String arrayName, String identifier, String jsonFile)
            throws IOException {
        Path filePath = Paths.get(PATH_TO_DIRECTORY +
                jsonFile + ".json");
        Reader reader = Files.newBufferedReader(filePath);
        JsonElement jsonElement = new JsonParser().parse(reader);
        JsonObject jsonArray = jsonElement.getAsJsonObject().getAsJsonArray(arrayName).get(0).getAsJsonObject();
        String result = jsonArray.get(identifier).getAsString();
        reader.close();
        return result != null;
    }

    public static String getValueFromJson(String identifier, String property, String jsonFile) throws IOException {
        Path filePath = Paths.get(PATH_TO_DIRECTORY +
                jsonFile + ".json");
        Reader reader = Files.newBufferedReader(filePath);
        JsonElement jsonElement = new JsonParser().parse(reader);
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        String result = jsonObject.getAsJsonObject(identifier).get(property).getAsString();
        reader.close();
        return result;
    }

    public static String getValueFromJson(String property, String jsonFile) throws IOException {
        Path filePath = Paths.get(PATH_TO_DIRECTORY +
                jsonFile + ".json");
        Reader reader = Files.newBufferedReader(filePath);
        JsonElement jsonElement = new JsonParser().parse(reader);
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        String result = jsonObject.get(property).getAsString();
        reader.close();
        return result;
    }

    public static String getValueFromJsonArray(String arrayName, String property, String jsonFile) throws IOException {
        Path filePath = Paths.get(PATH_TO_DIRECTORY +
                jsonFile + ".json");
        Reader reader = Files.newBufferedReader(filePath);
        JsonElement jsonElement = new JsonParser().parse(reader);
        JsonObject jsonArray = jsonElement.getAsJsonObject().getAsJsonArray(arrayName).get(0).getAsJsonObject();
        String result = jsonArray.get(property).getAsString();
        reader.close();
        return result;
    }


    private static boolean doesFileExist(String jsonFile) {
        File file = new File(PATH_TO_DIRECTORY + (jsonFile + ".json"));
        return file.exists();
    }

    public static Context getDataFromFile(String jsonFile) throws IOException, ParseException {
        Context tempContext = new Context();
        if (doesFileExist(jsonFile)) {
            if (doesIdentifierExist("mainInvestorClientData", jsonFile)) {
                tempContext.setMainInvestorClientData(setClientData("mainInvestorClientData", jsonFile));
            }
            if (doesIdentifierExist("latestRegisteredClientData", jsonFile)) {
                tempContext.setLatestRegisteredClientData(setSurName(jsonFile));
            }
            tempContext.setNsiNumber(getValueFromJson("nsiNumber", jsonFile));
            if (doesIdentifierExist("totalAmount", jsonFile)) {
                tempContext.setTotalAmount(getValueFromJson("totalAmount", jsonFile));
            }
            tempContext.setScenarioName(getValueFromJson("scenarioName", jsonFile));
            if (doesIdentifierExist("operatorSecurityCode", jsonFile)) {
                tempContext.setOperatorSecurityCode(getValueFromJson("operatorSecurityCode", jsonFile));
            }
            if (doesIdentifierExist("applicationReference", jsonFile)) {
                tempContext.setApplicationReference(getValueFromJson("applicationReference", jsonFile));
            }
            if (doesIdentifierExist("accountNumber", jsonFile)) {
                tempContext.setAccountNumber(getValueFromJson("accountNumber", jsonFile));
            }
            if (doesIdentifierExist("clientNumber", jsonFile)) {
                tempContext.setClientNumber(getValueFromJson("clientNumber", jsonFile));
            }
            if (doesIdentifierExist("secondClientData", jsonFile)) {
                tempContext.setSecondClientData(setClientData("secondClientData", jsonFile));
            }
            if (doesIdentifierExist("thirdClientData", jsonFile)) {
                tempContext.setThirdClientData(setClientData("thirdClientData", jsonFile));
            }
            if (doesIdentifierExist("firstChildClientData", jsonFile)) {
                tempContext.setFirstChildClientData(setClientData("firstChildClientData", jsonFile));
            }
            if (doesIdentifierExist("secondChildClientData", jsonFile)) {
                tempContext.setSecondChildClientData(setClientData("secondChildClientData", jsonFile));
            }
        } else {
            Assert.fail(AssertMessages.JSON_FILE_DOES_NOT_EXISTS.toString());
        }
        return tempContext;

    }

    private static ClientDataPojo setClientData(String client, String jsonFile) throws IOException {
        return (ClientDataPojo.builder()
                .title(getValueFromJson(client, "title", jsonFile))
                .foreName(getValueFromJson(client, "foreName", jsonFile))
                .surName(getValueFromJson(client, "surName", jsonFile))
                .dateOfBirth(getValueFromJson(client, "dateOfBirth", jsonFile))
                .nino(getValueFromJson(client, "nino", jsonFile))
                .phoneNumber(getValueFromJson(client, "phoneNumber", jsonFile))
                .email(getValueFromJson(client, "email", jsonFile))
                .postCode(getValueFromJson(client, "postCode", jsonFile))
                .build());
    }

    private static ClientDataPojo setSurName(String jsonFile) throws IOException {
        return (ClientDataPojo.builder()
                .surName(getValueFromJson("latestRegisteredClientData", "surName", jsonFile))
                .build());
    }
}