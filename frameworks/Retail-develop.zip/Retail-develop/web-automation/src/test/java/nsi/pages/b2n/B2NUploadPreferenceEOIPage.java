package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import nsi.pages.Pages;
import lombok.Getter;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NUploadPreferenceEOIPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//p[@class='PROMPT']")
    private SelenideElement titleText;

    @FindBy(xpath = "//font[@class='OUTPUT']")
    private SelenideElement optInText;

    // CHECKBOXES

    @FindBy(id = "Ck01")
    private SelenideElement optInCheckbox;

    // BUTTONS

    @FindBy(id = "Subm81")
    private SelenideElement continueButton;
}
