package nsi.steps.b2c.customerMaintenance;


import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.PaperlessOptionsPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class PaperlessOptionsSteps extends Steps {

    private PaperlessOptionsPage paperlessOptionsPage = page(PaperlessOptionsPage.class);

    @Then("PaperlessOptionsPage: verify if paperless option is marked")
    public void verifyPaperlessOptionsCheckmarkEnabled() {
        paperlessOptionsPage.getPaperlessOption().shouldHave(Condition.exactText("Paperless"));
        paperlessOptionsPage.getChangeButton().click();
    }

    @Then("PaperlessOptionsPage: verify if paperless option is changed")
    public void verifyPaperlessOptionsCheckmarkDisabled() {
        paperlessOptionsPage.getPaperlessOption().shouldHave(Condition.exactText("not paperless"));
    }

    @Then("PaperlessOptionsPage: Change paperless options to disable")
    public void changePaperlessOptionsToDisable() {
        paperlessOptionsPage.getTitleText().shouldHave(Condition.exactText("Your paperless options"));
        paperlessOptionsPage.getPaperlessTickbox().shouldBe(Condition.selected);
        paperlessOptionsPage.getPaperlessTickbox().click();
        paperlessOptionsPage.getPaperlessTickbox().shouldBe(Condition.selected);
        log.info("Paperless option has been disabled");

        paperlessOptionsPage.getSaveButton().click();
        paperlessOptionsPage.getBackToPaperlessButton().shouldBe(Condition.visible);
        paperlessOptionsPage.getBackToPaperlessButton().click();
    }
}