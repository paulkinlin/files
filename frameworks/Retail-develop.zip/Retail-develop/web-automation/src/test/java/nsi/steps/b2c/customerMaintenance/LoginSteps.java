package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.dao.ClientDao;
import nsi.pages.b2c.customerMaintenance.DashboardPage;
import nsi.pages.b2c.customerMaintenance.LoginPage;
import nsi.pojos.ClientDataPojo;
import nsi.steps.Steps;
import nsi.utils.JsonUtils;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;
import static nsi.utils.JsonUtils.getValueFromJson;

@Slf4j
public class LoginSteps extends Steps {

    private final LoginPage loginPage = page(LoginPage.class);
    private final DashboardPage dashboardPage = page(DashboardPage.class);

    @Then("LoginPage: submit nsiNo {string} surname {string} passwd {string}")
    public void LoginPage_submit_already_registered_nsiNo_surname_passwd(String nsiNo, String surname,
                                                                         String password) {
        loginToApplication(nsiNo, surname, password);
    }

    @And("LoginPage: submit from json {string}")
    public void LoginPageSubmitFromJsonPasswd(String jsonFile) throws Throwable {
        String nsiNumber = getValueFromJson("nsiNumber" , jsonFile);
        String surname = getValueFromJson("mainInvestorClientData", "surName" , jsonFile);
        loginToApplication(nsiNumber, surname, SECURITY_PASSWORD);
        dashboardPage.getLogOutLink().execute(waitUntilVisible);
    }

    @And("LoginPage: submit latest client details from context")
    public void LoginPageSubmitLatestClientDetailsFromJsonPasswd() {
        String nsiNumber = getContext().getNsiNumber();
        String surname = getContext().getLatestRegisteredClientData().getSurName();
        loginToApplication(nsiNumber, surname, SECURITY_PASSWORD);
    }

    private void loginToApplication(String nsiNo, String surname, String password) {
        loginPage.getNsiNumberField().execute(clearAndSetValue(nsiNo));
        loginPage.getSurnameField().execute(clearAndSetValue(surname));
        loginPage.getPasswordField().execute(clearAndSetValue(password));

        log.info("Submitting nsiNo: {}, name: {}, password: {}", nsiNo, surname, password);

        loginPage.getLoginButton().execute(waitUntilClickable).execute(jsClick);
    }

    @And("LoginPage: login page is displayed")
    public void loginPageIsDisplayed() {
        loginPage.getLoginOrRegisterText().shouldBe(Condition.and("",Condition.visible, Condition.enabled));
    }

    @And("LoginPage: Retrieve latest registered client from DB and save in json")
    public void getLatestRegisteredClientFromDataBase() throws IOException {
        ClientDataPojo latestRegisteredClient = new ClientDataPojo().latestRegisteredClientData();
        getContext().setLatestRegisteredClientData(latestRegisteredClient);
        JsonUtils.writeContextToJsonfile(getContext());
    }

    @And("LoginPage: Retrieve account number of the product from DB using client number stored in json {string}")
    public void getAccountNumberOfTheProductFromDataBase(String jsonFile) throws IOException, ParseException {
        ClientDao clientDao = new ClientDao();
        String nineDigitAccountNumber = clientDao.getAccountNumberOfProduct(jsonFile).substring(1,10);
        getContext().setAccountNumber(nineDigitAccountNumber);
        JsonUtils.writeContextToJsonfile(getContext());
    }
}
