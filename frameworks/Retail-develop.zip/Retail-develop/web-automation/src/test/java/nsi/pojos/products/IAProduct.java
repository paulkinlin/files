package nsi.pojos.products;

public class IAProduct extends ProductPojo {
}
