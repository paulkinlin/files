package nsi.steps.b2c.initialSale;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.InvestmentDetailsPage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static com.codeborne.selenide.Selenide.sleep;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;

@Slf4j
public class InvestmentDetailsSteps extends Steps {

    private InvestmentDetailsPage investmentDetailsPage = page(InvestmentDetailsPage.class);

    @When("InvestmentDetailsPage: enter amt {string}")
    public void investmentDetailsPageEnterAmt(String amt) {
        investmentDetailsPage.getInvestAmountField().execute(clearAndSetValue(amt));
    }

    @When("InvestmentDetailsPage: enter amt {string} prizes paid {string}")
    public void InvestmentDetailsPageEnterAmtReinvest(String amt, String paid) {
        investmentDetailsPageEnterAmt(amt);

        if (!paid.isEmpty()) {
            switch (paid.toLowerCase()) {
                case "pay":
                    investmentDetailsPage.getPayToRadio().click();
                    ((PremiumBondProduct) getContext().getProductPojoList().getLast())
                            .setPbInvestDetails("Pay to my nominated account");
                    break;
                case "reinvest":
                    investmentDetailsPage.getReInvestRadio().click();
                    ((PremiumBondProduct) getContext().getProductPojoList().getLast())
                            .setPbInvestDetails("Reinvest into Premium Bonds");
                    investmentDetailsPage.getNominatedAccountTitleText()
                            .execute(waitUntilVisible)
                            .shouldHave(Condition.exactText("Nominated account details - if you reach the maximum investment"));
                    break;
                default:
                    Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
            }
        }
    }

    @And("InvestmentDetailsPage: submit term")
    public void InvestmentDetailsPageSubmitTerm() {
        investmentDetailsPage.getTermRadio().click();
    }

    @When("InvestmentDetailsPage: enter amt {string} nino {string}")
    public void InvestmentDetailsPageEnterAmtNinoPaperless(String amt, String nino) {
        investmentDetailsPage.getInvestAmountField().execute(clearAndSetValue(amt));
        setValueNino(nino);
    }

    private void setValueNino(String nino) {
        investmentDetailsPage.getNinoOneField().execute(clearAndSetValue(nino.substring(0, 2)));
        investmentDetailsPage.getNinoTwoField().execute(clearAndSetValue(nino.substring(2, 4)));
        investmentDetailsPage.getNinoThreeField().execute(clearAndSetValue(nino.substring(4, 6)));
        investmentDetailsPage.getNinoFourField().execute(clearAndSetValue(nino.substring(6, 8)));
        investmentDetailsPage.getNinoFiveField().execute(clearAndSetValue(nino.substring(8, 9)));
    }

    @When("InvestmentDetailsPage: enter nino {string}")
    public void InvestmentDetailsPageEnterNino(String nino) {
        setValueNino(nino);

        getContext().getMainInvestorClientData().setNino(nino);
    }

    @When("InvestmentDetailsPage: enter nino {string} {string} {string} {string} {string}")
    public void InvestmentDetailsPageEnterNinoForValidationField(String nino1, String nino2, String nino3, String nino4, String nino5) {
        if (!nino1.isEmpty()) {
            investmentDetailsPage.getNinoOneField().execute(clearAndSetValue(nino1));
        }
        if (!nino2.isEmpty()) {
            investmentDetailsPage.getNinoTwoField().execute(clearAndSetValue(nino2));
        }
        if (!nino3.isEmpty()) {
            investmentDetailsPage.getNinoThreeField().execute(clearAndSetValue(nino3));
        }
        if (!nino4.isEmpty()) {
            investmentDetailsPage.getNinoFourField().execute(clearAndSetValue(nino4));
        }
        if (!nino5.isEmpty()) {
            investmentDetailsPage.getNinoFiveField().execute(clearAndSetValue(nino5));
        }
    }

    @When("InvestmentDetailsPage: enter nino for main investor")
    public void InvestmentDetailsPageEnterNino() {
        String nino = getContext().getMainInvestorClientData().getNino();
        setValueNino(nino);
    }

    @When("InvestmentDetailsPage: receive documents {string}")
    public void InvestmentDetailsPageReceiveDocs(String paperless) {
        switch (paperless.toLowerCase()) {
            case "yes":
                investmentDetailsPage.getPaperLessStatementLink().click();
                break;
            case "no":
                investmentDetailsPage.getByPostStatementLink().click();
                break;
            default:
                investmentDetailsPage.getByPostStatementLink().click();
        }
    }

    @When("InvestmentDetailsPage: submit sortcode {string} {string} {string} acctNo {string} acctName {string}")
    public void nsiinitialsale_submit_sortcode_acctNo_acctName(String sCode1, String sCode2, String sCode3,
                                                               String acctNo, String acctName) {
        investmentDetailsPage.getSortcode1Field().execute(clearAndSetValue(sCode1));
        investmentDetailsPage.getSortcode2Field().execute(clearAndSetValue(sCode2));
        investmentDetailsPage.getSortcode3Field().execute(clearAndSetValue(sCode3));
        investmentDetailsPage.getAcctNumberField().execute(clearAndSetValue(acctNo));
        investmentDetailsPage.getAcctNameField().execute(clearAndSetValue(acctName));
        investmentDetailsPage.getContinueButton().click();
    }

    @When("InvestmentDetailsPage: choose your nominated accounts {string}")
    public void investmentDetailsPageChooseYourNominatedAccount(String option) {
        switch (option.toLowerCase()) {
            case "use an ns&i direct saver account":
                investmentDetailsPage.getUseNSIDirectSaverRadio().click();
                investmentDetailsPage.getUseNSIDirectSaverConfirmationRadio().execute(waitUntilIsSelected);
                break;
            case "add a new nominated account":
                investmentDetailsPage.getAddNewNominatedAccRadio().click();
                investmentDetailsPage.getAddNewNominatedAccConfirmationRadio().execute(waitUntilIsSelected);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("InvestmentDetailsPage: choose Direct Saver account")
    public void investmentDetailsPageChooseDirectSaverAccount() {
        sleep(200);
        investmentDetailsPage.getCheckDirectSaverAccRadio().execute(waitUntilClickable).execute(jsClick);
        investmentDetailsPage.getUseNSIDirectSaverConfirmationRadio().shouldBe(Condition.selected);
        investmentDetailsPage.getContinueButton().execute(waitUntilClickable).click();
    }

    @Then("InvestmentDetailsPage: verify investmentDetails {string} error message displays {string}")
    public void nsiinitialsaleVerifyInvestmentDetailsErrorMessageDisplays(String errorField, String errorMsg) {
        SelenideElement element = null;

        switch (errorField.toLowerCase()) {
            case "amount":
                element = investmentDetailsPage.getInvestAmountTextError();
                break;
            case "ninoone":
                element = investmentDetailsPage.getNinoOneTextError();
                break;
            case "ninotwo":
                element = investmentDetailsPage.getNinoTwoTextError();
                break;
            case "ninothree":
                element = investmentDetailsPage.getNinoThreeTextError();
                break;
            case "ninofour":
                element = investmentDetailsPage.getNinoFourTextError();
                break;
            case "ninofive":
                element = investmentDetailsPage.getNinoFiveTextError();
                break;
            case "sortcode1":
                element = investmentDetailsPage.getSortCode1TextError();
                break;
            case "sortcode2":
                element = investmentDetailsPage.getSortCode2TextError();
                break;
            case "sortcode3":
                element = investmentDetailsPage.getSortCode3TextError();
                break;
            case "accountnumber":
                element = investmentDetailsPage.getAcctNumberTextError();
                break;
            case "accountname":
                element = investmentDetailsPage.getAcctNameTextError();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
        element.shouldHave(Condition.text(errorMsg));
    }
}