package nsi.pojos.products;

public class IncomeBondProduct extends ProductPojo {
}
