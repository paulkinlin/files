package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ViewAccountPage extends Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnCancel")
    private SelenideElement cancelButton;

    // LINKS

    // ----------------------------------------------------
}