package nsi;

import com.codeborne.selenide.WebDriverRunner;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Locale;

import static com.codeborne.selenide.Selenide.sleep;

@Slf4j
public abstract class BaseClass {
    static {
        Locale.setDefault(Locale.ENGLISH);
    }

    public static int generateRandomNumber(final int min, final int max) {
        return (int) ((max - min + 1) * Math.random() + min);
    }

    public static void switchBrowserTab(int tabIndex)
    {
        ArrayList<String> tabs = new ArrayList<String>(WebDriverRunner.getWebDriver().getWindowHandles());
        WebDriverRunner.getWebDriver().switchTo().window(tabs.get(tabIndex));
        sleep(100);
    }
}