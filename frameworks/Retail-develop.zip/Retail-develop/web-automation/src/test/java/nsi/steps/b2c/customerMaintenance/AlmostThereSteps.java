package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.AlmostTherePage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

public class AlmostThereSteps extends Steps {

    private AlmostTherePage almostTherePage = page(AlmostTherePage.class);

    @Then("AlmostTherePage: click continue")
    public void thankYouUpdatedPhoneNoBackToYourDetails() {
        almostTherePage.getContinueButton().click();
    }

    @Then("AlmostTherePage: is submit form visible Premium Bonds")
    public void initialsalepaymentIsSubmitFormVisiblePBForSomeoneChild() {
        if(getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList().getLast())
                    .setHoldersNumber(almostTherePage.getHoldersNumberText().getText());
        }
        getContext().getProductPojoList().getLast().setAmount(almostTherePage.getTotalAmountText().getText());
        getContext().getProductPojoList().getLast().setReferenceNumber(almostTherePage.getReferenceNumber().getText());
        getContext().getProductPojoList().getLast().setProduct(almostTherePage.getConfirmationText().getText()
                .replaceAll("\\s+", "")
                .replaceAll("Your", "")
                .replaceAll("applicationdetails", "")
                .replaceAll("Print", ""));
    }
}