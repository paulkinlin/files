package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class PayInConfirmPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//h2[contains(.,'Payment details')]")
    private SelenideElement headerText;

    @FindBy(xpath = "//label[contains(text(), 'From')]/following-sibling::div")
    private SelenideElement payInAccountFromText;

    @FindBy(xpath = "//label[contains(text(), 'To')]/following-sibling::div")
    private SelenideElement payInAccountToText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnSubmit")
    private SelenideElement payNowButton;

    @FindBy(id = "btnNext")
    private SelenideElement confirmButton;
    // LINKS

    // ----------------------------------------------------
}