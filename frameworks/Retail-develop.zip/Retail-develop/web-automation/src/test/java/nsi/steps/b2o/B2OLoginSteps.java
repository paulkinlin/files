package nsi.steps.b2o;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2o.B2OLoginPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.*;

@Slf4j
public class B2OLoginSteps extends Steps {

    private final B2OLoginPage b2OLoginPage = page(B2OLoginPage.class);

    @And("B2OLoginPage: login")
    public void b2OLoginPageLogin() {
        b2OLoginPage.getLoginField().execute(clearAndSetValue("exp"));
        b2OLoginPage.getPasswordField().execute(clearAndSetValue(B2O_SECURITY_PASSWORD));
        b2OLoginPage.getLoginButton().execute(waitUntilClickable).execute(jsClick);
    }
}
