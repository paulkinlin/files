package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NCustomerDetailPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NCustomerDetailSteps extends Steps {

    private B2NCustomerDetailPage b2NCustomerDetailPage = page(B2NCustomerDetailPage.class);

    @Then("B2NCustomerDetailPage: validate CustomerCat {string} TypeOfCust {string} Title {string} Surname {string} Forenames {string} NI {string} DOB {string} Country {string}")
    public void customerdetailpageValidateCustomerCatTypeOfCustTitleSurnameForenamesNIDOBCountry(String customerCategory, String typeOfCustomer,
                                                                                                 String title, String surname,
                                                                                                 String forenames, String ni,
                                                                                                 String dob, String country) {
        switchToFrame("dynamic");

        if (!customerCategory.isEmpty()) {
            b2NCustomerDetailPage.getCustomerCategoryText().shouldHave(Condition.text(customerCategory));
        }
        if (!typeOfCustomer.isEmpty()) {
            b2NCustomerDetailPage.getTypeOfCustomerText().shouldHave(Condition.text(typeOfCustomer));
        }
        if (!title.isEmpty()) {
            b2NCustomerDetailPage.getTitleText().shouldHave(Condition.text(title));
        }
        if (!surname.isEmpty()) {
            b2NCustomerDetailPage.getSurnameText().shouldHave(Condition.text(surname));
        }
        if (!forenames.isEmpty()) {
            b2NCustomerDetailPage.getForenameText().shouldHave(Condition.text(forenames));
        }
        if (!ni.isEmpty()) {
            b2NCustomerDetailPage.getNiText().shouldHave(Condition.text(ni));
        }
        if (!dob.isEmpty()) {
            b2NCustomerDetailPage.getDateOfBirthText().shouldHave(Condition.text(dob));
        }
        if (!country.isEmpty()) {
            b2NCustomerDetailPage.getCountryText().shouldHave(Condition.text(country));
        }
    }

    @Then("B2NCustomerDetailPage: validate email {string}")
    public void bNCustomerDetailPageValidateEmailMarioAtosNet(String email) {
        switchToFrame("dynamic");

        if (!email.isEmpty()) {
            b2NCustomerDetailPage.getEmailText().shouldHave(Condition.text(email));
        }
    }

    @Then("B2NCustomerDetailPage: validate prefix {string} and telephone number {string}")
    public void bNCustomerDetailPageValidateTelephone(String prefix, String telephone) {
        switchToFrame("dynamic");
        b2NCustomerDetailPage.getTelephoneText().shouldHave(Condition.text(telephone));
        b2NCustomerDetailPage.getTelephonePrefixText().shouldHave(Condition.text(prefix));
    }

}
