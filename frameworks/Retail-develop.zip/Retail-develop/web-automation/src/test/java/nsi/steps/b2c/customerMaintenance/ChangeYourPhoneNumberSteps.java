package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.ChangeYourPhoneNumberPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ClientDataPojo.generatePhoneNumber;
import static nsi.utils.CustomCommands.clearAndSetValue;

public class ChangeYourPhoneNumberSteps extends Steps {
    public static String phoneNumberOne;
    public static String phoneNumberTwo;

    ChangeYourPhoneNumberPage changeYourPhoneNumberPage = page(ChangeYourPhoneNumberPage.class);

    @Then("ChangeYourPhoneNumberPage: answer the questions and submit")
    public void changeYourPhoneNoAnswerTheQuestions() {
        changeYourPhoneNumberPage.getHeaderText().shouldBe(Condition.visible);
        String questionOne = returnQuestionText(changeYourPhoneNumberPage.getQuestion1Text());
        String questionTwo = returnQuestionText(changeYourPhoneNumberPage.getQuestion2Text());
        String answerOne = questionOne.substring(questionOne.lastIndexOf(' ') + 1);
        String answerTwo = questionTwo.substring(questionTwo.lastIndexOf(' ') + 1);
        changeYourPhoneNumberPage.getAnswer1Field().execute(clearAndSetValue(answerOne));
        changeYourPhoneNumberPage.getAnswer2Field().execute(clearAndSetValue(answerTwo));
        changeYourPhoneNumberPage.getContinueConfirmButton().click();
    }

    private String returnQuestionText(SelenideElement element) {
        return element.getText().replaceAll("\\(([\\s\\S]*)\\)", "").
                replace("?", "")
                .trim();
    }

    @And("ChangeYourPhoneNumberPage: change main number")
    public void changeYourPhoneNumberMainNumber() {
        changeYourPhoneNumberPage.getPhoneNo1Field().execute(clearAndSetValue(generatePhoneNumber()));
    }

    @And("ChangeYourPhoneNumberPage: change additional number and submit")
    public void changeYourPhoneNumberAdditionalNumber() {
        changeYourPhoneNumberPage.getPhoneNo2Field().execute(clearAndSetValue(generatePhoneNumber()));
        changeYourPhoneNumberPage.getContinueConfirmButton().click();
    }

    @And("ChangeYourPhoneNumberPage: verify phone numbers are displayed and submit")
    public void changeYourPhoneNumberIsDisplayed() {
        changeYourPhoneNumberPage.getPhoneNo1ConfirmationText().shouldBe(Condition.visible);
        changeYourPhoneNumberPage.getPhoneNo2ConfirmationText().shouldBe(Condition.visible);
        changeYourPhoneNumberPage.getContinueConfirmButton().click();
    }
}