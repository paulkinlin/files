package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangePaymentInstructionPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NChangePaymentInstructionSteps extends Steps {

    private B2NChangePaymentInstructionPage b2NChangePaymentInstructionPage = page(B2NChangePaymentInstructionPage.class);

    @And("B2NChangePaymentInstructionPage: submit PayNSI {string} and NNA {string} or PayToExternal {string} NSC {string} NNA {string} ref or roll {string} Payee {string}")
    public void changepaymentinstructionpageSubmitPayNSIAndNNAOrPayToExternalNSCNNARefRollPayee(String payToNSI, String newNominatedAccount,
                                                                                                String payToExternal, String newSortCode,
                                                                                                String newNominatedAccountField, String refRoll,
                                                                                                String payee) {
        switchToFrame("dynamic");

        if (payToNSI.equals("y")) {
            b2NChangePaymentInstructionPage.getPayToNSICheckbox().click();

            b2NChangePaymentInstructionPage.getPayToNSICheckbox().shouldBe(Condition.selected);
            b2NChangePaymentInstructionPage.getPayToExternalCheckbox().shouldBe(Condition.not(Condition.selected));
        } else if (payToExternal.equals("y")) {
            b2NChangePaymentInstructionPage.getPayToExternalCheckbox().click();

            b2NChangePaymentInstructionPage.getPayToExternalCheckbox().shouldBe(Condition.selected);
            b2NChangePaymentInstructionPage.getPayToNSICheckbox().shouldBe(Condition.not(Condition.selected));
        } else {
            Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }

        if (!newNominatedAccount.isEmpty()) {
            b2NChangePaymentInstructionPage.getNewNominatedAccountSelect().selectOption(newNominatedAccount);
        }
        if (!newSortCode.isEmpty()) {
            b2NChangePaymentInstructionPage.getNewSortCodeField().execute(clearAndSetValue(newSortCode));
        }
        if (!newNominatedAccountField.isEmpty()) {
            b2NChangePaymentInstructionPage.getNewNominatedAccountField().execute(clearAndSetValue(newNominatedAccountField));
        }
        if (!payee.isEmpty()) {
            b2NChangePaymentInstructionPage.getPayeeField().execute(clearAndSetValue(payee));
        }

        b2NChangePaymentInstructionPage.getConfirmButton().click();
    }

    @And("B2NChangePaymentInstructionPage: select pay to external account radio")
    public void changepaymentinstructionpageSelectPayToExternalAccountRadio() {
        switchToFrame("dynamic");
        b2NChangePaymentInstructionPage.getPayToExternalCheckbox().execute(waitUntilVisible).click();
    }

    @And("B2NChangePaymentInstructionPage: set new sort code {string}")
    public void changepaymentinstructionpageSetNewSortCode(String sortCode) {
        switchToFrame("dynamic");
        b2NChangePaymentInstructionPage.getNewSortCodeField().execute(clearAndSetValue(sortCode));
    }

    @And("B2NChangePaymentInstructionPage: set new nominated account {string}")
    public void changepaymentinstructionpageSetNewNominatedAccount(String nominatedAccount) {
        switchToFrame("dynamic");
        b2NChangePaymentInstructionPage.getNewNominatedAccountField().execute(clearAndSetValue(nominatedAccount));
    }

    @And("B2NChangePaymentInstructionPage: set payee {string}")
    public void changepaymentinstructionpageSetPayee(String payee) {
        switchToFrame("dynamic");
        b2NChangePaymentInstructionPage.getPayeeField().execute(clearAndSetValue(payee));
    }

    @And("B2NChangePaymentInstructionPage: click confirm")
    public void changepaymentinstructionpageClickConfirm() {
        switchToFrame("dynamic");
        b2NChangePaymentInstructionPage.getConfirmButton().execute(waitUntilVisible).click();
    }
}