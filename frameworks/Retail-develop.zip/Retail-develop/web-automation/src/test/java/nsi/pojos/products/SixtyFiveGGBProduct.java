package nsi.pojos.products;

public class SixtyFiveGGBProduct extends ProductPojo {
}
