package nsi.pojos.products;

public class CBProduct extends ProductPojo {
}
