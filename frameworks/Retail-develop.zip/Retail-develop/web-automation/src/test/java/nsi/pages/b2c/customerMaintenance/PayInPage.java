package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class PayInPage extends Pages {

    // TEXTS
    @FindBy(className = "error")
    private SelenideElement errorText;

    @FindBy(xpath = "//div[@class='info-panel info-panel--error']")
    private SelenideElement accountBlockErrorText;

    // FIELDS
    @FindBy(id = "operationAmount")
    private SelenideElement amountField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//input[@name='btnNext']")
    private SelenideElement continueButton;

    // LINKS

    // ----------------------------------------------------
}