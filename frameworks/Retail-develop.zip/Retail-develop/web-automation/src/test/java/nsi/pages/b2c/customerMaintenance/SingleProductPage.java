package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class SingleProductPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[contains(@id,'currentBalance')]/div")
    private SelenideElement balanceText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//a[contains(text(),'Cash in')]")
    private SelenideElement cashInButton;

    // LINKS
}