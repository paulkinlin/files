package nsi.pojos;

import com.github.javafaker.Faker;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nsi.dao.ClientDao;
import org.sql2o.data.Table;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static nsi.pojos.ContextFactory.getContext;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Slf4j
public class ClientDataPojo {
    private String title;
    private String foreName;
    private String surName;
    private String dateOfBirth;
    private String nino;
    private String phoneNumber;
    private String email;
    private String postCode;
    private String address;
    private String answerQuestion1;
    private String answerQuestion2;
    private String answerQuestion3;

    public ClientDataPojo createClientFromUK() {
        Faker ukFaker = new Faker(new Locale("en-GB"));
        String regexOfNI = "[A-CEGHJ-PR-TW-Z]{1}[A-CEGHJ-NPR-TW-Z]{1}[0-9]{6}[A-D]{1}";

        return ClientDataPojo.builder()
                .title(ukFaker.name().prefix().replace(".", ""))
                .foreName(ukFaker.name().firstName())
                .surName(ukFaker.name().lastName())
                .dateOfBirth(new SimpleDateFormat("dd-MM-yyyy").format(ukFaker.date().birthday(25, 30)))
                .nino(ukFaker.regexify(regexOfNI))
                .phoneNumber(ukFaker.bothify("7780######"))
                .email(ukFaker.bothify("?????###@test.atos"))
                .postCode("DH11SL")
                .build();
    }

    public ClientDataPojo createClientFromUKUnder18() {
        Faker ukFaker = new Faker(new Locale("en-GB"));
        String regexOfNI = "[A-CEGHJ-PR-TW-Z]{1}[A-CEGHJ-NPR-TW-Z]{1}[0-9]{6}[A-D]{1}";

        return ClientDataPojo.builder()
                .title("Mr")
                .foreName(ukFaker.name().firstName())
                .surName(ukFaker.name().lastName())
                .dateOfBirth(new SimpleDateFormat("dd-MM-yyyy").format(ukFaker.date().birthday(16, 17)))
                .nino(ukFaker.regexify(regexOfNI))
                .phoneNumber(ukFaker.bothify("7780 ######"))
                .email(ukFaker.bothify("?????###@test.atos"))
                .postCode("DH11SL")
                .build();
    }

    public ClientDataPojo createClientFromUKbetween16and17() {
        Faker ukFaker = new Faker(new Locale("en-GB"));
        String regexOfNI = "[A-CEGHJ-PR-TW-Z]{1}[A-CEGHJ-NPR-TW-Z]{1}[0-9]{6}[A-D]{1}";

        return ClientDataPojo.builder()
                .title("Mr")
                .foreName(ukFaker.name().firstName())
                .surName(ukFaker.name().lastName())
                .dateOfBirth("01-01-2002")  //this date is hardcoded only for IDT env, for other env please use .format(ukFaker.date().birthday(16, 17)) instead
                .nino(ukFaker.regexify(regexOfNI))
                .phoneNumber(ukFaker.bothify("7780 ######"))
                .email(ukFaker.bothify("?????###@test.atos"))
                .postCode("DH11SL")
                .build();
    }

    public ClientDataPojo createClientFromUKForJointAccount() {
        Faker ukFaker = new Faker(new Locale("en-GB"));
        String regexOfNI = "[A-CEGHJ-PR-TW-Z]{1}[A-CEGHJ-NPR-TW-Z]{1}[0-9]{6}[A-D]{1}";

        return ClientDataPojo.builder()
                .title(ukFaker.name().prefix().replace(".", ""))
                .foreName(ukFaker.name().firstName())
                .surName(getContext().getMainInvestorClientData().surName)
                .dateOfBirth(new SimpleDateFormat("dd-MM-yyyy").format(ukFaker.date().birthday(25, 30)))
                .nino(ukFaker.regexify(regexOfNI))
                .phoneNumber(ukFaker.bothify("7780 ######"))
                .email(ukFaker.bothify("?????###@test.atos"))
                .postCode("DH11SL")
                .build();
    }

    public ClientDataPojo createClientFromUKUnder18ForJointAccount() {
        Faker ukFaker = new Faker(new Locale("en-GB"));
        String regexOfNI = "[A-CEGHJ-PR-TW-Z]{1}[A-CEGHJ-NPR-TW-Z]{1}[0-9]{6}[A-D]{1}";

        return ClientDataPojo.builder()
                .title("Mr")
                .foreName(ukFaker.name().firstName())
                .surName(getContext().getMainInvestorClientData().surName)
                .dateOfBirth(new SimpleDateFormat("dd-MM-yyyy").format(ukFaker.date().birthday(16, 17)))
                .nino(ukFaker.regexify(regexOfNI))
                .phoneNumber(ukFaker.bothify("7780 ######"))
                .email(ukFaker.bothify("?????###@test.atos"))
                .postCode("DH11SL")
                .build();
    }

    public ClientDataPojo latestRegisteredClientData() {
        ClientDao clientDao = new ClientDao();
        Table clientDetails = clientDao.getLatestRegisteredClient();
        List<Map<String, Object>> clientDetailsList = clientDetails.asList();
        surName = (String) clientDetailsList.get(0).get("nomcli");
        getContext().setClientNumber((String) clientDetailsList.get(0).get("numcli"));
        getContext().setNsiNumber((String) clientDetailsList.get(0).get("numidt"));
        return ClientDataPojo.builder()
                .surName(surName)
                .build();
    }

    public String getNinoWithSpaces() {
        String nino1 = nino.substring(0, 2);
        String nino2 = nino.substring(2, 4);
        String nino3 = nino.substring(4, 6);
        String nino4 = nino.substring(6, 8);
        String nino5 = nino.substring(8, 9);

        return String.join(" ", nino1, nino2, nino3, nino4, nino5);
    }

    public String getClientTitleForeSureName() {
        return String.join(" ", title, foreName, surName);
    }

    public static String generateEmailAddress(){
        return new Faker(new Locale("en-GB")).bothify("?????###@test.atos");
    }

    public static String generatePhoneNumber(){
        return new Faker(new Locale("en-GB")).bothify("7780 ######");
    }

}
