package nsi.steps.b2c.initialSale;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.YourDetailsPage;
import nsi.pojos.ClientDataPojo;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;

@Slf4j
public class YourDetailsSteps {
    private YourDetailsPage yourDetailsPage = page(YourDetailsPage.class);

    @And("YourDetailsPage: account or investment not on sale {string}")
    public void nsiinitialsale_account_investment_not_on_sale(String errorMsg) {
        yourDetailsPage.getInfoAccountInvestmentNotOnSaleText().shouldHave(Condition.text(errorMsg));
        log.info("Test finished. {}", errorMsg);
    }

    @When("YourDetailsPage: fill title {string} forename {string} surname {string} day {string} month {string} year {string} for main investor")
    public void nsiinitialsaleFillTitleForenameSurnameDayMonthYearMainInvestor(String title, String forename,
                                                                               String surname, String dobDay,
                                                                               String dobMonth, String dobYear) {

        fillTitleForeNameSurnameDobForMainInvestor(title, forename, surname, dobDay, dobMonth, dobYear);

        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();

        mainInvestor.setTitle(title);
        mainInvestor.setForeName(forename);
        mainInvestor.setSurName(surname);
        mainInvestor.setDateOfBirth(String.join("-", dobDay, dobMonth, dobYear));
    }

    private void fillTitleForeNameSurnameDobForMainInvestor(String title, String forename,
                                                            String surname, String dobDay,
                                                            String dobMonth, String dobYear) {
        if (!title.isEmpty()) {
            yourDetailsPage.getTitleMainInvestorSelect().selectOption(title);
        }
        if (!forename.isEmpty()) {
            yourDetailsPage.getForenameMainInvestorField().execute(clearAndSetValue(forename));
        }
        if (!surname.isEmpty()) {
            yourDetailsPage.getSurnameMainInvestorField().execute(clearAndSetValue(surname));
        }
        if (!dobDay.isEmpty()) {
            yourDetailsPage.getDobDayMainInvestorSelect().selectOption(dobDay);
        }
        if (!dobMonth.isEmpty()) {
            yourDetailsPage.getDobMonthMainInvestorSelect().selectOption(dobMonth);
        }
        if (!dobYear.isEmpty()) {
            yourDetailsPage.getDobYearMainInvestorSelect().selectOption(dobYear);
        }
    }

    @When("YourDetailsPage: fill title, forename, surname, day, month, year for main investor")
    public void nsiinitialsaleFillTitleForenameSurnameDayMonthYearMainInvestorContext() {

        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();

        String title = mainInvestor.getTitle();
        String foreName = mainInvestor.getForeName();
        String surName = mainInvestor.getSurName();
        String day = mainInvestor.getDateOfBirth().substring(0, 2);
        String month = mainInvestor.getDateOfBirth().substring(3, 5);
        String year = mainInvestor.getDateOfBirth().substring(6);

        nsiinitialsaleFillTitleForenameSurnameDayMonthYearMainInvestor(title, foreName, surName, day, month, year);
    }

    @When("YourDetailsPage: fill title {string} forename {string} surname {string} day {string} month {string} year {string} for second investor")
    private void nsiinitialsaleFillTitleForenameSurnameDayMonthYearSecondInvestor(String title, String forename,
                                                                                  String surname, String dobDay, String dobMonth, String dobYear) {

        yourDetailsPage.getTitleSecondInvestorSelect().selectOption(title);
        yourDetailsPage.getForenameSecondInvestorField().execute(clearAndSetValue(forename));
        yourDetailsPage.getSurnameSecondInvestorField().execute(clearAndSetValue(surname));
        selectDobSecondInvestorSelect(dobDay, dobMonth, dobYear);

        ClientDataPojo secondInvestor = getContext().getSecondClientData();

        secondInvestor.setTitle(title);
        secondInvestor.setForeName(forename);
        secondInvestor.setSurName(surname);
        secondInvestor.setDateOfBirth(String.join("-", dobDay, dobMonth, dobYear));
    }

    private void selectDobSecondInvestorSelect(String dobDay, String dobMonth, String dobYear) {
        yourDetailsPage.getDobDaySecondInvestorSelect().selectOption(dobDay);
        yourDetailsPage.getDobMonthSecondInvestorSelect().selectOption(dobMonth);
        yourDetailsPage.getDobYearSecondInvestorSelect().selectOption(dobYear);
    }

    @When("YourDetailsPage: fill title, forename, surname, day, month, year for second investor")
    public void nsiinitialsaleFillTitleForenameSurnameDayMonthYearSecondInvestorContext() {

        ClientDataPojo secondInvestor = getContext().getSecondClientData();

        String title = secondInvestor.getTitle();
        String foreName = secondInvestor.getForeName();
        String surName = secondInvestor.getSurName();
        String day = secondInvestor.getDateOfBirth().substring(0, 2);
        String month = secondInvestor.getDateOfBirth().substring(3, 5);
        String year = secondInvestor.getDateOfBirth().substring(6);

        nsiinitialsaleFillTitleForenameSurnameDayMonthYearSecondInvestor(title, foreName, surName, day, month, year);
    }

    @When("YourDetailsPage: fill title {string} forename {string} surname {string} day {string} month {string} year {string} for child parent")
    private void nsiinitialsaleFillTitleForenameSurnameDayMonthYearChildParent(String title, String forename,
                                                                               String surname, String dobDay, String dobMonth, String dobYear) {
        yourDetailsPage.getTitleChildParentSelect().selectOption(title);
        yourDetailsPage.getForenameChildParentField().execute(clearAndSetValue(forename));
        yourDetailsPage.getSurnameChildParentField().execute(clearAndSetValue(surname));
        selectDobChildParentSelect(dobDay, dobMonth, dobYear);

        ClientDataPojo childParent = getContext().getThirdClientData();

        childParent.setTitle(title);
        childParent.setForeName(forename);
        childParent.setSurName(surname);
        childParent.setDateOfBirth(String.join("-", dobDay, dobMonth, dobYear));
    }

    private void selectDobChildParentSelect(String dobDay, String dobMonth, String dobYear) {
        yourDetailsPage.getDobDayChildParentSelect().selectOption(dobDay);
        yourDetailsPage.getDobMonthChildParentSelect().selectOption(dobMonth);
        yourDetailsPage.getDobYearChildParentSelect().selectOption(dobYear);
    }

    @When("YourDetailsPage: fill title, forename, surname, day, month, year for child parent")
    public void nsiinitialsaleFillTitleForenameSurnameDayMonthYearChildParentContext() {

        ClientDataPojo childParent = getContext().getThirdClientData();

        String title = childParent.getTitle();
        String foreName = childParent.getForeName();
        String surName = childParent.getSurName();
        String day = childParent.getDateOfBirth().substring(0, 2);
        String month = childParent.getDateOfBirth().substring(3, 5);
        String year = childParent.getDateOfBirth().substring(6);

        nsiinitialsaleFillTitleForenameSurnameDayMonthYearChildParent(title, foreName, surName, day, month, year);
    }

    @When("YourDetailsPage: submit same address as first investor")
    public void nsiinitialsale__same_address() {
        yourDetailsPage.getSecondInvestorSameAddressCheckbox().click();
    }

    @When("YourDetailsPage: fill title {string} forename {string} surname {string} day {string} month {string} year {string} for child")
    public void nsiinitialsaleFillTitleForenameSurnameDayMonthYearChild(String title, String forename, String surname,
                                                                        String dobDay, String dobMonth, String dobYear) {

        fillTitleForenameSurnameDobForChild(title, forename, surname, dobDay, dobMonth, dobYear);

        ClientDataPojo child = getContext().getFirstChildClientData();

        child.setTitle(title);
        child.setForeName(forename);
        child.setSurName(surname);
        child.setDateOfBirth(String.join("-", dobDay, dobMonth, dobYear));

    }

    private void fillTitleForenameSurnameDobForChild(String title, String forename, String surname,
                                                     String dobDay, String dobMonth, String dobYear) {
        if (!title.isEmpty()) {
            yourDetailsPage.getTitleChildSelect().selectOption(title);
        }
        if (!forename.isEmpty()) {
            yourDetailsPage.getForenameChildField().execute(clearAndSetValue(forename));
        }
        if (!surname.isEmpty()) {
            yourDetailsPage.getSurnameChildField().execute(clearAndSetValue(surname));
        }
        if (!dobDay.isEmpty()) {
            yourDetailsPage.getDobDayChildSelect().selectOption(dobDay);
        }
        if (!dobMonth.isEmpty()) {
            yourDetailsPage.getDobMonthChildSelect().selectOption(dobMonth);
        }
        if (!dobYear.isEmpty()) {
            yourDetailsPage.getDobYearChildSelect().selectOption(dobYear);
        }
    }

    @When("YourDetailsPage: fill title, forename, surname, day, month, year for child")
    public void nsiinitialsaleFillTitleForenameSurnameDayMonthYearChildContext() {

        ClientDataPojo child = getContext().getFirstChildClientData();

        String title = child.getTitle();
        String foreName = child.getForeName();
        String surName = child.getSurName();
        String day = child.getDateOfBirth().substring(0, 2);
        String month = child.getDateOfBirth().substring(3, 5);
        String year = child.getDateOfBirth().substring(6);

        fillTitleForenameSurnameDobForChild(title, foreName, surName, day, month, year);
    }

    @When("YourDetailsPage: find postCode {string} for main investor")
    public void nsiinitialsaleFindPostcodeMainInvestor(String postCode) {
        yourDetailsPage.getPostcodeMainInvestorField().execute(clearAndSetValue(postCode));
        yourDetailsPage.getLookUpPostcodeButton().execute(jsClick);
    }

    @When("YourDetailsPage: find postCode main investor")
    public void nsiinitialsaleFindPostcodeMainInvestorContext() {
        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();
        String postCode = mainInvestor.getPostCode();
        nsiinitialsaleFindPostcodeMainInvestor(postCode);
    }

    @When("YourDetailsPage: fill main investor address {string}")
    public void nsiinitialsaleFillMainInvestorAddress(String addressText) {
        Select dropdownSelect = new Select(yourDetailsPage.getAddressMainInvestorSelect());
        List<WebElement> dropdownOptions = dropdownSelect.getOptions();
        boolean optionExists = dropdownOptions.stream().anyMatch(
                dropdownAddress -> dropdownAddress.getText().equals(addressText));

        if (optionExists) {
            yourDetailsPage.getAddressMainInvestorSelect().selectOptionContainingText(addressText);
        } else {
            yourDetailsPage.getAddressMainInvestorSelect().selectOption(1);
        }
    }

    @When("YourDetailsPage: find postCode {string} for second investor")
    private void nsiinitialsaleFindPostcodeSecondInvestor(String postCode) {
        findPostCodeForSecondInvestor(postCode);
        getContext().getSecondClientData().setPostCode(postCode);
    }

    @When("YourDetailsPage: find postCode second investor")
    public void nsiinitialsaleFindPostcodeSecondInvestorContext() {
        String postCode = getContext().getSecondClientData().getPostCode();
        findPostCodeForSecondInvestor(postCode);
    }

    private void findPostCodeForSecondInvestor(String postCode) {
        yourDetailsPage.getPostcodeSecondInvestorField().execute(clearAndSetValue(postCode));
        yourDetailsPage.getLookUpPostcodeSecondInvestorButton().execute(jsClick);
    }

    @When("YourDetailsPage: fill second investor address {string}")
    public void nsiinitialsaleFillSecondInvestorAddress(String addressText) {
        yourDetailsPage.getAddressSecondInvestorSelect().selectOptionContainingText(addressText);
    }

    @When("YourDetailsPage: find postCode {string} for child")
    private void nsiinitialsaleFindPostcodeChild(String postCode) {
        yourDetailsPage.getPostcodeChildField().execute(clearAndSetValue(postCode));

        ClientDataPojo child = getContext().getFirstChildClientData();
        child.setPostCode(postCode);
        yourDetailsPage.getLookUpPostcodeChildButton().execute(jsClick);
    }

    @When("YourDetailsPage: find postCode child")
    public void nsiinitialsaleFindPostcodeChildContext() {
        ClientDataPojo child = getContext().getFirstChildClientData();
        String postCode = child.getPostCode();
        nsiinitialsaleFindPostcodeChild(postCode);
    }

    @When("YourDetailsPage: fill child address {string}")
    public void nsiinitialsaleFillChildAddress(String addressText) {
        yourDetailsPage.getAddressChildSelect().selectOptionContainingText(addressText);
    }

    @When("YourDetailsPage: submit child's grandparent or great grandparent")
    public void nsiinitialsale_childs_grandparent_greatgrandparent() {
        yourDetailsPage.getChildsGrandParentCheckbox().click();
    }

    @When("YourDetailsPage: fill tax nonUK {string} city {string} country {string} tax country {string} tax number {string}")
    public void nsiinitialsalepbFillTaxStatus(String tax, String city, String country, String taxCountry,
                                              String taxNumber) {
        switch (tax.toLowerCase()) {
            case "yes":
                yourDetailsPage.getTaxNonUKNORadio().click();
                setValueTaxInformationCityCountryTaxCountryMainInvestor(city, country, taxCountry);
                yourDetailsPage.getTaxIDMainInvestorField().execute(clearAndSetValue(taxNumber));
                break;
            case "no":
                yourDetailsPage.getTaxNonUKNORadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("YourDetailsPage: fill tax for child nonUK {string} city {string} country {string} tax country {string} tax number {string}")
    public void nsiinitialsalepbFillTaxStatusForChild(String tax, String city, String country, String taxCountry,
                                                      String tinNumber) {
        switch (tax.toLowerCase()) {
            case "yes":
                yourDetailsPage.getChildTaxYESRadio().click();
                setValueTaxInformationCityCountryTaxCountryTaxIDChild(city, country, taxCountry, tinNumber);
                break;
            case "no":
                yourDetailsPage.getChildTaxNORadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("YourDetailsPage: fill tax nonUK {string} city {string} country {string} tax country {string} tin {string} tinNumber {string}")
    public void nsiinitialsalepbFillTaxStatusNotin(String nonUK, String city, String country, String taxCountry,
                                                   String tin, String tinNumber) {
        switch (nonUK.toLowerCase()) {
            case "yes":
                yourDetailsPage.getTaxNonUKYESRadio().execute(waitUntilClickable).click();
                yourDetailsPage.getTaxNonUKYESConfirmationRadio().shouldHave(Condition.attribute("checked"));
                setValueTaxInformationCityCountryTaxCountryMainInvestor(city, country, taxCountry);

                switch (tin.toLowerCase()) {
                    case "yes":
                        yourDetailsPage.getTaxIDMainInvestorField().execute(clearAndSetValue(tinNumber));
                        break;
                    case "no":
                        yourDetailsPage.getTinRadio().click();
                        break;
                    default:
                        Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
                }
                break;
            case "no":
                yourDetailsPage.getTaxNonUKNORadio().execute(waitUntilClickable).click();
                yourDetailsPage.getTaxNonUKNOConfirmationRadio().shouldHave(Condition.attribute("checked"));
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("YourDetailsPage: submit joint account")
    public void nsiinitialsale_joint_account() {
        yourDetailsPage.getAddASecondInvestorLink().click();
        yourDetailsPage.getRemoveSecondInvestorLink().shouldHave(Condition.exactText("Remove second investor"));
    }

    @When("YourDetailsPage: submit buying for child {string}")
    public void nsiinitialsalepb_submit_buying_for_child(String buyingForChild) {
        switch (buyingForChild.toLowerCase()) {
            case "yes":
                yourDetailsPage.getBuyingForChildYESRadio().click();
                yourDetailsPage.getBuyingForChildYESConfirmationRadio().shouldBe(Condition.selected);
                break;
            case "no":
                yourDetailsPage.getBuyingForChildNORadio().click();
                yourDetailsPage.getBuyingForChildNOConfirmationRadio().shouldBe(Condition.selected);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("YourDetailsPage: submit buying for your own or someone else child {string}")
    public void nsiinitialsalepb_submit_buying_for_own_someone_else_child(String option) {
        switch (option.toLowerCase()) {
            case "buying for your own child as their parent or guardian":
                yourDetailsPage.getBuyingForOwnChildRadio().click();
                yourDetailsPage.getBuyingForOwnChildConfirmationRadio().shouldBe(Condition.selected);
                break;
            case "buying for someone else's child":
                yourDetailsPage.getBuyingForSomeoneElseChildRadio().click();
                yourDetailsPage.getBuyingForSomeoneElseChildConfirmationRadio().shouldBe(Condition.selected);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("YourDetailsPage: submit tax nonUK PB {string} city {string} country {string} tax country {string} tax number {string}")
    public void nsiinitialsale_pb_submit_tax_status(String tax, String city, String country, String taxCountry,
                                                    String taxNumber) {

        switch (tax.toLowerCase()) {
            case "yes":
                yourDetailsPage.getTaxNonUKPBYESRadio().click();
                break;
            case "no":
                yourDetailsPage.getTaxNonUKPBNORadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("YourDetailsPage: click Continue")
    public void nsiinitialsaleClickContinue() {
        yourDetailsPage.getContinueButton().click();
    }

    @Then("YourDetailsPage: verify yourDetails {string} error message displays {string}")
    public void nsiinitialsaleVerifyYourDetailsErrorMessageDisplays(String errorField, String errorMsg) {
        SelenideElement element = null;
        switch (errorField.toLowerCase()) {
            case "title":
                element = yourDetailsPage.getTitleErrorMsgMainInvestorText();
                break;
            case "forename":
                element = yourDetailsPage.getForenameErrorMsgMainInvestorText();
                break;
            case "surname":
                element = yourDetailsPage.getSurnameErrorMsgMainInvestorText();
                break;
            case "dob_day":
                element = yourDetailsPage.getDobDayErrorMsgMainInvestorText();
                break;
            case "dob_month":
                element = yourDetailsPage.getDobMonthErrorMsgMainInvestorText();
                break;
            case "dob_year":
                element = yourDetailsPage.getDobYearErrorMsgMainInvestorText();
                break;
            case "postcode":
                element = yourDetailsPage.getPostcodeErrorMsgMainInvestorText();
                break;
            case "address":
                element = yourDetailsPage.getAddressSelectErrorMsgMainInvestorText();
                break;
            case "infopostcode":
                element = yourDetailsPage.getInfoPostcodeErrorMsgBoxMainInvestorText();
                break;
            case "infoaddress":
                element = yourDetailsPage.getInfoChosenAddressErrorMsgMainInvestorText();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }

        element.execute(waitUntilAppears).shouldHave(Condition.text(errorMsg));
    }

    @And("YourDetailsPage: submit link {string}")
    public void nsiinitialsaleSubmit(String link) {
        switch (link.toLowerCase()) {
            case "nopostcodelink":
                yourDetailsPage.getDontKnowPostcodeLink().click();
                break;
            case "cantfindaddresslink":
                yourDetailsPage.getCantFindAddressLink().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("YourDetailsPage: verify Continue button disabled")
    public void nsiinitialsaleVerifyContinueButtonDisabled() {
        yourDetailsPage.getContinueButton().shouldNotBe(Condition.visible);
    }

    @And("YourDetailsPage: submit cantFindEdit")
    public void nsiinitialsaleSubmitCantFindEdit() {
        yourDetailsPage.getCantFindEditButton().click();
    }

    @And("YourDetailsPage: choose same address as parent or guardian")
    public void nsiinitialsaleChooseSameAddressAsParentGuardian() {
        yourDetailsPage.getChildSameAddressCheckbox().click();
        yourDetailsPage.getChildSameAddressConfirmationCheckbox().shouldBe(Condition.selected);
    }

    @And("YourDetailsPage: choose same address as child")
    public void nsiinitialsaleChooseSameAddressAsChild() {
        yourDetailsPage.getParentSameAddressCheckbox().click();
        yourDetailsPage.getParentSameAddressConfirmationCheckbox().shouldBe(Condition.selected);
    }

    @And("YourDetailsPage: find postCode parent")
    public void nsiinitialsaleFindPostcodeParentContext() {
        ClientDataPojo parent = getContext().getMainInvestorClientData();
        String postCode = parent.getPostCode();
        nsiinitialsaleFindPostcodeParent(postCode);
    }

    @When("YourDetailsPage: find postCode {string} for parent")
    private void nsiinitialsaleFindPostcodeParent(String postCode) {
        yourDetailsPage.getPostcodeParentField().execute(clearAndSetValue(postCode));
        ClientDataPojo parent = getContext().getMainInvestorClientData();
        parent.setPostCode(postCode);
        yourDetailsPage.getLookUpPostcodeParentButton().execute(jsClick);
    }

    @When("YourDetailsPage: fill parent address {string}")
    public void nsiinitialsaleFillParentAddress(String addressText) {
        yourDetailsPage.getAddressParentSelect().selectOptionContainingText(addressText);
    }

    @When("YourDetailsPage: choose second investor details {string}")
    public void nsiinitialsaleChooseSecondInvestorDetails(String option) {
        switch (option.toLowerCase()) {
            case "i know their ns&i number":
                yourDetailsPage.getKnowNSINumberRadio().click();
                yourDetailsPage.getKnowNSINumberConfirmationRadio().shouldBe(Condition.selected);
                break;
            case "i don't know their ns&i number":
                yourDetailsPage.getDontKnowNSINumberRadio().click();
                yourDetailsPage.getDontKnowNSINumberConfirmationRadio().shouldBe(Condition.selected);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    private void setValueTaxInformationCityCountryTaxCountryMainInvestor(String city, String country, String taxCountry) {
        yourDetailsPage.getTaxBirthCityMainInvestorField().execute(clearAndSetValue(city));
        yourDetailsPage.getTaxBirthCountryMainInvestorSelect().selectOptionContainingText(country);
        yourDetailsPage.getTaxCountryMainInvestorSelect().selectOptionContainingText(taxCountry);
    }

    private void setValueTaxInformationCityCountryTaxCountryTaxIDChild(String city, String country, String taxCountry, String tinNumber) {
        yourDetailsPage.getTaxBirthCityChildField().execute(clearAndSetValue(city));
        yourDetailsPage.getTaxBirthCountryChildSelect().selectOptionContainingText(country);
        yourDetailsPage.getTaxCountryChildSelect().selectOptionContainingText(taxCountry);
        yourDetailsPage.getTaxIDChildField().execute(clearAndSetValue(tinNumber));
    }
}