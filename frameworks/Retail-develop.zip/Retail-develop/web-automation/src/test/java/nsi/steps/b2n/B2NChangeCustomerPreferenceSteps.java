package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeCustomerPreferencePage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class B2NChangeCustomerPreferenceSteps extends Steps {

    private B2NChangeCustomerPreferencePage b2NChangeCustomerPreferencePage = page(B2NChangeCustomerPreferencePage.class);

    private void getCorrectPrefForContext(String option, String position) {
        Boolean flag = true;
        if (position.equals("n")) {
            flag = false;
        }
        switch (option) {
            case "By all channels":
                getContext().setMarketingPreferenceByPost(flag);
                getContext().setMarketingPreferenceByEmail(flag);
                getContext().setMarketingPreferenceByPhone(flag);
                getContext().setMarketingPreferenceOnline(flag);
                break;
            case "Marketing, by post":
                getContext().setMarketingPreferenceByPost(flag);
                break;
            case "Marketing, by email":
                getContext().setMarketingPreferenceByEmail(flag);
                break;
            case "Marketing, by phone":
                getContext().setMarketingPreferenceByPhone(flag);
                break;
            case "Marketing, online":
                getContext().setMarketingPreferenceOnline(flag);
                break;
        }
    }

    private SelenideElement getCorrectRadioButton(String option, String radioButton) {
        switchToFrame("dynamic");

        ElementsCollection radioButtons = b2NChangeCustomerPreferencePage.getCustomersTable()
                .$$(By.tagName("tr"))
                .filter(Condition.text(option))
                .first()
                .$$(By.tagName("input"));

        return (radioButton.toLowerCase().equals("y")) ? radioButtons.first() : radioButtons.last();
    }

    @And("B2NChangeCustomerPreferencePage: select {string} option {string}")
    public void changecustomerpreferencepageSelectOption(String option, String position) {
        SelenideElement radioButton = getCorrectRadioButton(option, position);

        radioButton.click();
        radioButton.shouldBe(Condition.selected);

        getCorrectPrefForContext(option, position);

        log.info("ChangeCustomerPreferencePage select '{}' option '{}'", option, position);
    }

    @And("B2NChangeCustomerPreferencePage: confirm")
    public void changecustomerpreferencepageConfirm() {
        switchToFrame("dynamic");

        b2NChangeCustomerPreferencePage.getConfirmButton().click();
    }

    @Then("B2NChangeCustomerPreferencePage: verify {string} is selected {string}")
    public void bNChangeCustomerPreferencePageVerifyIsSelected(String option, String position) {
        getCorrectRadioButton(option, position).shouldBe(Condition.selected);
    }

    @Then("B2NChangeCustomerPreferencePage: verify all channels is selected {string}")
    public void bNChangeCustomerPreferencePageVerifyAllChannelsIsSelected(String option) {
        switchToFrame("dynamic");

        b2NChangeCustomerPreferencePage.getCustomersTable()
                .shouldBe(Condition.visible)
                .findAll(By.tagName("tr"))
                .get(1)
                .findAll(By.tagName("input"))
                .filter(Condition.not(Condition.selected))
                .shouldHaveSize(2);

        b2NChangeCustomerPreferencePage.getCustomersTable()
                .findAll(By.tagName("input"))
                .filter(Condition.attribute("value", (option.equals("yes") ? "01" : "02")))
                .filter(Condition.selected)
                .shouldHaveSize(9);
    }
}
