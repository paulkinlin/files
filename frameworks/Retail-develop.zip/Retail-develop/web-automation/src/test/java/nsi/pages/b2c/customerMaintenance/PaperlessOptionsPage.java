package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class PaperlessOptionsPage extends Pages {

    // Texts
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    @FindBy(xpath = "//*[@class='field--transparent']/label")
    private SelenideElement paperlessOption;

    // BUTTONS
    @FindBy(id = "editOtherOptionsButton")
    private SelenideElement changeButton;

    @FindBy(xpath = "//*[@data-label='Paperless']/input")
    private SelenideElement paperlessTickbox;

    @FindBy(id = "saveOther")
    private SelenideElement saveButton;

    @FindBy(xpath = "//p[contains(text(), 'Thank you')]")
    private SelenideElement thankYouHeader;

    @FindBy(id = "btnConfirm")
    private SelenideElement backToPaperlessButton;
}

