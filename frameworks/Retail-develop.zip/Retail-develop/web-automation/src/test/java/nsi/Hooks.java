package nsi;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.dao.DataBaseQueryies;
import nsi.dao.OperatorsDao;
import nsi.utils.JsonUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class Hooks {
    private final OperatorsDao operatorsDao = new OperatorsDao();

    @Before(order = 2)
    public void setup(Scenario sc) {
        baseConfig();
        getContext().setScenarioName(sc.getName());
        log.info("Start scenario: {}", sc.getName());
    }

    @After("@MWS")
    public void exitMWS(Scenario sc) {
        log.info("After MWS scenarios");
        genericAfter(sc);
    }

    @After("@B2N or @B2C or @B2O")
    public void exit(Scenario sc) throws IOException {
        log.info("After B2C, B2N, B2O scenarios");
        // -----cleaning operator session for B2N tests-----
        if (sc.getName().contains("B2N")) {
            for (String userId : getContext().getUserIds()) {
                operatorsDao.cleanOperatorSession(userId);
            }
        }
        getAccountMovementsAndSaveItToJson();
        genericAfter(sc);
    }

    private void genericAfter(Scenario sc) {
        // -----making screenshots------
        if (sc.isFailed()) {
            try {
                byte[] screenshot = ((TakesScreenshot) WebDriverRunner.getWebDriver()).getScreenshotAs(OutputType.BYTES);
                sc.embed(screenshot, "image/png", "screenshot");
            } catch (WebDriverException wde) {
                System.err.println(wde.getMessage());
            } catch (ClassCastException cce) {
                cce.printStackTrace();
            }
        }

        // -----clear cache and close webdriver------
        WebDriverRunner.clearBrowserCache();
        WebDriverRunner.closeWebDriver();

        // -----log scenario name------
        log.info("Finished scenario: {}", sc.getName());
    }

    private void baseConfig() {
        Configuration.driverManagerEnabled = false;
        Configuration.pageLoadStrategy = "eager";
        Configuration.fastSetValue = true;
//        Configuration.reportsFolder = "target/screenshots/";
        Configuration.timeout = 60000;
        Configuration.browser = "chrome";
        Configuration.startMaximized = false;
        Configuration.browserSize = "1920x4000";
        Configuration.screenshots = false;
        Configuration.savePageSource = false;
    }

    private void getAccountMovementsAndSaveItToJson() throws IOException {
        List<Map<String, Object>> accountMovements = new DataBaseQueryies().getAccountMovements();
        getContext().setAccountMovements(accountMovements);
        JsonUtils.writeContextToJsonfile(getContext());
    }
}