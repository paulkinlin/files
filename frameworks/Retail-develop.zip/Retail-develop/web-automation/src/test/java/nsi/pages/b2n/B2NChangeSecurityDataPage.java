package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeSecurityDataPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Cb01")
    private SelenideElement dataTypeSelect;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}
