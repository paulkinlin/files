package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class SecurityPage extends Pages {

    // FIELDS
    @FindBy(id = "password")
    private SelenideElement passwordField;

    @FindBy(id = "passwordMatchingVerification")
    private SelenideElement confirmPasswordField;

    @FindBy(id = "emailAddress")
    private SelenideElement emailField;

    @FindBy(id = "confirmEmailAddress")
    private SelenideElement confirmEmailField;

    @FindBy(id = "telephoneNumberOne1")
    private SelenideElement phoneNo1Field;

    @FindBy(id = "nationalInsuranceNumber_part1")
    private SelenideElement nino1Field;

    @FindBy(id = "nationalInsuranceNumber_part2")
    private SelenideElement nino2Field;

    @FindBy(id = "nationalInsuranceNumber_part3")
    private SelenideElement nino3Field;

    @FindBy(id = "nationalInsuranceNumber_part4")
    private SelenideElement nino4Field;

    @FindBy(id = "nationalInsuranceNumber_part5")
    private SelenideElement nino5Field;

    @FindBy(id = "securityAnswer1")
    private SelenideElement answer1Field;

    @FindBy(id = "securityAnswer2")
    private SelenideElement answer2Field;

    @FindBy(id = "securityAnswer3")
    private SelenideElement answer3Field;

    @FindBy(id = "birthCity")
    private SelenideElement taxBirthCitySecondInvestorField;

    @FindBy(id = "taxIdentificationNumber")
    private SelenideElement taxIDSecondInvestorField;

    // DROPDOWNS
    @FindBy(id = "telephoneCountryCodeOne1")
    private SelenideElement countryCode1Select;

    @FindBy(id = "securityQuestion1")
    private SelenideElement question1Select;

    @FindBy(id = "securityQuestion2")
    private SelenideElement question2Select;

    @FindBy(id = "securityQuestion3")
    private SelenideElement question3Select;

    @FindBy(id = "birthCountry")
    private SelenideElement taxBirthCountrySecondInvestorSelect;

    @FindBy(id = "taxCountry")
    private SelenideElement taxCountrySecondInvestorSelect;

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='accountOwnership:0']")
    private SelenideElement under18Radio;

    @FindBy(xpath = "//label[@for='accountOwnership:1']")
    private SelenideElement forMyselfRadio;

    @FindBy(xpath = "//label[@for='residentNonUK_2:1']")
    private SelenideElement taxNonUKNOSecondInvestorRadio;

    @FindBy(xpath = "//label[@for='residentNonUK_2:0']")
    private SelenideElement taxNonUKYESSecondInvestorRadio;

    // CHECKBOXES
    @FindBy(xpath = "(//label[@for='marketingByPost01'])[2]")
    private SelenideElement noPostCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByEmail01'])[2]")
    private SelenideElement noEmailCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByPhone01'])[2]")
    private SelenideElement noPhoneCheckbox;

    @FindBy(xpath = "(//label[@for='marketingOnline01'])[2]")
    private SelenideElement noWebCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByPost02'])[2]")
    private SelenideElement noPostSecondInvestorCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByEmail02'])[2]")
    private SelenideElement noEmailSecondInvestorCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByPhone02'])[2]")
    private SelenideElement noPhoneSecondInvestorCheckbox;

    @FindBy(xpath = "(//label[@for='marketingOnline02'])[2]")
    private SelenideElement noWebSecondInvestorCheckbox;

    // BUTTONS
    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    // TEXTS
    @FindBy(xpath = "//span[contains(@id, 'password-error')]")
    private SelenideElement passwordFieldError;

    @FindBy(xpath = "//span[contains(@id, 'passwordMatchingVerification-error')]")
    private SelenideElement confirmPwdFieldError;

    @FindBy(xpath = "//span[contains(@id, 'securityQuestion1-error')]")
    private SelenideElement securityQuestion1Error;

    @FindBy(xpath = "//span[contains(@id, 'securityQuestion2-error')]")
    private SelenideElement securityQuestion2Error;

    @FindBy(xpath = "//span[contains(@id, 'securityQuestion3-error')]")
    private SelenideElement securityQuestion3Error;

    @FindBy(xpath = "//span[contains(@id, 'securityAnswer1-error')]")
    private SelenideElement securityAnswer1Error;

    @FindBy(xpath = "//span[contains(@id, 'securityAnswer2-error')]")
    private SelenideElement securityAnswer2Error;

    @FindBy(xpath = "//span[contains(@id, 'securityAnswer3-error')]")
    private SelenideElement securityAnswer3Error;

    @FindBy(xpath = "//span[contains(@id, 'emailAddress-error')]")
    private SelenideElement emailAddressFieldError;

    @FindBy(xpath = "//span[contains(@id, 'confirmEmailAddress-error')]")
    private SelenideElement emailConfAddressFieldError;

    // ----------------------------------------------------
}