package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NTransactionAuthorisedPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//p[@class='PROMPT']")
    private SelenideElement titleText;

    @FindBy(xpath = "//p[contains(text(), 'Application reference')]")
    private SelenideElement referenceText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm84")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
