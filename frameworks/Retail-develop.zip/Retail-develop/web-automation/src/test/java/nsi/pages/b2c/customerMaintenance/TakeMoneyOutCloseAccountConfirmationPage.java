package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class TakeMoneyOutCloseAccountConfirmationPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    @FindBy(id = "movementAmount")
    private SelenideElement currentBalanceText;

    @FindBy(id = "fromAccount")
    private SelenideElement fromAccountText;

    @FindBy(id = "toAccount")
    private SelenideElement toAccountText;

    @FindBy(tagName = "h2")
    private SelenideElement header;

    @FindBy(id = "requestedAmount")
    private SelenideElement requestedAmountText;

    @FindBy(id = "interestAmount")
    private SelenideElement interestAmountText;

    @FindBy(id = "totalAmountClosure")
    private SelenideElement amountToBePaidText;

    @FindBy(css = "#challengeDataDiv h2")
    private SelenideElement confirmPhoneNoText;

    // RADIOBUTTONS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}