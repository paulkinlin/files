package nsi.steps.b2c.initialSale;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.dao.ClientDao;
import nsi.pages.b2c.initialSale.PaymentDetailsPage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static com.codeborne.selenide.Selenide.switchTo;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;


@Slf4j
public class PaymentDetailsSteps extends Steps {

    private final PaymentDetailsPage paymentDetailsPage = page(PaymentDetailsPage.class);
    private final ClientDao clientDao = new ClientDao();


    @Given("PaymentDetailsPage: click continue")
    public void InitialSalePaymentSubmitData() {
        paymentDetailsPage.getContinueButton().click();
    }

    @And("PaymentDetailsPage: click confirm")
    public void nsiinitialsaleClickContinue() {
        paymentDetailsPage.getConfirmButton().click();
    }

    @Then("PaymentDetailsPage: is submit form visible")
    public void initialsalepaymentIsSubmitFormVisible() {
        waitUntilPageIsDisplayedAndClickPayNowButton();

        paymentDetailsPage.getNsiNumberText().execute(waitUntilVisible);

        getContext().setNsiNumber(paymentDetailsPage.getNsiNumberText().getText()
                .substring(0, paymentDetailsPage.getNsiNumberText().getText().indexOf("(") - 1)
                .replaceAll("\\s",""));

        getContext().setClientNumber(clientDao.getExistingClientNumber(getContext().getNsiNumber()));
        if(!(getContext().getProductPojoList().getLast() instanceof PremiumBondProduct)) {
            getContext()
                    .getProductPojoList()
                    .getLast()
                    .setAccountNumber(paymentDetailsPage.getAccountNumberText().getText());
        } else {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList()
                    .getLast())
                    .setHoldersNumber(paymentDetailsPage.getAccountNumberText().getText()); }
        getContext().getProductPojoList().getLast().setAmount(paymentDetailsPage.getTotalAmountText().getText());
        getContext().getProductPojoList().getLast().setReferenceNumber(paymentDetailsPage.getReferenceNumber().getText());
        getContext().getProductPojoList().getLast().setProduct(paymentDetailsPage.getConfirmationText().getText()
                .replaceAll("\\s+", "")
                .replaceAll("Your", "")
                .replaceAll("applicationdetails", "")
                .replaceAll("Print", ""));

    }

    @Then("PaymentDetailsPage: is submit form visible Premium Bonds for someone child")
    public void initialsalepaymentIsSubmitFormVisiblePBForSomeoneChild() {
        waitUntilPageIsDisplayedAndClickPayNowButton();

        paymentDetailsPage.getNsiNumberPBSomeoneChildText().execute(waitUntilVisible);

        getContext().setNsiNumber(paymentDetailsPage.getNsiNumberPBSomeoneChildText().getText()
                .substring(0, paymentDetailsPage.getNsiNumberPBSomeoneChildText().getText().indexOf("(") - 1)
                .replaceAll("\\s",""));
        getContext().setClientNumber(clientDao.getExistingClientNumber(getContext().getNsiNumber()));
    }

    @Then("PaymentDetailsPage: is submit form visible for existing customer")
    public void initialsalepaymentIsSubmitFormVisibleForExistingCustomer() {
        waitUntilPageIsDisplayedAndClickPayNowButton();
    }

    public void waitUntilPageIsDisplayedAndClickPayNowButton() {
        paymentDetailsPage.getPaymentDetailsPageTitleText().shouldBe(Condition.visible);
        switchTo().frame(paymentDetailsPage.getFrameFirstContent());
        paymentDetailsPage.getPayNowButton().execute(clickAndWait);
    }

    @When("PaymentDetailsPage: choose your way to pay {string}")
    public void investmentDetailsPageChooseYourNominatedAccounts(String option) {
        switch (option.toLowerCase()) {
            case "pay by debit card":
                paymentDetailsPage.getPayByDebitCardRadio().click();
                paymentDetailsPage.getPayByDebitCardConfirmationRadio().execute(waitUntilIsSelected);
                paymentDetailsPage.getContinueButton().click();
                waitUntilPageIsDisplayedAndClickPayNowButton();
                break;
            case "pay from another ns&i account":
                paymentDetailsPage.getPayFromAnotherNSIAccRadio().execute(clickAndWait);
                paymentDetailsPage.getCheckDirectSaverAccRadio().execute(waitUntilVisible).click();
                paymentDetailsPage.getCheckDirectSaverAccConfirmationRadio().execute(waitUntilIsSelected);
                paymentDetailsPage.getContinueButton().click();
                break;
            case "click pay now button":
                waitUntilPageIsDisplayedAndClickPayNowButton();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }
}