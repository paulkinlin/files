package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSecurityChangePage extends Pages {

    // TEXTS
    @FindBy(id = "Tx01")
    private SelenideElement passwordText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS

    // ----------------------------------------------------
}
