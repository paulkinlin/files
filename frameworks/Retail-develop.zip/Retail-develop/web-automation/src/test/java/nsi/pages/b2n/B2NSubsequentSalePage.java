package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSubsequentSalePage extends Pages {

    // TEXTS
    @FindBy(id = "Tx01")
    private SelenideElement accountNumberText;

    @FindBy(id = "Tx02")
    private SelenideElement currentBalanceText;

    @FindBy(id = "Tx04")
    private SelenideElement headroomText;

    // FIELDS
    @FindBy(id = "Cb01")
    private SelenideElement accountNumberSelect;

    @FindBy(id = "Cb02")
    private SelenideElement mediaCodeSelect;

    @FindBy(id = "Ed01")
    private SelenideElement amountField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm82")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}
