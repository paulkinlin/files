package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.TakeMoneyOutCloseAccountPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class TakeMoneyOutCloseAccountSteps extends Steps {

    private TakeMoneyOutCloseAccountPage takeMoneyOutCloseAccountPage = page(TakeMoneyOutCloseAccountPage.class);

    @And("TakeMoneyOutCloseAccountPage: check header")
    public void takemoneyoutCloseAccountText() {
        takeMoneyOutCloseAccountPage.getTitleText().shouldHave(Condition.exactText("Do you want to close your account?"));
    }

    @And("TakeMoneyOutCloseAccountPage: choose continue with transfer")
    public void takemoneyoutChooseContinueWithTransfer() {
        takeMoneyOutCloseAccountPage.getContinueWithTransferText().click();
        takeMoneyOutCloseAccountPage.getNextButton().click();
    }

    @And("TakeMoneyOutCloseAccountPage: select to close account")
    public void takemoneyoutcloseaccountpageSelectCloseAccount() {
        takeMoneyOutCloseAccountPage.getCloseMyAccountText().click();
        takeMoneyOutCloseAccountPage.getNextButton().click();
    }

    @And("TakeMoneyOutCloseAccountPage: choose account closure")
    public void takemoneyoutCloseAccountConfirm() {
        takeMoneyOutCloseAccountPage.getYesCloseAccountRadio().click();
        takeMoneyOutCloseAccountPage.getNextButton().click();
    }
}