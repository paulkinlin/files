package nsi.pojos.products;

public class IGGIBProduct extends ProductPojo {
}
