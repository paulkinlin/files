package nsi.pages.MWS;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class Bold360Page extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[@class='bc-workitem-chat-list']/ul[@class='bc-workitem-titles-list']")
    private SelenideElement message;

    @FindBy(xpath = "//div[@data-automation-id='CANNED_MESSAGES']//virtual-scroller//div[@class='ng-star-inserted']")
    private SelenideElement agentFirstPredefinedMessage;

    @FindBy(xpath = "//body[@id='tinymce']/p")
    private SelenideElement agentMessageTextArea;

    @FindBy(xpath = "//div[@role='alert' and contains(@class, 'bc-ended-message')]/span")
    private SelenideElement endChatAlert;

    // FIELDS
    @FindBy(id = "emailAddress")
    private SelenideElement loginInput;

    @FindBy(id = "password")
    private SelenideElement passwordInput;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "next-button")
    private SelenideElement nextButton;

    @FindBy(id = "submit")
    private SelenideElement signInButton;

    @FindBy(id = "chat-buttons-end-chat")
    private SelenideElement endChatButton;

    @FindBy(xpath = "//app-confirmation-modal//button")
    private SelenideElement confirmEndChatButton;

    // LINKS
    @FindBy(xpath = "//div[@data-automation-id='operator-service-status-chats']")
    private SelenideElement operatorStatusServiceLink;

    @FindBy(xpath = "//workitem-answer-next/div")
    private SelenideElement takeNextQueuedChat;
}
