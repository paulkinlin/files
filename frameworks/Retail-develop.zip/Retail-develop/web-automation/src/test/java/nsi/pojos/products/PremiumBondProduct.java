package nsi.pojos.products;

import lombok.Data;

@Data
public class PremiumBondProduct extends ProductPojo {
    private String prizeNotification;
    private String holdersNumber;
    private String pbInvestDetails = "Pay to my nominated account";
}
