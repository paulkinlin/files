package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeTextPreferencesPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NChangeTextPreferencesSteps extends Steps {

    private B2NChangeTextPreferencesPage b2NChangeTextPreferencesPage = page(B2NChangeTextPreferencesPage.class);

    @And("B2NChangeTextPreferencesPage: submit Allow {string} Stop {string}")
    public void changetextpreferencespageSubmitAllowStop(String allow, String stop) {
        switchToFrame("dynamic");

        if (allow.equals("y")) {
            b2NChangeTextPreferencesPage.getAllowCheckbox().click();
            b2NChangeTextPreferencesPage.getAllowCheckbox().shouldBe(Condition.selected);

        }
        if (stop.equals("y")) {
            b2NChangeTextPreferencesPage.getStopCheckbox().click();
            b2NChangeTextPreferencesPage.getStopCheckbox().shouldBe(Condition.selected);

        }

        log.info("ChangeTextPreferencesPage submit Allow '{}' Stop '{}'", allow, stop);

        b2NChangeTextPreferencesPage.getConfirmButton().click();
    }
}
