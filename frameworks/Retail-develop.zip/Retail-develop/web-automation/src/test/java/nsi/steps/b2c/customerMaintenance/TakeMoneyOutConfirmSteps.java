package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.TakeMoneyOutConfirmPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class TakeMoneyOutConfirmSteps extends Steps {

    private TakeMoneyOutConfirmPage takeMoneyOutConfirmPage = page(TakeMoneyOutConfirmPage.class);

    @And("TakeMoneyOutPage: click confirm")
    public void takemoneyoutConfirm() {
        takeMoneyOutConfirmPage.getTitleText().shouldHave(Condition.text("Take money out - please confirm"));
        takeMoneyOutConfirmPage.getNextButton().click();
    }
}