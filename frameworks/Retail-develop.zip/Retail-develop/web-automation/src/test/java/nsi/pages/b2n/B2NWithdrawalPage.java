package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NWithdrawalPage extends Pages {

    // TEXTS

    @FindBy(xpath = "//form[@name='form1']")
    private SelenideElement pageTitle;

    @FindBy(id = "Tx01")
    private SelenideElement balanceAmount;

    @FindBy(id = "Tx03")
    private SelenideElement paymentChannelSelected;

    @FindBy(id = "Tx04")
    private SelenideElement paymentModeSelected;

    @FindBy(id = "Tx05")
    private SelenideElement amountRequested;

    // FIELDS
    @FindBy(id = "Ed05")
    private SelenideElement amountRequestedField;

    // DROPDOWNS
    @FindBy(id = "Cb01")
    private SelenideElement accountNumberSelect;

    @FindBy(id = "Cb02")
    private SelenideElement paymentChannelSelect;

    @FindBy(id = "Cb03")
    private SelenideElement paymentModeSelect;

    @FindBy(id = "Cb04")
    private SelenideElement reinvestmentToAccountNumberSelect;

    @FindBy(id = "Cb05")
    private SelenideElement accountTypeSelect;

    @FindBy(xpath = "(//fieldset//td[not(contains(@class, 'OUTPUT'))])[1]")
    private SelenideElement questionOneField;

    @FindBy(id = "Ed01")
    private SelenideElement answerOneField;

    @FindBy(xpath = "(//fieldset//td[not(contains(@class, 'OUTPUT'))])[2]")
    private SelenideElement questionTwoField;

    @FindBy(id = "Ed02")
    private SelenideElement answerTwoField;

    // CHECKBOXES
    @FindBy(id = "Ck01")
    private SelenideElement manualInputCheckbox;

    // BUTTONS
    @FindBy(xpath = "//input[@value='Next']")
    private SelenideElement nextButton;

    @FindBy(xpath = "//input[@value='Confirm']")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
