package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NSalesSummaryPage;
import nsi.steps.Steps;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NSalesSummarySteps extends Steps {

    private final B2NSalesSummaryPage b2NSalesSummaryPage = page(B2NSalesSummaryPage.class);

    @And("B2NSalesSummaryPage: check sales reference number with json {string}")
    public void salessummarypageCheckSalesRefNumber(String jsonFile) throws IOException, ParseException {
        switchToFrame("dynamic");
        verifyPageTitle("Sales summary");

        String salesRefNo = getContext().getProductPojoList().getLast().getReferenceNumber();
        b2NSalesSummaryPage.getSaleRefPRNText().execute(waitUntilVisible).shouldHave(Condition.text(salesRefNo));
    }

    @And("B2NSalesSummaryPage: check sales status {string} product {string} and amount {string}")
    public void salessummarypageCheckSalesStatusProductAmount(String status, String product, String amount) {
        switchToFrame("dynamic");
        verifyPageTitle("Sales summary");

        b2NSalesSummaryPage.getStatusText().execute(waitUntilVisible).shouldHave(Condition.text(status));
        b2NSalesSummaryPage.getProductText().shouldHave(Condition.text(product));
        b2NSalesSummaryPage.getAmountText().shouldHave(Condition.text(amount));
    }

    @And("B2NSalesSummaryPage: click back")
    public void salessummarypageClickBack() {
        switchToFrame("dynamic");
        verifyPageTitle("Sales summary");

        b2NSalesSummaryPage.getBackButton().click();
    }
}