package nsi.pages.MWS;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChatbotPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[@class='welcome-msg']/p[1]")
    private SelenideElement welcomeMessage;

    @FindBy(xpath = "//div[@class='welcome-msg']/p[2]")
    private SelenideElement hoursOfServiceMessage;

    @FindBy(xpath = "(//div[@class='conversation-entry-bot__message-body'])[last()]")
    private SelenideElement lastResponseMessage;

    @FindBy(xpath = "(//div[@class='conversation-entry-user__message'])[last()]")
    private SelenideElement lastRequestMessage;

    @FindBy(xpath = "(//div[@class='conversation-log__entry']/div[contains(@class, 'conversation-entry-bot--agent')])[last()]")
    private SelenideElement lastHumanResponse;

    @FindBy(xpath = "(//div[@class='conversation-log__entry']/div[contains(@class, 'conversation-entry-bot--mounted')])[last()]")
    private SelenideElement lastBotResponse;

    @FindBy(xpath = "//time[@class='conversation-timestamp']")
    private ElementsCollection timeStampLabels;

    @FindBy(xpath = "(//form[contains(@class, 'pre-chat__custom-form')]//textarea)[1]")
    private SelenideElement messageTextarea;

    @FindBy(xpath = "//strong[@id='nrConfirmDialog_17']/p")
    private SelenideElement endConversationMessage;

    // FIELDS
    @FindBy(className = "query-field__input")
    private SelenideElement queryInput;

    @FindBy(xpath = "(//form[contains(@class, 'pre-chat__custom-form')]//input[@type='text'])[1]")
    private SelenideElement nameInput;

    // DROPDOWNS
    @FindBy(xpath = "(//form[contains(@class, 'pre-chat__custom-form')]//select)[1]")
    private SelenideElement productSelect;

    // CHECKBOXES
    @FindBy(xpath = "(//form[contains(@class, 'pre-chat__custom-form')]//input[@type='radio'])[1]")
    private SelenideElement yesIUnderstandAndAgreeRadio;
    
    // BUTTONS
    @FindBy(xpath = "//button[contains(@class, 'conversation-choices')]")
    private ElementsCollection defaultQueryContainer;

    @FindBy(xpath = "//i[contains(@class, 'thumb-negative')]")
    private SelenideElement thumbDownButton;

    @FindBy(xpath = "//i[contains(@class, 'thumb-positive')]")
    private SelenideElement thumbUpButton;

    @FindBy(className = "conversation-buttons")
    private SelenideElement conversationButtonsContainer;

    @FindBy(xpath = "//button[contains(@data-channel-name,'Live agent TWS (SIT')]")
    private SelenideElement liveChatButton;

    @FindBy(className = "query-field__button--send")
    private SelenideElement querySendButton;

    @FindBy(xpath = "//button[contains(@class, 'widget-floating__button--increase')]")
    private SelenideElement increaseButton;

    @FindBy(xpath = "//button[contains(@class, 'widget-floating__button--decrease')]")
    private SelenideElement decreaseButton;

    @FindBy(xpath = "//button[contains(@class, 'widget-floating__button--collapse')]")
    private SelenideElement collapseButton;

    @FindBy(xpath = "//button[contains(@class, 'widget-floating__button--close')]")
    private SelenideElement closeButton;

    @FindBy(xpath = "//button[contains(@class, 'transcript-btn')]")
    private SelenideElement downloadTranscriptButton;

    @FindBy(xpath = "//a[contains(@class, 'feedback-btn')]")
    private SelenideElement leaveFeedbackButton;

    @FindBy(xpath = "//div[@class='confirmation-dialog__buttons']/button[not(contains(@class, 'button--yes'))]")
    private SelenideElement endConversationContinueButton;

    @FindBy(xpath = "//div[@class='confirmation-dialog__buttons']/button[contains(@class, 'button--yes')]")
    private SelenideElement endConversationCloseButton;

    @FindBy(xpath = "//button[contains(@data-channel-name,'Live agent TWS (SIT')]")
    private SelenideElement chatToSomeoneButton;

    @FindBy(xpath = "//form[contains(@class, 'bc-form')]//button[@type='submit']")
    private SelenideElement startChatButton;

    @FindBy(xpath = "//button[.='Close' and contains(@class, 'bc-button')]")
    private SelenideElement chatCloseButton;

    // LINKS

    // OTHERS
    @FindBy(className = "widget-floating__wrapper")
    private SelenideElement widgetWrapper;

    @FindBy(className = "conversation-ui")
    private SelenideElement chatbotContainer;
}
