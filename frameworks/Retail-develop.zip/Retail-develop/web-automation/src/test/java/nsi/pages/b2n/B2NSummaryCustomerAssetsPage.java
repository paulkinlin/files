package nsi.pages.b2n;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSummaryCustomerAssetsPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//table[@id = 'Ta01']//tr[contains(@id, 'row')]/td[2]")
    private ElementsCollection productsTexts;

    // FIELDS
    @FindBy(id = "Ta01")
    private SelenideElement summaryTable;

    @FindBy(xpath = "//*[@id='Ta01']//*[contains(@class, 'COLS0')]")
    private SelenideElement noItemsSummaryTable;

    @FindBy(xpath = "//tr[@id='row01']/child::td[2]")
    private SelenideElement productText;

    @FindBy(xpath = "//tr[@id='row01']/child::td[3]")
    private SelenideElement holdingAccountText;

    @FindBy(xpath = "//tr[@id='row01']/child::td[4]")
    private SelenideElement totalValueText;

    @FindBy(xpath = "//tr[@id='row01']/child::td[6]")
    private SelenideElement headroomText;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm80")
    private SelenideElement nextButton;

    @FindBy(xpath = "//a[@href='javascript:submitForm(03)']")
    private SelenideElement backButton;

    @FindBy(id = "Subm04")
    private SelenideElement detailedViewButton;

    @FindBy(id = "Subm11")
    private SelenideElement customerDetailsButton;

    // LINKS
    // ----------------------------------------------------
}
