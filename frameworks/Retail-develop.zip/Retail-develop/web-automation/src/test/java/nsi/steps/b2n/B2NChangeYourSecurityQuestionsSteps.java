package nsi.steps.b2n;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeYourSecurityQuestionsPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NChangeYourSecurityQuestionsSteps extends Steps {

    private B2NChangeYourSecurityQuestionsPage b2NChangeYourSecurityQuestionsPage = page(B2NChangeYourSecurityQuestionsPage.class);

    @And("B2NChangeYourSecurityQuestionsPage: submit questions and answers")
    public void changeyoursecurityquestionspageSubmitQuestionsAndAnswers() {
        switchToFrame("dynamic");
        verifyPageTitle("Change your security questions");

        final int sizeQuestionsOneSelect = (b2NChangeYourSecurityQuestionsPage.getQuestionOneSelect().$$(By.tagName("option"))).size() - 1;
        final int sizeQuestionsTwoSelect = (b2NChangeYourSecurityQuestionsPage.getQuestionTwoSelect().$$(By.tagName("option"))).size() - 1;
        final int sizeQuestionsThreeSelect = (b2NChangeYourSecurityQuestionsPage.getQuestionThreeSelect().$$(By.tagName("option"))).size() - 1;

        String questionOne;
        String questionTwo;
        String questionThree;

        b2NChangeYourSecurityQuestionsPage.getQuestionOneSelect().selectOption(new Faker().number().numberBetween(1, sizeQuestionsOneSelect));
        questionOne = b2NChangeYourSecurityQuestionsPage.getQuestionOneSelect().getSelectedText()
                .replaceAll("\\(([\\s\\S]*)\\)", "")
                .replace("?", "")
                .trim();

        do {
            b2NChangeYourSecurityQuestionsPage.getQuestionTwoSelect().selectOption(new Faker().number().numberBetween(1, sizeQuestionsTwoSelect));
            questionTwo = b2NChangeYourSecurityQuestionsPage.getQuestionTwoSelect().getSelectedText()
                    .replaceAll("\\(([\\s\\S]*)\\)", "")
                    .replace("?", "")
                    .trim();
        } while (questionTwo.equals(questionOne));

        do {
            b2NChangeYourSecurityQuestionsPage.getQuestionThreeSelect().selectOption(new Faker().number().numberBetween(1, sizeQuestionsThreeSelect));
            questionThree = b2NChangeYourSecurityQuestionsPage.getQuestionThreeSelect().getSelectedText()
                    .replaceAll("\\(([\\s\\S]*)\\)", "")
                    .replace("?", "")
                    .trim();
        } while (questionThree.equals(questionOne) || questionThree.equals(questionTwo));

        String answerOne = questionOne.substring(questionOne.lastIndexOf(' ') + 1);
        String answerTwo = questionTwo.substring(questionTwo.lastIndexOf(' ') + 1);
        String answerThree = questionThree.substring(questionThree.lastIndexOf(' ') + 1);

        b2NChangeYourSecurityQuestionsPage.getAnswerOneField().execute(clearAndSetValue(answerOne));
        b2NChangeYourSecurityQuestionsPage.getAnswerTwoField().execute(clearAndSetValue(answerTwo));
        b2NChangeYourSecurityQuestionsPage.getAnswerThreeField().execute(clearAndSetValue(answerThree));

        b2NChangeYourSecurityQuestionsPage.getConfirmButton().click();
    }
}
