package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourMarketingPrefsPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//h1[contains(., 'Change your marketing preferences')]")
    private SelenideElement titleText;

    @FindBy(xpath = "//div[@id='emailAddress']//div")
    private SelenideElement currentEmailText;

    // CHECKBOXES
    @FindBy(xpath = "(//label[@for='marketingByPost:0'])")
    private SelenideElement yesPostCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByPost:1'])")
    private SelenideElement noPostCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByEmail:0'])")
    private SelenideElement yesEmailCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByEmail:1'])")
    private SelenideElement noEmailCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByPhone:0'])")
    private SelenideElement yesPhoneCheckbox;

    @FindBy(xpath = "(//label[@for='marketingByPhone:1'])")
    private SelenideElement noPhoneCheckbox;

    @FindBy(xpath = "(//label[@for='marketingOnline:0'])")
    private SelenideElement yesWebCheckbox;

    @FindBy(xpath = "(//label[@for='marketingOnline:1'])")
    private SelenideElement noWebCheckbox;

    // FIELDS

    // DROPDOWNS

    // BUTTONS
    @FindBy(xpath = "//*[@id='btnNext']")
    private SelenideElement confirmButton;
}