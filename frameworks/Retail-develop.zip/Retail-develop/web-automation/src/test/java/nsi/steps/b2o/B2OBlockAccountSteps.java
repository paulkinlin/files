package nsi.steps.b2o;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import nsi.pages.b2o.B2OBlockAccountPage;
import nsi.steps.Steps;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

public class B2OBlockAccountSteps extends Steps {

    private final B2OBlockAccountPage b2OBlockAccountPage = page(B2OBlockAccountPage.class);

    @When("B2OBlockAccountPage: Search field submit account number from context")
    public void b2OSearchFieldAccountNumberSubmit() {
        String accountNumber = getContext().getAccountNumber();
        b2OBlockAccountPage.getAccountNumberSearchField()
                .shouldBe(Condition.and("",Condition.visible, Condition.enabled))
                .setValue(accountNumber)
                .pressEnter();
    }

    @And("B2OBlockAccountPage: Select blocking reason code {}")
    public void b2OSelectBlockingReason(String blockingReason){
        b2OBlockAccountPage.getBlockingReasonDropdown()
                .shouldBe(Condition.and("", Condition.visible, Condition.enabled))
                .setValue(String.valueOf(blockingReason))
                .pressEnter();
    }

    @And("B2OBlockAccountPage: Validate associated blocking code {} and blocking label {}")
    public void b2OValidateAssociatedBlockingReasonValues(String associatedCode, String associatedLabel){
        b2OBlockAccountPage.getAssociatedBlockingCode().shouldHave(Condition.text(associatedCode));
        b2OBlockAccountPage.getAssociatedBlockingCodeLabel().shouldHave(Condition.text(associatedLabel));
        b2OBlockAccountPage.getBlockAccountConfirmButton().click();
    }
}
