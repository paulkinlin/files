package nsi.pages.b2o;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2OBlockAccountPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "accountNumber")
    private SelenideElement accountNumberSearchField;

    @FindBy(id = "associatedBlockingCode")
    private SelenideElement associatedBlockingCode;

    @FindBy(id = "associatedBlockingCode_libelle")
    private SelenideElement associatedBlockingCodeLabel;

    // DROPDOWNS
    @FindBy(id = "blockingReason_1")
    private SelenideElement blockingReasonDropdown;


    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnConfirm")
    private SelenideElement blockAccountConfirmButton;

    // LINKS

    // ----------------------------------------------------
}