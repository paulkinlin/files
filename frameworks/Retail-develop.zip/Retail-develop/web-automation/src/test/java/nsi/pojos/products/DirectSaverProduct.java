package nsi.pojos.products;

public class DirectSaverProduct extends ProductPojo {

}
