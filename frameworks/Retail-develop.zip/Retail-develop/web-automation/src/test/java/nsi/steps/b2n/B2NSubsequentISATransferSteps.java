package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NSubsequentISATransferPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NSubsequentISATransferSteps extends Steps {

    private B2NSubsequentISATransferPage b2NSubsequentISATransferPage = page(B2NSubsequentISATransferPage.class);

    @And("B2NSubsequentISATransferPage select first account")
    public void subsequentisatransferpageSelectFirstAccount() {
        switchToFrame("dynamic");

        b2NSubsequentISATransferPage.getAccountNumberSelect().selectOption(1);
    }

    @And("B2NSubsequentISATransferPage click button {string}")
    public void subsequentisatransferpageClickButton(String buttonName) {
        switchToFrame("dynamic");

        switch (buttonName.toLowerCase()) {
            case "next":
                b2NSubsequentISATransferPage.getNextButton().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }
}
