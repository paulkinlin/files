package nsi.pojos.products;

public class SetUpProductB2N {
    public  <T extends ProductPojo> T returnProductObject(String product) {
        switch (product){
            case "Premium Bonds":
                return (T) new PremiumBondProduct();
            case "Direct Saver":
                return (T) new DirectSaverProduct();
            case "DISA":
                return (T) new DISAProduct();
            case "Income Bonds":
                return (T) new IncomeBondProduct();
            case "Junior ISA":
                return (T) new JisaProduct();
            default:
                return null;
        }
    }
}