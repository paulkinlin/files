package nsi.pojos.products;

public class GEBProduct extends ProductPojo {
}
