package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import nsi.pages.b2c.customerMaintenance.CashInCloseAccountConfirmationPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class CashInCloseAccountConfirmationSteps extends Steps {

    private CashInCloseAccountConfirmationPage cashInCloseAccountConfirmationPage = page(CashInCloseAccountConfirmationPage.class);

    @And("CashInCloseAccountConfirmationPage: verify account closure confirmation")
    public void cashInCloseAccountConfirmationConfirm() {
        cashInCloseAccountConfirmationPage.getTitleText().shouldHave(Condition.exactText("Confirm your account closure"));
    }
}