package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeSecurityDataPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NChangeSecurityDataSteps extends Steps {

    private B2NChangeSecurityDataPage b2NChangeSecurityDataPage = page(B2NChangeSecurityDataPage.class);

    @And("B2NChangeSecurityDataPage: select {string}")
    public void changesecuritydatapageSelect(String option) {
        switchToFrame("dynamic");
        verifyPageTitle("Change security data");
        b2NChangeSecurityDataPage.getDataTypeSelect().selectOption(option);
        b2NChangeSecurityDataPage.getDataTypeSelect().getSelectedOption().shouldHave(Condition.text(option));
        b2NChangeSecurityDataPage.getNextButton().click();
    }
}
