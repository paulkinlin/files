package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.ChangeYourTaxDetailsPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class ChangeYourTaxDetailsSteps extends Steps {
    public static String taxNonUK;
    public static String city;
    public static String country;
    public static String taxCountry;
    public static String tinNumber;

    private ChangeYourTaxDetailsPage changeYourTaxDetailsPage = page(ChangeYourTaxDetailsPage.class);

    @And("ChangeYourTaxDetailsPage: fill tax nonUK {string} city {string} country {string} tax country {string} tin {string} tinNumber {string}")
    public void fillYourTaxDetails(String nonUK, String city, String country, String taxCountry,
                                   String tin, String tinNumber) {
        switch (nonUK.toLowerCase()) {
            case "yes":
                changeYourTaxDetailsPage.getTaxNonUKYESRadio().click();
                changeYourTaxDetailsPage.getTaxBirthCityMainInvestorField().execute(clearAndSetValue(city));
                changeYourTaxDetailsPage.getTaxBirthCountryMainInvestorSelect().selectOptionContainingText(country);
                changeYourTaxDetailsPage.getTaxCountryMainInvestorSelect().selectOptionContainingText(taxCountry);
                ChangeYourTaxDetailsSteps.taxNonUK = nonUK;
                ChangeYourTaxDetailsSteps.city = city;
                ChangeYourTaxDetailsSteps.country = country;
                ChangeYourTaxDetailsSteps.taxCountry = taxCountry;
                switch (tin.toLowerCase()) {
                    case "yes":
                        changeYourTaxDetailsPage.getTaxIDMainInvestorField().execute(clearAndSetValue(tinNumber));
                        ChangeYourTaxDetailsSteps.tinNumber = tinNumber;
                        break;
                    case "no":
                        changeYourTaxDetailsPage.getTinCheckbox().click();
                        break;
                    default:
                        Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
                }
                break;
            case "no":
                changeYourTaxDetailsPage.getTaxNonUKNORadio().click();
                ChangeYourTaxDetailsSteps.taxNonUK = nonUK;
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @Then("ChangeYourTaxDetailsPage: click continue")
    public void thankYouUpdatedPhoneNoBackToYourDetails() {
        changeYourTaxDetailsPage.getContinueButton().click();
    }
}