package nsi.utils;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum AssertMessages {

    NO_CASE_FOUND("No case found / Bad input?"),
    JSON_FILE_DOES_NOT_EXISTS("JSON file does not exits"),
    PAGE_IS_NOT_DISPLAYED("Page is not displayed");

    private String text;

    @Override
    public String toString() {
        return this.text;
    }
}
