package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NSecurityValidationPage;
import nsi.steps.Steps;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NSecurityValidationSteps extends Steps {

    private final B2NSecurityValidationPage b2NSecurityValidationPage = page(B2NSecurityValidationPage.class);

    @And("B2NSecurityValidationPage: submit The numeric key from json {string}")
    public void securityvalidationpageSubmitTheNumericKey(String jsonFile) throws IOException, ParseException {
        switchToFrame("dynamic");
        verifyPageTitle("Security validation");

        String securityCode = getContext().getOperatorSecurityCode();

        b2NSecurityValidationPage.getNumericalKeyField().execute(clearAndSetValue(securityCode));

        b2NSecurityValidationPage.getNextButton().click();
    }

    @And("B2NSecurityValidationPage: submit The numeric key")
    public void securityvalidationpageSubmitTheNumericKey() {
        switchToFrame("dynamic");
        verifyPageTitle("Security validation");

        String securityCode = getContext().getOperatorSecurityCode();

        b2NSecurityValidationPage.getNumericalKeyField().execute(clearAndSetValue(securityCode));

        b2NSecurityValidationPage.getNextButton().click();
    }

    @And("B2NSecurityValidationPage: check security titles")
    public void securityvalidationpageCheckSecurityTitles() {
        switchToFrame("dynamic");
        verifyPageTitle("Security validation");
        verifyPageTitle("Security modification has been validated");
    }
}