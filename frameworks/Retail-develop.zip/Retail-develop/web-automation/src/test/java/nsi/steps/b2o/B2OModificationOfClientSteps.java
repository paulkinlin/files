package nsi.steps.b2o;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import nsi.pages.b2o.B2OModificationOfClientPage;
import nsi.steps.Steps;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

public class B2OModificationOfClientSteps extends Steps {

    private B2OModificationOfClientPage b2OModificationOfClientPage = page(B2OModificationOfClientPage.class);

    @When("B2OModificationOfClientPage: Client identity field submit client number from context")
    public void b2OIdentityFieldSubmit() {
        String clientNumber = getContext().getClientNumber();
        b2OModificationOfClientPage.getClientIdentityField()
                .shouldBe(Condition.and("",Condition.visible, Condition.enabled))
                .setValue(clientNumber)
                .pressEnter();
        b2OModificationOfClientPage.getNextButton().click();
    }

    @And("B2OModificationOfClientPage: Update client surname to {}")
    public void b2OUpdateClientSurname(String clientSurname){
        b2OModificationOfClientPage.getClientNameField()
                .shouldBe(Condition.and("", Condition.visible, Condition.enabled))
                .setValue(String.valueOf(clientSurname))
                .pressEnter();
    }

    @And("B2OModificationOfClientPage: Validate client short name field is updated with {}")
    public void b2OValidateClientShortName(String shortName){
        b2OModificationOfClientPage.getCustomerShortNameField().getValue().contains(shortName);
        b2OModificationOfClientPage.getConfirmButton().click();
    }
}
