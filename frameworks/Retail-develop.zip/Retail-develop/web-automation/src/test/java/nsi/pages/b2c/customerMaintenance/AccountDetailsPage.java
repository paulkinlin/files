package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class AccountDetailsPage extends Pages {

    // TEXTS
    @FindBy(xpath = "(//div[@class='column-1-3'])[1]")
    private SelenideElement mainPhoneNumberText;

    @FindBy(xpath = "(//div[@class='column-1-3'])[2]")
    private SelenideElement secondPhoneNumberText;

    @FindBy(xpath = "//h3[contains(text(),'Your email address')]/../..//div[@class='field field--content']")
    private SelenideElement emailText;

    @FindBy(xpath = "//label[@for='titleCode']/following-sibling::div")
    private SelenideElement titleText;

    @FindBy(xpath = "//label[@for='clientFirstName']/following-sibling::div")
    private SelenideElement firstNameText;

    @FindBy(xpath = "//label[@for='clientName']/following-sibling::div")
    private SelenideElement surnameText;

    @FindBy(xpath = "//div[@id='birthDate_fieldLine']/div")
    private SelenideElement dateOfBirthText;

    @FindBy(xpath = "//*[contains(@class, 'checked') or contains(@class, 'unchecked')])")
    private ElementsCollection setAllMarketingPrefs;

    @FindBy(xpath = "//*[contains(@class, 'checked') and contains(text(), 'by post')]")
    private ElementsCollection checkedMarketingPrefsByPost;

    @FindBy(xpath = "//*[contains(@class, 'unchecked')]")
    private ElementsCollection uncheckedMarketingPrefs;

    @FindBy(xpath = "//*[contains(@class, 'checked')]")
    private ElementsCollection checkedMarketingPrefs;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//h3[contains(text(),'Your address')]/../..//a[text()='Change']")
    private SelenideElement changeYourAddressButton;

    @FindBy(xpath = "//h3[contains(text(),'Your phone numbers')]/../..//a[text()='Change']")
    private SelenideElement changeYourPhoneNumbersButton;

    @FindBy(xpath = "//h3[contains(text(),'Your email address')]/../..//a[text()='Change']")
    private SelenideElement changeYourEmailAddressButton;

    @FindBy(xpath = "//h3[contains(text(),'Your marketing preferences')]/../..//a[text()='Change']")
    private SelenideElement changeYourMarketingPreferencesButton;

    @FindBy(xpath = "//h3[contains(text(),'Transactional text updates')]/../..//a[text()='Change']")
    private SelenideElement changeTransactionalTextUpdatesButton;

    @FindBy(xpath = "//h3[contains(text(),'Your security details')]/../..//a[text()='Change'][1]")
    private SelenideElement changeSecurityQuestionsButton;

    @FindBy(xpath = "//h3[contains(text(),'Your security details')]/../..//a[text()='Change'][2]")
    private SelenideElement changePasswordButton;

    @FindBy(xpath = "//h3[contains(text(),'Tax details')]/../..//a[text()='Change']")
    private SelenideElement changeTaxDetailsButton;

    // LINKS

    // ----------------------------------------------------
}