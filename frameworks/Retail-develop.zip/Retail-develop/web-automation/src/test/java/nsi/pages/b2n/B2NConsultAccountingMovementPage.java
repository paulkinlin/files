package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NConsultAccountingMovementPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx01")
    private SelenideElement accountText;

    @FindBy(id = "Tx05")
    private SelenideElement operationDateText;

    @FindBy(id = "Tx06")
    private SelenideElement valueDateText;

    @FindBy(id = "Tx07")
    private SelenideElement kindOfOperationText;

    @FindBy(id = "Tx08")
    private SelenideElement amountOfTheMovementText;

    @FindBy(id = "Tx09")
    private SelenideElement operationReferenceText;

    @FindBy(id = "Tx10")
    private SelenideElement accountingDateText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    @FindBy(xpath = "//a[@href='javascript:submitForm(03)']")
    private SelenideElement backButton;

    // LINKS

    // ----------------------------------------------------
}
