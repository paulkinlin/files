package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ConfirmAccountClosureWithSecurityQuestionsPage extends Pages {

    // TEXTS

    @FindBy(xpath = "//h3[contains(.,'For your security, please answer the questions below.')]")
    private SelenideElement answerSecurityQuestionsText;

    // FIELDS

    @FindBy(xpath = "//input[@id='challengeQuestion0']")
    private SelenideElement answerQuestion1Field;

    @FindBy(xpath = "//input[@id='challengeQuestion1']")
    private SelenideElement answerQuestion2Field;

    // DROPDOWNS

    // RADIOBUTTONS

    // CHECKBOXES

    // BUTTONS

    @FindBy(xpath = "//input[@id='btnNext']")
    private SelenideElement confirmButton;

    // LINKS

}
