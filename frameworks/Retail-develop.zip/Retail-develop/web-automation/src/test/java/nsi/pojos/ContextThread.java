package nsi.pojos;

public class ContextThread {

    private Context context;

    public Context getContext() {
        if (context == null) {
            context = new Context();
        }
        return context;
    }

}
