package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NSearchCustomerSummaryPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NSearchCustomerSummarySteps extends Steps {

    private final B2NSearchCustomerSummaryPage b2NSearchCustomerSummaryPage = page(B2NSearchCustomerSummaryPage.class);

    @And("B2NSearchCustomerSummaryPage: choose name {string}")
    public void searchcustomersummarypageChooseName(String name) {
        switchToFrame("dynamic");
        verifyPageTitle("Search a customer");

        $(By.linkText(name)).click();
    }

    @And("B2NSearchCustomerSummaryPage: select radio for name {string}")
    public void searchcustomersummarypageSelectRadioForName(String name) {
        switchToFrame("dynamic");
        verifyPageTitle("Search a customer");

        ElementsCollection rows = b2NSearchCustomerSummaryPage.getTableWithResults().$$(By.tagName("tr"));

        for (SelenideElement row : rows) {

            if (row.getText().contains(name)) {
                SelenideElement radio = row.$(By.tagName("input")).setSelected(true);
                radio.shouldBe(Condition.selected);
            }
        }
    }

    @And("B2NSearchCustomerSummaryPage: click button {string}")
    public void searchcustomersummarypageClickButton(String buttonName) {
        switchToFrame("dynamic");
        verifyPageTitle("Search a customer");

        switch (buttonName.toLowerCase()) {
            case "authenticate a customer":
                b2NSearchCustomerSummaryPage.getAuthenticateCustomerButton().execute(waitUntilVisible).click();
                break;
            case "summary of initial sales":
                b2NSearchCustomerSummaryPage.getSummaryOfInitialSalesButton().execute(waitUntilVisible).click();
                break;
            case "registration":
                b2NSearchCustomerSummaryPage.getRegistrationButton().execute(waitUntilVisible).click();
                break;
            case "reprint":
                b2NSearchCustomerSummaryPage.getReprintButton().execute(waitUntilVisible).click();
                break;
            case "enquiries history":
                b2NSearchCustomerSummaryPage.getEnquiriesHistoryButton().execute(waitUntilVisible).click();
                break;
            case "fulfilment":
                b2NSearchCustomerSummaryPage.getFulfilmentButton().execute(waitUntilVisible).click();
                break;
            case "add a customer":
                b2NSearchCustomerSummaryPage.getAddCustomerButton().execute(waitUntilVisible).click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NSearchCustomerSummaryPage: select mainInvestor from JSON {string}")
    public void bNSearchCustomerSummaryPageSelectMainInvestorFromJSON(String jsonFile) throws IOException, ParseException {
        String title = getContext().getMainInvestorClientData().getTitle();
        String foreName = getContext().getMainInvestorClientData().getForeName();
        String surName = getContext().getMainInvestorClientData().getSurName();

        searchcustomersummarypageSelectRadioForName(title + " " + foreName.charAt(0) + " "+ surName);
    }
}