package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.And;
import nsi.pages.b2c.customerMaintenance.ViewAccountPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class ViewAccountSteps extends Steps {

    private ViewAccountPage viewAccountPage = page(ViewAccountPage.class);

    @And("ViewAccountPage: back to Dashboard")
    public void viewaccountBackToDashboard() {
        viewAccountPage.getCancelButton().click();
    }
}