package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.MakeATransferPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class MakeATransferSteps extends Steps {

    private final MakeATransferPage makeATransferPage = page(MakeATransferPage.class);

    @When("MakeATransferPage: enter amt to transfer {string}")
    public void makeATransferPageEnterAmtToTransfer(String amt) {
        makeATransferPage.getTitleText().shouldHave(Condition.exactText("Make a transfer"));
        makeATransferPage.getAmountToTransferField().execute(clearAndSetValue(amt));
        getContext().getProductPojoList().getLast().setAmount(amt);
    }

    @When("MakeATransferPage: check account")
    public void makeATransferPageCheckDirectSaverAccount() {
        makeATransferPage.getCheckAccountRadio().click();
        getContext().getProductPojoList().getLast().setTargetAccount(makeATransferPage.getTargetAccount().getText().replaceAll("\n" , " "));
    }

    @When("MakeATransferPage: choose transfer deferment {string}")
    public void makeATransferPageChooseTransferDeferment(String option) {
        switch (option.toLowerCase()) {
            case "yes":
                makeATransferPage.getYesTransferDefermentRadio().click();
                break;
            case "no":
                makeATransferPage.getNoTransferDefermentRadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("MakeATransferPage: click continue")
    public void makeATransferPageClickContinue() {
        makeATransferPage.getNextButton().click();
    }
}