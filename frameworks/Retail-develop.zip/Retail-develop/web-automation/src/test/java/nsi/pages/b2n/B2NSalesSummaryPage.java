package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSalesSummaryPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//tr[@id='row01']/child::td[1]")
    private SelenideElement saleRefPRNText;

    @FindBy(xpath = "//tr[@id='row01']/child::td[2]")
    private SelenideElement statusText;

    @FindBy(xpath = "//tr[@id='row01']/child::td[3]")
    private SelenideElement productText;

    @FindBy(xpath = "//tr[@id='row01']/child::td[4]")
    private SelenideElement amountText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//a[@href='javascript:submitForm(03)']")
    private SelenideElement backButton;

    // LINKS

    // ----------------------------------------------------
}
