package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class NotifyDetailsPage extends Pages {

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='prizeNotification:0']")
    private SelenideElement prizeNotifyEmailRadio;

    @FindBy(xpath = "//label[@for='prizeNotification:1']")
    private SelenideElement prizeNotifyTextRadio;

    @FindBy(xpath = "//label[@for='notificationValue:0']")
    private SelenideElement notifyEmailRadio;

    @FindBy(xpath = "//label[@for='notificationValue:1']")
    private SelenideElement notifyTextRadio;

    // BUTTONS
    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    // ----------------------------------------------------
}