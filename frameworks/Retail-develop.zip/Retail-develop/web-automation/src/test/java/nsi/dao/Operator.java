package nsi.dao;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Operator {

    private Long id;
    private String numabt;
    private String password;
    private final String operatorPass = System.getenv("operatorPass");

    public String getPassword() {
        return operatorPass;
    }
}