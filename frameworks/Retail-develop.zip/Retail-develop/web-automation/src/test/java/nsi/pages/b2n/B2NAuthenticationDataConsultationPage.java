package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NAuthenticationDataConsultationPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx02")
    private SelenideElement nameText;

    @FindBy(id = "Tx01")
    private SelenideElement statusText;

    @FindBy(id = "Tx03")
    private SelenideElement cDateText;

    @FindBy(id = "Tx04")
    private SelenideElement vDateText;

    @FindBy(id = "Tx05")
    private SelenideElement aDateText;

    @FindBy(id = "Tx06")
    private SelenideElement userText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS

    // ----------------------------------------------------
}