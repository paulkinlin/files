package nsi.pages;

public abstract class Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS

    // ----------------------------------------------------

}
