package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NTransactionHistoryListPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ta01")
    private SelenideElement historyTable;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm12")
    private SelenideElement nextButton;

    @FindBy(id = "Subm10")
    private SelenideElement previusButton;

    // LINKS

    // ----------------------------------------------------
}
