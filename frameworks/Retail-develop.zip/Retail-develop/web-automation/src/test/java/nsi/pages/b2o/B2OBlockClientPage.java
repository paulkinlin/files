package nsi.pages.b2o;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2OBlockClientPage extends Pages {

    // TEXTS
    @FindBy(id = "blockingCode")
    private SelenideElement blockingCodeText;

    @FindBy(id = "blockingCode_libelle")
    private SelenideElement blockingCodeLabelText;

    // FIELDS
    @FindBy(id = "clientNumber")
    private SelenideElement clientNumberSearchField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS

    // ----------------------------------------------------
}