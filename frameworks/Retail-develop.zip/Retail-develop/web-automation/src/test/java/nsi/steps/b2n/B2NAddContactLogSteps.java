package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NAddContactLogPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.*;
import static nsi.utils.CustomCommands.*;

@Slf4j
public class B2NAddContactLogSteps extends Steps {

    private B2NAddContactLogPage b2NAddContactLogPage = page(B2NAddContactLogPage.class);

    @And("B2NAddContactLogPage: submit Type of contact {string} Bank product {string} Note {string}")
    public void addcontactlogpageSubmitTypeOfContactBankProductNote(String typeOfContact, String bankProduct, String note) {
        switchToFrame("dynamic");


        if (!typeOfContact.isEmpty()) {
            b2NAddContactLogPage.getTypeOfContactSelect().selectOption(typeOfContact);
            b2NAddContactLogPage.getTypeOfContactSelect().shouldHave(Condition.text(typeOfContact));
        }
        if (!bankProduct.isEmpty()) {
            b2NAddContactLogPage.getBankProductSelect().selectOption(bankProduct);
            b2NAddContactLogPage.getBankProductSelect().shouldHave(Condition.text(bankProduct));
        }
        if (!note.isEmpty()) {
            b2NAddContactLogPage.getNoteField().setValue(note);
            b2NAddContactLogPage.getNoteField().shouldHave(Condition.value(note));
        }

        log.info("AddContactLogPage submit Type of contact '{}' Bank product '{}' Note '{}'", typeOfContact, bankProduct, note);

        b2NAddContactLogPage.getConfirmButton().click();

        $(By.xpath("//form[@name='form1']"))
                .waitUntil(Condition.matchesText("Summary of contact logs"), 10000, 200);
    }

    @And("B2NAddContactLogPage: submit next button")
    public void submitNextButton() {
        switchToFrame("dynamic");

        b2NAddContactLogPage.getConfirmButton()
                .execute(waitUntilVisible)
                .click();
    }

    @And("B2NAddContactLogPage: submit Add contact log button")
    public void submitAddContactLogButton() {
        switchToFrame("dynamic");

        b2NAddContactLogPage.getConfirmButton()
                .execute(waitUntilVisible)
                .click();
    }

    @And("B2NAddContactLogPage: verify latest contact log entry on Summary view Bank product {string} Type of Contact: {string}")
    public void verifyLatestContactLogEntry(String bankProduct, String typeOfContact) {
        switchToFrame("dynamic");

        b2NAddContactLogPage.getLatestContactLogEntry().execute(waitUntilVisible).shouldHave(Condition.text(bankProduct));
        b2NAddContactLogPage.getLatestContactLogEntry().execute(waitUntilVisible).shouldHave(Condition.text(typeOfContact));
    }

    @And("B2NAddContactLogPage: look up contact log entry Bank product {string} Type of Contact: {string} Note: {string}")
    public void verifyLatestContactLogEntry(String bankProduct, String typeOfContact, String note) {
        switchToFrame("dynamic");

        b2NAddContactLogPage.getLookUpButton().execute(jsClick);
        b2NAddContactLogPage.getLookUpBankProduct().execute(waitUntilVisible).shouldHave(Condition.exactText(bankProduct));
        b2NAddContactLogPage.getLookUpTypeOfContact().execute(waitUntilVisible).shouldHave(Condition.exactText(typeOfContact));
        b2NAddContactLogPage.getLookUpNoteTextArea().execute(waitUntilVisible).shouldHave(Condition.exactText(note));
    }
}