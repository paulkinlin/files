package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeCustomerPreferencePage extends Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    // LINKS

    // TABLES
    @FindBy(id = "Tab03")
    private SelenideElement CustomersTable;

    // ----------------------------------------------------
}