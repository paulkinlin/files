package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class CashInCloseAccountPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='closureRadios:1']")
    private SelenideElement yesCloseAccountRadio;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}