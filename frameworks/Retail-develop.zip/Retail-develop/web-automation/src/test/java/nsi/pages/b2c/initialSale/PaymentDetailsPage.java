package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class PaymentDetailsPage extends Pages {

    // CONTENTS
    @FindBy(id = "main-content")
    private SelenideElement pageContent;

    @FindBy(name = "rtlframe")
    private SelenideElement frameFirstContent;

    // TEXTS
    @FindBy(xpath = "//div[@class='field-group--summary']/div/h3 | //h2[contains(text(), 'Payment details')]")
    private SelenideElement paymentDetailsPageTitleText;

    @FindBy(xpath = "//div[@id='loginDetails1']/div")
    private SelenideElement nsiNumberText;

    @FindBy(xpath = "//div[@id='loginDetails3']/div")
    private SelenideElement nsiNumberPBSomeoneChildText;

    @FindBy(xpath = "//div[@id='holding' or @id='account']/div")
    private SelenideElement accountNumberText;

    @FindBy(xpath = "//div[@id='saleAmount']/div")
    private SelenideElement totalAmountText;

    @FindBy(xpath = "//*[@id='reference']/div")
    private SelenideElement referenceNumber;

    // BUTTONS
    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    @FindBy(id = "btnSubmit")
    private SelenideElement payNowButton;

    @FindBy(id = "btnNext")
    private SelenideElement confirmButton;

    @FindBy(xpath = "//*[@id='initialSaleConfirmationScreen']//*[@class='column']")
    private SelenideElement confirmationText;

    // RADIOBUTTONS
    @FindBy(xpath = "//label[contains(.,'Pay by debit card')]")
    private SelenideElement payByDebitCardRadio;

    @FindBy(id = "paymentChoice:0")
    private SelenideElement payByDebitCardConfirmationRadio;

    @FindBy(xpath = "//label[contains(.,'Pay from another NS&I account')]")
    private SelenideElement payFromAnotherNSIAccRadio;

    @FindBy(xpath = "//label[@for='initialSaleForm:fundingDepositAccount_accountRadio_0' or @for='saleB2CActionsForm:fundingDepositAccount_accountRadio_0']")
    private SelenideElement checkDirectSaverAccRadio;

    @FindBy(xpath = "//input[@id='initialSaleForm:fundingDepositAccount_accountRadio_0' or @id='saleB2CActionsForm:fundingDepositAccount_accountRadio_0']")
    private SelenideElement checkDirectSaverAccConfirmationRadio;

    // ----------------------------------------------------
}