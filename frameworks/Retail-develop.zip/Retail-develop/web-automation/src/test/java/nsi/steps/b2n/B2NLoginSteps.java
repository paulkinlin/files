package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.dao.Operator;
import nsi.dao.OperatorsDao;
import nsi.pages.b2n.B2NLoginPage;
import nsi.pojos.B2NOperators;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NLoginSteps extends Steps {

    private final B2NLoginPage b2NLoginPage = page(B2NLoginPage.class);

    private final OperatorsDao operatorsDao = new OperatorsDao();

    @When("B2NLoginPage: submit operator {string}")
    public void loginpageSubmitOperator(String operatorName) {
        B2NOperators operator = B2NOperators.valueOf(operatorName);
        b2NLoginPage.getLoginField().execute(clearAndSetValue(operator.returnLogin()));
        b2NLoginPage.getPasswordField().execute(clearAndSetValue(operator.returnPassword()));
        b2NLoginPage.getSendButton().click();
    }

    @When("B2NLoginPage: submit second operator {string}")
    public void loginpageSubmitSecondOperator(String operatorName) {
        B2NOperators operator = B2NOperators.valueOf(operatorName);
        b2NLoginPage.getLoginField().execute(clearAndSetValue(operator.returnLogin()));
        b2NLoginPage.getPasswordField().execute(clearAndSetValue(operator.returnPassword()));
        b2NLoginPage.getSendButton().click();
    }

    @And("B2NLoginPage: login operator")
    public void bNLoginPageLoginOperator() {
        b2NLoginPage.getLoginField().shouldBe(Condition.and("", Condition.visible, Condition.enabled));
        b2NLoginPage.getPasswordField().shouldBe(Condition.and("", Condition.visible, Condition.enabled));
        b2NLoginPage.getSendButton().shouldBe(Condition.and("", Condition.visible, Condition.enabled));
        Operator operator = operatorsDao.getFreeOperatorToTest();
        log.info("Selected operator: " + operator.getNumabt());
        getContext().getUserIds().add(operator.getNumabt());
        logIn(operator);
    }

    public void logIn(Operator operator) {
        b2NLoginPage.getLoginField().setValue(operator.getNumabt());
        b2NLoginPage.getPasswordField().setValue(operator.getPassword());
        b2NLoginPage.getSendButton().click();

        getContext().setLastUsedOperator(operator.getNumabt());
    }
}
