package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.TakeMoneyOutPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class TakeMoneyOutSteps extends Steps {

    private final TakeMoneyOutPage takeMoneyOutPage = page(TakeMoneyOutPage.class);

    @Then("TakeMoneyOutPage: submit amount {string}")
    public void takemoneyoutAmount(String amount) {
        takeMoneyOutPage.getAmountField().execute(clearAndSetValue(amount));
        takeMoneyOutPage.getNextButton().click();
        getContext().getProductPojoList().getLast().setAmount(amount);
    }

    @And("TakeMoneyOutPage: check error text {string}")
    public void takemoneyoutErrorText(String errorMsg) {
        takeMoneyOutPage.getErrorText().shouldHave(Condition.text(errorMsg));
    }

    @And("TakeMoneyOutPage: check available amount {string}")
    public void takemoneyoutAvailableAmount(String amount) {
        takeMoneyOutPage.getAvailableAmountText().shouldHave(Condition.text(amount));
    }

    @And("TakeMoneyOutPage: check current balance {string}")
    public void takemoneyoutCurrentBalance(String balance) {
        takeMoneyOutPage.getAvailableAmountText().shouldHave(Condition.text(balance));
    }

    @And("TakeMoneyOutPage: check pay to account {string}")
    public void takemoneyoutPayToAccount(String account) {
        takeMoneyOutPage.getPayToSelect().shouldHave(Condition.text(account));
    }
}