package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NDashboardPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.jsClick;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NDashboardSteps extends Steps {

    private final B2NDashboardPage b2NDashboardPage = page(B2NDashboardPage.class);

    @And("B2NDashboardPage: select {string}")
    public void dashboardpageSelect(String select) {
        switchToFrame("topFrame");

        b2NDashboardPage.getTopMenu()
                .execute(waitUntilVisible)
                .findAll(By.tagName("a"))
                .find(Condition.matchesText(select))
                .execute(jsClick);

        try {
            WebDriverWait wait = new WebDriverWait(WebDriverRunner.getWebDriver(), 10);
            wait.until(ExpectedConditions.alertIsPresent());
            WebDriverRunner.getWebDriver().switchTo().alert().accept();

            log.debug("Alert accepted");
        } catch (Exception e) {

        }
    }

    @And("B2NDashboardPage: left menu select {string}")
    public void dashboardpageLeftMenuSelect(String menuPosition) {
        switchToFrame("menu");

        b2NDashboardPage.getLeftMenu()
                .execute(waitUntilVisible)
                .findAll(By.tagName("a"))
                .find(Condition.matchesText(menuPosition))
                .execute(jsClick);
    }

    @And("B2NDashboardPage: select quicklink {string}")
    public void dashboardpageSelectQuicklink(String name) {
        switchToFrame("topFrame");

        b2NDashboardPage.getShortcutsMenu()
                .execute(waitUntilVisible)
                .findAll(By.tagName("a"))
                .find(Condition.exactText(name))
                .execute(jsClick);
    }
}
