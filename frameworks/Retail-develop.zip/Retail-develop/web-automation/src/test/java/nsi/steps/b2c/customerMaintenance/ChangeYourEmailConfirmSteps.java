package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.ChangeYourEmailConfirmPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class ChangeYourEmailConfirmSteps extends Steps {

    private ChangeYourEmailConfirmPage changeYourEmailConfirmPage = page(ChangeYourEmailConfirmPage.class);

    @And("ChangeYourEmail confirm")
    public void changeyouremailConfirm() {
        changeYourEmailConfirmPage.getTitleText().shouldHave(Condition.text("Confirm your new email address"));
        changeYourEmailConfirmPage.getConfirmButton().click();
    }
}