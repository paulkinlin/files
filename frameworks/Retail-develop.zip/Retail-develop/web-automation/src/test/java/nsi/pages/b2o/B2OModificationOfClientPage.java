package nsi.pages.b2o;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2OModificationOfClientPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "clientNumber")
    private SelenideElement clientIdentityField;

    @FindBy(id = "clientName")
    private SelenideElement clientNameField;

    @FindBy(id = "customerShortName")
    private SelenideElement customerShortNameField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnConfirm")
    private SelenideElement confirmButton;

    @FindBy(id = "btnNext")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}