package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeAddressPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Cb07")
    private SelenideElement countrySelect;

    @FindBy(id = "Ed01F")
    private SelenideElement postCodeField;

    @FindBy(id = "PCA11")
    private SelenideElement foundAddressesSelect;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm83")
    private SelenideElement searchButton;

    @FindBy(id = "Subm80")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
