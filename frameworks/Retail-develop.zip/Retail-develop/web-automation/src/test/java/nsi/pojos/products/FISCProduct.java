package nsi.pojos.products;

public class FISCProduct extends ProductPojo {
}
