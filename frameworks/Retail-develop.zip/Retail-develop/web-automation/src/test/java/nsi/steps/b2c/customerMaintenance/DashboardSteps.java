package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.DashboardPage;
import nsi.pojos.products.ProductPojo;
import nsi.pojos.products.SetUpProductB2C;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import java.text.NumberFormat;

import static com.codeborne.selenide.CollectionCondition.size;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;
import static nsi.utils.JsonUtils.getValueFromJson;
import static nsi.utils.JsonUtils.getValueFromJsonArray;

@Slf4j
public class DashboardSteps extends Steps {

    private final DashboardPage dashboardPage = page(DashboardPage.class);

    @And("DashboardPage: navigate yourDetails")
    public void dashboardNavigateYourDetails() {
        do {
            dashboardPage.getYourProfileLink().hover();
            dashboardPage.getYourProfileLink().click();
        } while (!dashboardPage.getYourDetailsLink().is(Condition.visible));
        dashboardPage.getYourDetailsLink().click();
    }

    @And("DashboardPage: navigate yourDashboard")
    public void dashboardNavigateYourDashboard() {
        dashboardPage.getYourAccountsLink().hover();
        dashboardPage.getYourDashboardLink().shouldBe(Condition.visible).execute(clickAndWait);
    }

    @And("LoginPage: check dashboard is visible")
    public void dashboardPageIsDisplayed() {
        dashboardPage.getLogoNSILinks().shouldBe(Condition.visible, Condition.enabled);
    }

    @And("DashboardPage: navigate paperless options")
    public void dashboardNavigatePaperlessOptions() {
        int counter = 0;
        do {
            dashboardPage.getYourProfileLink().hover();
            dashboardPage.getYourProfileLink().click();
            counter++;
        } while (!dashboardPage.getPaperlessOptionsLink().is(Condition.visible) && counter < 5);
        dashboardPage.getPaperlessOptionsLink().click();
    }


    @And("DashboardPage: click logo NSI")
    public void dashboardClickLogoNSI() {
        dashboardPage.getLogoNSILinks().hover().execute(waitUntilAttributeLogoActivePresented).click();
    }

    @And("DashboardPage: logout")
    public void dashboardLogout() {
        dashboardPage.getLogOutLink().click();
        dashboardPage.getLogOutButton().click();
    }

    @And("DashboardPage: click takeMoneyOut and save transaction type to context {string}")
    public void dashboardTakeMoneyOutAndSaveTransactionTypeToContext(String productName) {
        dashboardPage.getTakeMoneyOutLinks()
                .first()
                .execute(waitUntilVisible)
                .click();
        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(productName);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised"); }
            getContext().getProductPojoList().add(productPojo);
        getContext().getProductPojoList().getLast().setTransactionType("takeMoneyOut");
        productPojo.setProduct(productName);
    }

    @And("DashboardPage: click takeMoneyOut {string}")
    public void dashboardTakeMoneyOut(String productName) {
        dashboardPage.getTakeMoneyOutLinks()
                .first()
                .execute(waitUntilVisible)
                .click();
    }

    @And("DashboardPage: click openNewAccount")
    public void dashboardOpenNewAccount() {
        dashboardPage.getOpenNewAccountLinks()
                .first()
                .execute(waitUntilVisible)
                .click();

        String productName = dashboardPage.getProductNameHeader()
                .execute(waitUntilVisible)
                .getText();

        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(productName);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised"); }
        getContext().getProductPojoList().add(productPojo);
        getContext().getProductPojoList().getLast().setTransactionType("InitialSale");
        productPojo.setProduct(productName);
    }

    @And("DashboardPage: click buyMoreBonds {string}")
    public void dashboardbuyMoreBonds(String productName) {
        dashboardPage.getBuyMoreBondsLinks()
                .first()
                .execute(waitUntilVisible)
                .click();
    }

    @And("DashboardPage: click cashIn {string}")
    public void dashboardCashIn(String productName) {
        dashboardPage.getCashInLinks()
                .first()
                .execute(waitUntilVisible)
                .click();
    }

    @And("DashboardPage: click cashIn and save transaction type to context {string}")
    public void dashboardCashInAndSaveTransactionTypeToContext(String productName) {
        dashboardPage.getCashInLinks()
                .first()
                .execute(waitUntilVisible)
                .click();
        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(productName);
            if (productPojo == null) {
                throw new RuntimeException("Product not recognised"); }
            getContext().getProductPojoList().add(productPojo);
            productPojo.setProduct(productName);
            getContext().getProductPojoList().getLast().setTransactionType("cashIn");
    }

    @When("DashboardPage: click viewAccount {string}")
    public void dashboardViewAccount(String productName) {
        dashboardPage.getViewAccountLinks()
                .first()
                .execute(waitUntilVisible)
                .execute(clickAndWait);
    }

    @And("DashboardPage: check {string} account tile is present in dashboard")
    public void dashboardCheckAccountTileIsPresentInDashboard(String tileTitle) {
        dashboardNavigateYourDashboard();
        SelenideElement productTileWidget = dashboardPage.getProductTileWidget()
                .filter(Condition.text(tileTitle))
                .first()
                .execute(waitUntilVisible);
        productTileWidget.$x("./h3/strong").shouldHave(Condition.exactText(tileTitle));
    }

    @And("DashboardPage: check {int} product tile(s) is/are displayed in dashboard")
    public void dashboardpageCheckProductTilesIsDisplayedInDashboard(int numberOfTiles) {
        dashboardPage.getProductTileWidget().shouldBe(size(numberOfTiles));
    }

    @And("DashboardPage: check {string} account tile is present in dashboard with amount {string}")
    public void dashboardCheckAccountTileIsPresentInDashboardWithAmount(String tileTitle, String amount) {
        dashboardNavigateYourDashboard();
        SelenideElement productTileWidget = dashboardPage.getProductTileWidget()
                .filter(Condition.text(tileTitle))
                .first()
                .execute(waitUntilVisible);
        productTileWidget.$x("./h3/strong").shouldHave(Condition.exactText(tileTitle));
        productTileWidget.$x("./ul[contains(@class,'list--account-summary')]/li[contains(text(),'Balance')]/Strong")
                .shouldHave(Condition.text(amount));
    }

    @And("DashboardPage: navigate {string}")
    public void dashboardNavigateYourProduct(String product) {
        dashboardPage.getYourAccountsLink().hover();
        $(By.xpath("//a[contains(.,'" + product + "')]")).click();
    }

    @And("DashboardPage: click payMoneyIn {string}")
    public void dashboardPayMoneyIn(String productName) {
        dashboardPage.clickPayMoneyInLinkFor(Condition.attribute("aria-label", "Pay money in " + productName));
    }

    @And("DashboardPage: click payMoneyIn {string} and save transaction type to context")
    public void dashboardPayMoneyInAndSaveTransactionTypeToContext(String productName) {
        dashboardPage.clickPayMoneyInLinkFor(Condition.attribute("aria-label", "Pay money in " + productName));

        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(productName);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised"); }
        getContext().getProductPojoList().add(productPojo);
        productPojo.setProduct(productName);
        getContext().getProductPojoList().getLast().setTransactionType("payMoneyIn");
    }

    @And("DashboardPage: click makeATransfer {string}")
    public void dashboardMakeATransfer(String productName) {
        dashboardPage.clickMakeATransferLinkFor(Condition.attribute("aria-label", "Make a transfer " + productName));
        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(productName);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised"); }
        getContext().getProductPojoList().add(productPojo);
        productPojo.setProduct(productName);
        getContext().getProductPojoList().getLast().setTransactionType("transfer");
    }

    @And("DashboardPage: check information from json {string}")
    public void dashboardCheckCustomerInformation(String jsonFile) throws Throwable {
        String title = getValueFromJson("mainInvestorClientData", "title" , jsonFile);
        String surname = getValueFromJson("mainInvestorClientData", "surName" , jsonFile);
        String amountInvested = "£" + getValueFromJsonArray("productPojoList", "amount" , jsonFile);

        dashboardPage.getTitleAndSurnameText().shouldHave(Condition.text(title));
        dashboardPage.getTitleAndSurnameText().shouldHave(Condition.text(surname));
        dashboardPage.getAmountInvestedText().shouldHave(Condition.text(amountInvested));

    }

    @And("DashboardPage: acceptCookies")
    public void dashboardacceptCookies() {
        if (dashboardPage.getCookieConsentButton().isDisplayed()) {
            dashboardPage.getCookieConsentButton().click();
        }
    }

    @And("DashboardPage: check total invested amount {string}")
    public void dashboardCheckAmount(String amountInvested) {
        dashboardPage.getAmountInvestedText().shouldHave(Condition.text(amountInvested));
    }

    @And("DashboardPage: check balance {string}")
    public void dashboardCheckBalance(String balance) {
        dashboardPage.getAmountFirstProductText().shouldHave(Condition.exactText(balance));
    }

    @And("DashboardPage: check balance wording {string}")
    public void dashboardCheckBalanceWording(String balanceWording) {
        dashboardPage.getBalanceWordingFirstProductText().shouldHave(Condition.text(balanceWording));
    }

    @And("DashboardPage: compare products amount with total amount")
    public void dashboardCompareAmountsOfProducts() {
        long firstProductAmount = Long.parseLong(dashboardPage.getAmountFirstProductText().getText().substring(1).replaceAll("\\D", ""));
        long secondProductAmount = Long.parseLong(dashboardPage.getAmountSecondProductText().getText().substring(1).replaceAll("\\D", ""));
        String total = NumberFormat.getInstance().format(firstProductAmount + secondProductAmount);
        dashboardPage.getAmountInvestedText().shouldHave(Condition.exactText("£"+total));
    }

    @And("^DashboardPage: verify tax details$")
    public void changeYourTaxtDetailsConfirm() {
        if (ChangeYourTaxDetailsSteps.taxNonUK.equals("yes")) {
            dashboardPage.getBirthCityText().shouldHave(Condition.exactText(ChangeYourTaxDetailsSteps.city));
            dashboardPage.getBirthCountryText().shouldHave(Condition.exactText(ChangeYourTaxDetailsSteps.country));
            dashboardPage.getTaxCountryText().shouldHave(Condition.exactText(ChangeYourTaxDetailsSteps.taxCountry));
            if (ChangeYourTaxDetailsSteps.tinNumber != null) {
                dashboardPage.getTaxIdentificationNumberText().shouldHave(Condition.exactText(ChangeYourTaxDetailsSteps.tinNumber));
            } else {
                dashboardPage.getTaxIdentificationNumberText().shouldHave(Condition.text("I don’t have a tax identification number"));
            }
        }
    }

    @And("DashboardPage: validate displayed surname on dashboard as {}")
    public void validateSurNameOnDashboard(String surname) {
        dashboardPage.getTitleAndSurnameText().shouldHave(Condition.text(surname));
    }

}