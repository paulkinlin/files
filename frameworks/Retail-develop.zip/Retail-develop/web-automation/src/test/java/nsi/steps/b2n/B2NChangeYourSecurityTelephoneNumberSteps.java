package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NChangeYourSecurityTelephoneNumberPage;
import nsi.steps.Steps;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NChangeYourSecurityTelephoneNumberSteps extends Steps {

    private final B2NChangeYourSecurityTelephoneNumberPage b2NChangeYourSecurityTelephoneNumberPage = page(B2NChangeYourSecurityTelephoneNumberPage.class);

    @And("B2NChangeYourSecurityTelephoneNumberPage: submit cell phone number from json {string}")
    public void changeyoursecuritytelephonenumberSubmitCellPhoneNumber(String jsonFile) throws IOException, ParseException {
        switchToFrame("dynamic");
        String phoneNumber = getContext().getMainInvestorClientData().getPhoneNumber();
        b2NChangeYourSecurityTelephoneNumberPage.getPhoneNumberOneField()
                .execute(clearAndSetValue(phoneNumber));
        b2NChangeYourSecurityTelephoneNumberPage.getPhoneNumberOneField().shouldHave(Condition.value(phoneNumber));
        b2NChangeYourSecurityTelephoneNumberPage.getConfirmButton().click();
    }

    @And("B2NChangeYourSecurityTelephoneNumberPage: change cell phone number to {string}")
    public void changeYourSeurityTelephoneNumerTo(String number) {
        switchToFrame("dynamic");
        b2NChangeYourSecurityTelephoneNumberPage.getPhoneNumberOneField()
                .execute(clearAndSetValue(number));
        b2NChangeYourSecurityTelephoneNumberPage.getPhoneNumberOneField().shouldHave(Condition.value(number));
        b2NChangeYourSecurityTelephoneNumberPage.getConfirmButton().click();
    }
}
