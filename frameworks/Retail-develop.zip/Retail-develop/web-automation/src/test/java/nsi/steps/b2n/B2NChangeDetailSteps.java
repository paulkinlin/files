package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeDetailPage;
import nsi.steps.Steps;
import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NChangeDetailSteps extends Steps {

    private B2NChangeDetailPage b2NChangeDetailPage = page(B2NChangeDetailPage.class);

    @And("B2NChangeDetailPage: change title {string} NI {string}")
    public void changedetailpageSubmitEmail(String title, String ni) {
        switchToFrame("dynamic");

        if (!title.isEmpty()) {
            b2NChangeDetailPage.getTitleSelect().selectOption(title);
        }
        if (!ni.isEmpty()) {
            b2NChangeDetailPage.getNIField().execute(clearAndSetValue(ni));
        }

        log.info("ChangeDetailPage change title '{}' NI '{}'", title, ni);
    }

    @And("B2NChangeDetailPage: customer extra details change: fax {string} email {string} SPICode {string}")
    public void changedetailpageCustomerExtraDetailsSubmitFaxEmailSPICode(String fax, String email, String spiCode) {
        switchToFrame("dynamic");

        if (!fax.isEmpty()) {
            b2NChangeDetailPage.getFaxNumberField().execute(clearAndSetValue(fax));
        }
        if (!email.isEmpty()) {
            b2NChangeDetailPage.getEmailField().execute(clearAndSetValue(email));
        }
        if (!spiCode.isEmpty()) {
            b2NChangeDetailPage.getSPICodeSelect().selectOption(spiCode);
        }

        log.info("ChangeDetailPage - Customer extra details change: fax '{}' email '{}' SPICode '{}'", fax, email, spiCode);
    }

    @And("B2NChangeDetailPage: submit confirm")
    public void changedetailpageSubmitConfirm() {
        switchToFrame("dynamic");

        b2NChangeDetailPage.getConfirmButton().click();
    }
}
