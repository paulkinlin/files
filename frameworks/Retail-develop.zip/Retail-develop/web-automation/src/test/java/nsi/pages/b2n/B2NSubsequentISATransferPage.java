package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSubsequentISATransferPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Cb01")
    private SelenideElement accountNumberSelect;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm82")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}
