package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.ThankYouInvestmentPage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clickAndWait;
import static nsi.utils.CustomCommands.waitUntilVisible;

public class ThankYouInvestmentSteps extends Steps {

    private final ThankYouInvestmentPage thankYouInvestmentPage = page(ThankYouInvestmentPage.class);

    @Then("ThankYouInvestmentPage: click backToHomePage")
    public void thankYouInvestBackToHomePage() {
        thankYouInvestmentPage.getYourHomePageButton().execute(waitUntilVisible).execute(clickAndWait);
    }

    @Then("ThankYouInvestmentPage: save amount and reference number to context and click backToHomePage")
    public void thankYouInvestSaveAmountAndReferenceNumberAndBackToHomePage() {

        getContext().getProductPojoList().getLast().setAmount(thankYouInvestmentPage.getAmount().getText());
        getContext().getProductPojoList().getLast().setReferenceNumber(thankYouInvestmentPage.getReferenceNumber().getText());
        if(getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList().getLast())
                    .setHoldersNumber(thankYouInvestmentPage.getHoldersNumberText().getText());
        }

        thankYouInvestmentPage.getYourHomePageButton().execute(waitUntilVisible).execute(clickAndWait);
    }

    @Then("ThankYouInvestmentPage: save reference number to context and click backToHomePage")
    public void thankYouInvestSaveReferenceNumberAndBackToHomePage() {

        getContext().getProductPojoList().getLast().setReferenceNumber(thankYouInvestmentPage.getReferenceNumber().getText());
        thankYouInvestmentPage.getYourHomePageButton().execute(waitUntilVisible).execute(clickAndWait);
    }

    @Then("ThankYouInvestmentPage: click backToProduct")
    public void thankYouInvestBackToProduct() {
        thankYouInvestmentPage.getBackToButton().click();
    }

    @Then("ThankYouInvestmentPage: Verify info panel text {string} and navigate to Homepage")
    public void thankYouVerifyInfoPanelAndGoToHomepage(String infoPanelText) {
        thankYouInvestmentPage.getInfoPanelText().shouldHave(Condition.text(infoPanelText));
    }
}