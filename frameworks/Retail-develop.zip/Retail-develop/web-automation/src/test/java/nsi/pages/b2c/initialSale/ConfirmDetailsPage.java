package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ConfirmDetailsPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//*[contains(@id, 'name') or contains(@id, 'existingName')]/div")
    private SelenideElement nameMainInvestorText;

    @FindBy(xpath = "//*[@id='name_2']/div")
    private SelenideElement nameSecondInvestorText;

    @FindBy(xpath = "//*[@id='childName_2']/div")
    private SelenideElement nameChildText;

    @FindBy(xpath = "//*[@id='thirdPartyName_2']/div")
    private SelenideElement nameParentText;

    @FindBy(xpath = "//*[contains(@id, 'dateOfBirth_1_fieldLine') or contains(@id, 'existingDateOfBirth_1_fieldLine')]/div")
    private SelenideElement dobMainInvestorText;

    @FindBy(xpath = "//*[@id='dateOfBirth_2_fieldLine']/div")
    private SelenideElement dobSecondInvestorText;

    @FindBy(xpath = "//*[@id='childDateOfBirth_2_fieldLine']/div")
    private SelenideElement dobChildText;

    @FindBy(xpath = "//*[@id='thirdPartyDateOfBirth_2_fieldLine']/div")
    private SelenideElement dobParentText;

    @FindBy(xpath = "//*[contains(@id, 'addressUnauthenticated') or contains(@id, 'authenticatedAddress') ]/div")
    private SelenideElement addressMainInvestorText;

    @FindBy(xpath = "//*[@id='addressSecondInvestor']/div")
    private SelenideElement addressSecondInvestorText;

    @FindBy(xpath = "//*[@id='addressChild']/div")
    private SelenideElement addressChildText;

    @FindBy(xpath = "//*[@id='addressThirdParty']/div")
    private SelenideElement addressParentText;

    @FindBy(xpath = "//*[@id='saleAmount']/div")
    private SelenideElement investmentAmountText;

    @FindBy(id = "reinvest01")
    private SelenideElement reinvestText;

    @FindBy(id = "payToNominated")
    private SelenideElement payToAcctText;

    @FindBy(xpath = "//*[@id='nameOnAccount']/div")
    private SelenideElement accountNameText;

    @FindBy(xpath = "//*[@id='sortCode_fieldLine']/div")
    private SelenideElement sortCodeText;

    @FindBy(xpath = "//*[@id='accountNumber']/div")
    private SelenideElement accountNumberText;

    @FindBy(xpath = "//*[@id='bankReference']/div")
    private SelenideElement rollNumberText;

    @FindBy(id = "prizeNotificationEmail")
    private SelenideElement notifyEmailText;

    @FindBy(id = "prizeNotificationText")
    private SelenideElement notifyTextText;

    @FindBy(xpath = "//div[contains(text(),'Paper')]")
    private SelenideElement notifyPaperText;

    @FindBy(xpath = "//div[contains(text(),'Paperless')]")
    private SelenideElement notifyNoPaperText;

    @FindBy(id = "residentNonUKYes")
    private SelenideElement taxNonUKYesText;

    @FindBy(id = "birthCityFilled")
    private SelenideElement taxNonUKBirthCityText;

    @FindBy(id = "birthCountryFilled")
    private SelenideElement taxNonUKBirthCountryText;

    @FindBy(id = "taxCountryFilled")
    private SelenideElement taxNonUKTaxCountryText;

    @FindBy(id = "taxIdentificationNumberFilled")
    private SelenideElement taxNonUKTINText;

    // BUTTONS
    @FindBy(id = "editPersonalDetails")
    private SelenideElement changeTaxDetailsButton;

    @FindBy(id = "editInvestmentDetails")
    private SelenideElement changeInvestmentDetailsButton;

    @FindBy(id = "editPrizeDetails")
    private SelenideElement changePrizeDetailsButton;

    @FindBy(id = "editNominatedDetails1")
    private SelenideElement changeNominatedDetailsButton;

    @FindBy(id = "editPrizeNotificationDetails")
    private SelenideElement changePrizeNotificationDetailsButton;

    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    // LINKS
    @FindBy(xpath = "//a[contains(.,'Brochure, including customer agreement')]")
    private SelenideElement customerBrochureLink;

    @FindBy(xpath = "//a[contains(.,'Privacy notice')]")
    private SelenideElement privacyLink;

    // CHECKBOXES
    @FindBy(xpath = "//label[contains(.,'Tick to confirm that you’ve had the opportunity to read the above documents.')]")
    private SelenideElement tickToConfirmCheckBox;

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='residentNonUK_2:1']")
    private SelenideElement taxNonUKNOSecondInvestorRadio;

    @FindBy(xpath = "//label[@for='residentNonUK_2:0']")
    private SelenideElement taxNonUKYESSecondInvestorRadio;

    // FIELDS
    @FindBy(id = "birthCity")
    private SelenideElement taxBirthCitySecondInvestorField;

    @FindBy(id = "taxIdentificationNumber")
    private SelenideElement taxIDSecondInvestorField;

    // DROPDOWNS
    @FindBy(id = "birthCountry")
    private SelenideElement taxBirthCountrySecondInvestorSelect;

    @FindBy(id = "taxCountry")
    private SelenideElement taxCountrySecondInvestorSelect;

    // ----------------------------------------------------
}