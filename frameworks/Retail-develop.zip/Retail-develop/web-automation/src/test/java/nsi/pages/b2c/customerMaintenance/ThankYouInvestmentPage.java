package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

@Getter
public class ThankYouInvestmentPage extends Pages {

    // TEXTS

    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    @FindBy(xpath = "//div[contains(@class, 'info-panel')]/p")
    private SelenideElement infoPanelText;

    @FindBy(xpath = "//div[@id='holding']/div")
    private SelenideElement holdersNumberText;

    // FIELDS

    // DROPDOWNS

    // RADIOBUTTONS

    // CHECKBOXES

    // BUTTONS

    @FindBy(xpath = "//a[contains(.,'Your homepage')]")
    private SelenideElement yourHomePageButton;

    @FindBy(xpath = "//a[contains(.,'Back to')]")
    private SelenideElement backToButton;

    @FindAll({
            @FindBy(xpath = "//*[@id='j_id_jsp_415568619_30']/div"),
            @FindBy(xpath = "//*[@id='reference']/div") })
    private SelenideElement referenceNumber;

    @FindAll({
        @FindBy(xpath = "//*[@id='j_id_jsp_415568619_33']/div"),
        @FindBy(xpath = "//*[@id='saleAmount']/div") })
    private SelenideElement amount;

    // LINKS

    // ----------------------------------------------------
}
