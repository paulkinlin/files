package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeCustomerTaxDataPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NChangeCustomerTaxDataSteps extends Steps {

    private B2NChangeCustomerTaxDataPage b2NChangeCustomerTaxDataPage = page(B2NChangeCustomerTaxDataPage.class);

    @And("B2NChangeCustomerTaxDataPage: change: City of birth {string} Country of birth {string} Tax country 1 {string} Tax identification no 1 {string}")
    public void changecustomertaxdatapageChangeCityOfBirthCountryOfBirthTaxCountryTaxIdentificationNo(String cityBirth, String countryBirth,
                                                                                                      String taxCountry, String taxIdentification) {
        switchToFrame("dynamic");

        if (!cityBirth.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getCityOfBirthField().execute(clearAndSetValue(cityBirth));
        }
        if (!countryBirth.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getCountryOfBirthSelect().selectOption(countryBirth);
        }
        if (!taxCountry.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxCountryOneSelect().selectOption(taxCountry);
        }
        if (!taxIdentification.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxIdentificationNoOneField().execute(clearAndSetValue(taxIdentification));
        }
    }

    @And("B2NChangeCustomerTaxDataPage: change: Tax country 2 {string} Tax identification no 2 {string} Tax country 3 {string} Tax identification no 3 {string}")
    public void changecustomertaxdatapageChangeTaxCountryTaxIdentificationNoTaxCountryTaxIdentificationNo(String taxCountryTwo, String taxIdentificationTwo,
                                                                                                          String taxCountryThree, String taxIdentificationThree) {
        switchToFrame("dynamic");

        if (!taxCountryTwo.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxCountryTwoSelect().selectOption(taxCountryTwo);
        }
        if (!taxIdentificationTwo.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxIdentificationNoTwoField().execute(clearAndSetValue(taxIdentificationTwo));
        }
        if (!taxCountryThree.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxCountryThreeSelect().selectOption(taxCountryThree);
        }
        if (!taxIdentificationThree.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxIdentificationNoThreeField().execute(clearAndSetValue(taxIdentificationThree));
        }
    }

    @And("B2NChangeCustomerTaxDataPage: change: Tax country 4 {string} Tax identification no 4 {string} Evidence of identity {string} Evidence of address {string}")
    public void changecustomertaxdatapageChangeTaxCountryTaxIdentificationNoEvidenceOfIdentityEvidenceOfAddress(String taxCountryFour, String taxIdentificationFour,
                                                                                                                String evidenceIdentity, String evidenceAddress) {
        switchToFrame("dynamic");

        if (!taxCountryFour.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxCountryFourSelect().selectOption(taxCountryFour);
        }
        if (!taxIdentificationFour.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getTaxIdentificationNoFourField().execute(clearAndSetValue(taxIdentificationFour));
        }
        if (!evidenceIdentity.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getEvidenceIdentitySelect().selectOption(evidenceIdentity);
        }
        if (!evidenceAddress.isEmpty()) {
            b2NChangeCustomerTaxDataPage.getEvidenceAddressSelect().selectOption(evidenceAddress);
        }
    }

    @And("B2NChangeCustomerTaxDataPage: confirm")
    public void changecustomertaxdatapageConfirm() {
        switchToFrame("dynamic");

        b2NChangeCustomerTaxDataPage.getConfirmButton().click();
    }
}