package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NTransactionAuthorisedPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NTransactionAuthorisedSteps extends Steps {

    private final B2NTransactionAuthorisedPage b2NTransactionAuthorisedPage = page(B2NTransactionAuthorisedPage.class);

    @And("B2NTransactionAuthorisedPage: capture reference")
    public void transactionauthorisedpageCaptureReference() {
        switchToFrame("dynamic");

        Selenide.switchTo().frame(0);
        String referenceNumber = b2NTransactionAuthorisedPage.getReferenceText()
                .execute(waitUntilVisible)
                .getText()
                .substring(b2NTransactionAuthorisedPage.getReferenceText().getText().lastIndexOf(':') + 1)
                .trim();

        getContext().getProductPojoList().getLast().setReferenceNumber(referenceNumber);

        b2NTransactionAuthorisedPage.getConfirmButton().click();
    }

    @And("B2NTransactionAuthorisedPage: check title")
    public void transactionauthorisedpageCheckTitle() {
        switchToFrame("dynamic");

        Selenide.switchTo().frame(0);
        b2NTransactionAuthorisedPage.getTitleText().shouldHave(Condition.text("Transaction Authorised."));
    }
}