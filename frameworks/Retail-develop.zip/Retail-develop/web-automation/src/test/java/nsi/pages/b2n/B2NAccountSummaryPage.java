package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NAccountSummaryPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx11")
    private SelenideElement accountNumberText;

    @FindBy(id = "Tx13")
    private SelenideElement bankProductText;

    @FindBy(id = "Tx14")
    private SelenideElement currencyText;

    @FindBy(id = "Tx15")
    private SelenideElement accountTitleText;

    @FindBy(id = "Ck12")
    private SelenideElement signatureControlCheckbox;

    @FindBy(id = "TxZ1")
    private SelenideElement headroomText;

    @FindBy(id = "TxZ2")
    private SelenideElement currentBalanceText;

    @FindBy(id = "TxZ3")
    private SelenideElement availableAmountText;

    @FindBy(id = "CkZ1")
    private SelenideElement closedCheckbox;

    @FindBy(id = "Tx36")
    private SelenideElement reasonForBlockingText;

    @FindBy(id = "Tx37")
    private SelenideElement blockingDateText;

    @FindBy(id = "Tx38")
    private SelenideElement blockingAuthorityText;

    @FindBy(id = "CkB1")
    private SelenideElement electronicDocumentsCheckbox;

    @FindBy(id = "TxB7")
    private SelenideElement electronicDocumentsModifyText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//a[@href='javascript:submitForm(03)']")
    private SelenideElement backButton;

    //html/body/form/div/table/tbody/tr/td/a[1]/img

    // LINKS

    // ----------------------------------------------------
}