package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NAuthenticateCustomerPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx01")
    private SelenideElement passwordOrderOneText;

    @FindBy(id = "Tx02")
    private SelenideElement passwordOrderTwoText;

    // FIELDS
    @FindBy(id = "Ed01ZOF")
    private SelenideElement passwordOneField;

    @FindBy(id = "Ed02ZO")
    private SelenideElement passwordTwoField;

    @FindBy(id = "Ed01FZO")
    private SelenideElement customerIDField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}