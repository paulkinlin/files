package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class TakeMoneyOutCloseAccountPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    @FindBy(xpath = ("//*[contains(text(),'Continue with transfer but keep my account open')]"))
    private SelenideElement continueWithTransferText;

    @FindBy(xpath = ("//*[contains(text(),'Yes I want to close my account')]"))
    private SelenideElement closeMyAccountText;

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='closureRadios:0']")
    private SelenideElement continueWithTransferRadio;

    @FindBy(xpath = "//label[@for='closureRadios:1']")
    private SelenideElement yesCloseAccountRadio;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}