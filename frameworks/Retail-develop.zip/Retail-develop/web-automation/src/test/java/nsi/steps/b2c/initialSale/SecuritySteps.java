package nsi.steps.b2c.initialSale;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.SecurityPage;
import nsi.pojos.ClientDataPojo;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.BaseClass.generateRandomNumber;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;

@Slf4j
public class SecuritySteps extends Steps {

    private SecurityPage securityPage = page(SecurityPage.class);

    @When("SecurityPage: enter password")
    public void securityPageEnterPasswordConfPass() {
        securityPage.getPasswordField().execute(clearAndSetValue(SECURITY_PASSWORD));
        securityPage.getConfirmPasswordField().execute(clearAndSetValue(SECURITY_PASSWORD));
    }

    @When("SecurityPage: enter password {string} confPass {string}")
    public void securityPageEnterPasswordConfPass(String password, String confirmPassword) {
        if (password.equals("pass")) {
            password = SECURITY_PASSWORD;
        }
        if (confirmPassword.equals("pass")) {
            confirmPassword = SECURITY_PASSWORD;
        }
        securityPage.getPasswordField().execute(clearAndSetValue(password));
        securityPage.getConfirmPasswordField().execute(clearAndSetValue(confirmPassword));
    }

    @When("SecurityPage: choose security questions and answers")
    public void securityPageChooseSecurityQuestionsAndAnswers() {

        String questionOne;
        String questionTwo;
        String questionThree;

        String answerOne;
        String answerTwo;
        String answerThree;

        do {
            questionOne = selectRandomQuestion(securityPage.getQuestion1Select());

            do {
                questionTwo = selectRandomQuestion(securityPage.getQuestion2Select());
            } while (questionTwo.equals(questionOne));

            do {
                questionThree = selectRandomQuestion(securityPage.getQuestion3Select());

            } while (questionThree.equals(questionOne) || questionThree.equals(questionTwo));

            answerOne = questionOne.substring(questionOne.lastIndexOf(' ') + 1);
            answerTwo = questionTwo.substring(questionTwo.lastIndexOf(' ') + 1);
            answerThree = questionThree.substring(questionThree.lastIndexOf(' ') + 1);

        } while (answerOne.equals(answerTwo) || answerTwo.equals(answerThree) || answerOne.equals(answerThree));

        securityPage.getAnswer1Field().execute(clearAndSetValue(answerOne));
        securityPage.getAnswer2Field().execute(clearAndSetValue(answerTwo));
        securityPage.getAnswer3Field().execute(clearAndSetValue(answerThree));

        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();
        mainInvestor.setAnswerQuestion1(answerOne);
        mainInvestor.setAnswerQuestion2(answerTwo);
        mainInvestor.setAnswerQuestion3(answerThree);

        log.info("Question 1: {}, Answer 1 {}", questionOne, answerOne);
        log.info("Question 2: {}, Answer 2 {}", questionTwo, answerTwo);
        log.info("Question 3: {}, Answer 3 {}", questionThree, answerThree);
    }

    private String selectRandomQuestion(SelenideElement element) {
        int sizeDropdown = (element.$$(By.tagName("option"))).size() - 2;
        element.execute(waitUntilEnabled).selectOption(generateRandomNumber(1, sizeDropdown));
        return element.
                getSelectedText().replaceAll("\\(([\\s\\S]*)\\)", "").
                replace("?", "")
                .trim();
    }

    @And("SecurityPage: choose {string} security question")
    public void securityPageChooseWhatSecurityQuestion(String numberOfQuestion) {
        $(By.id("securityQuestion" + numberOfQuestion))
                .findAll(By.tagName("option"))
                .last()
                .click();
    }

    @And("NSIInitialSale enter {string} security answer")
    public void securityPageEnterSecurityAnswer(String numberOfAnswer) {
        $(By.id("securityAnswer" + numberOfAnswer))
                .execute(clearAndSetValue(Integer.toString(generateRandomNumber(1, 10000))));
    }

    @When("SecurityPage: enter email for main investor")
    public void securityPageEnterEmailForMainInvestor() {
        ClientDataPojo client = getContext().getMainInvestorClientData();

        enterEmail(client.getEmail(), client.getEmail());
    }

    @When("SecurityPage: enter email {string} confEmail {string}")
    public void securityPageEnterEmailConfEmail(String email, String confEmail) {
        enterEmail(email, confEmail);

        getContext().getMainInvestorClientData().setEmail(email);
    }

    private void enterEmail(String email, String confEmail) {
        securityPage.getEmailField().execute(clearAndSetValue(email));
        securityPage.getConfirmEmailField().execute(clearAndSetValue(confEmail));
    }

    @When("SecurityPage: enter ctryCode {string} phoneNo for main investor")
    public void securityPageEnterCtryCodePhoneNo(String ctryCode) {
        securityPage.getCountryCode1Select().selectOptionContainingText(ctryCode);

        ClientDataPojo client = getContext().getMainInvestorClientData();

        enterPhoneNo1(client.getPhoneNumber());
    }

    @When("SecurityPage: press continue button")
    public void SecurityPagePressContinueButton() {
        securityPage.getContinueButton().click();
    }

    @When("SecurityPage: enter ctryCode {string} phoneNo {string}")
    public void securityPageEnterCtryCodePhoneNo(String ctryCode, String phoneNo) {
        securityPage.getCountryCode1Select().selectOptionContainingText(ctryCode);

        enterPhoneNo1(phoneNo);

        getContext().getMainInvestorClientData().setPhoneNumber(phoneNo);
    }

    private void enterPhoneNo1(String phoneNo) {
        securityPage.getPhoneNo1Field().execute(clearAndSetValue(phoneNo));
    }

    @When("SecurityPage: fill tax nonUK second investor {string} city {string} country {string} tax country {string} tax number {string}")
    public void securityPageSubmitTaxStatusSecondInvestor(String tax, String city,
                                                          String country, String taxCountry,
                                                          String taxNumber) {
        switch (tax.toLowerCase()) {
            case "yes":
                securityPage.getTaxNonUKYESSecondInvestorRadio().click();

                securityPage.getTaxBirthCitySecondInvestorField().execute(clearAndSetValue(city));
                securityPage.getTaxBirthCountrySecondInvestorSelect().selectOptionContainingText(country);
                securityPage.getTaxCountrySecondInvestorSelect().selectOptionContainingText(taxCountry);
                securityPage.getTaxIDSecondInvestorField().execute(clearAndSetValue(taxNumber));
                break;
            case "no":
                securityPage.getTaxNonUKNOSecondInvestorRadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("SecurityPage: submit marketingPrefs post {string} email {string} phone {string} onLine {string}")
    public void securityPageSubmitMarketingPrefsPostEmailPhoneOnLineMmainInvestor(String post, String email,
                                                                                  String phone, String online) {
        if (post.equalsIgnoreCase("no")) {
            securityPage.getNoPostCheckbox().click();
            getContext().setMarketingPreferenceByPost(false);
        }
        if (email.equalsIgnoreCase("no")) {
            securityPage.getNoEmailCheckbox().click();
            getContext().setMarketingPreferenceByEmail(false);
        }
        if (phone.equalsIgnoreCase("no")) {
            securityPage.getNoPhoneCheckbox().click();
            getContext().setMarketingPreferenceByPhone(false);
        }
        if (online.equalsIgnoreCase("no")) {
            securityPage.getNoWebCheckbox().click();
            getContext().setMarketingPreferenceOnline(false);
        }
        log.info("Submitted marketing prefs: POST {}, EMAIL {}, PHONE {}, WEB {}", post, email, phone, online);

        securityPage.getContinueButton().click();
    }

    @When("SecurityPage: submit marketingPrefs second investor post {string} email {string} phone {string} onLine {string}")
    public void securityPageSubmitMarketingPrefsPostEmailPhoneOnLineSecondInvestor(String post, String email,
                                                                                   String phone, String online) {
        if (post.equalsIgnoreCase("no")) {
            securityPage.getNoPostSecondInvestorCheckbox().click();
        }
        if (email.equalsIgnoreCase("no")) {
            securityPage.getNoEmailSecondInvestorCheckbox().click();
        }
        if (phone.equalsIgnoreCase("no")) {
            securityPage.getNoPhoneSecondInvestorCheckbox().click();
        }
        if (online.equalsIgnoreCase("no")) {
            securityPage.getNoWebSecondInvestorCheckbox().click();
        }
        log.info("Submitted marketing prefs: POST {}, EMAIL {}, PHONE {}, WEB {}", post, email, phone, online);
    }

    @When("SecurityPage: choose your application {string}")
    public void securityPageChooseYourApplication(String option) {
        switch (option.toLowerCase()) {
            case "i am applying for my child under 18":
                securityPage.getUnder18Radio().click();
                break;
            case "i am 16/17 and applying for myself":
                securityPage.getForMyselfRadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("SecurityPage: enter nino {string}")
    public void securityPageEnterNino(String nino) {
        setValueNino(nino);
    }

    private void setValueNino(String nino) {
        securityPage.getNino1Field().execute(clearAndSetValue(nino.substring(0, 2)));
        securityPage.getNino2Field().execute(clearAndSetValue(nino.substring(2, 4)));
        securityPage.getNino3Field().execute(clearAndSetValue(nino.substring(4, 6)));
        securityPage.getNino4Field().execute(clearAndSetValue(nino.substring(6, 8)));
        securityPage.getNino5Field().execute(clearAndSetValue(nino.substring(8, 9)));
    }

    @Then("SecurityPage: verify security {string} error message displays {string}")
    public void securityPageVerifySecurityErrorMessageDisplays(String errorField, String errorMsg) {
        SelenideElement element = null;

        switch (errorField.toLowerCase()) {
            case "password":
                element = securityPage.getPasswordFieldError();
                break;
            case "confpassword":
                element = securityPage.getConfirmPwdFieldError();
                break;
            case "question1":
                element = securityPage.getSecurityQuestion1Error();
                break;
            case "question2":
                element = securityPage.getSecurityQuestion2Error();
                break;
            case "question3":
                element = securityPage.getSecurityQuestion3Error();
                break;
            case "answer1":
                element = securityPage.getSecurityAnswer1Error();
                break;
            case "answer2":
                element = securityPage.getSecurityAnswer2Error();
                break;
            case "answer3":
                element = securityPage.getSecurityAnswer3Error();
                break;
            case "emailaddress":
                element = securityPage.getEmailAddressFieldError();
                break;
            case "emailconfaddress":
                element = securityPage.getEmailConfAddressFieldError();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }

        element.execute(waitUntilAppears).shouldHave(Condition.text(errorMsg));
    }
}