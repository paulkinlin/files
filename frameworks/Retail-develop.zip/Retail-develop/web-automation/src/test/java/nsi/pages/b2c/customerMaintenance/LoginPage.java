package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class LoginPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//label[@for='j_password_pwd']")
    private SelenideElement passwordText;

    @FindBy(xpath = "//label[@for='j_username_pwd']")
    private SelenideElement surnameText;

    @FindBy(xpath = "//label[@for='j_userlogin_pwd']")
    private SelenideElement nsiNumberText;

    @FindBy(xpath = "//h2[contains(.,'Log in or register')]")
    private SelenideElement loginOrRegisterText;

    // FIELDS
    @FindBy(id = "j_password_pwd")
    private SelenideElement passwordField;

    @FindBy(id = "j_username_pwd")
    private SelenideElement surnameField;

    @FindBy(id = "j_userlogin_pwd")
    private SelenideElement nsiNumberField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnValidate")
    private SelenideElement loginButton;

    @FindBy(xpath = "//a[contains(.,'Register now')]")
    private SelenideElement registerNowButton;

    // LINKS
    @FindBy(id = "forgottenPass")
    private SelenideElement forgotPasswordLink;

    @FindBy(id = "forgottenUci")
    private SelenideElement forgotNSINumberLink;

    // ----------------------------------------------------
}