package nsi.utils;

import com.codeborne.selenide.Command;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.JavascriptExecutor;

import static com.codeborne.selenide.Condition.and;
import static nsi.utils.waitUtils.setDriver;
import static nsi.utils.waitUtils.waitAllRequest;

/**
 * Class with customs commands that can be performed on SelenideElements. Commands can be chained.
 * Class must be imported: 'import static nsi.utils.CustomCommands.*;'
 * Example: SelenideElement.execute(name of custom command) like: titleSelect.execute(waitUntilVisible);
 */

public class CustomCommands {

    public static final int POLLING_INTERVAL = 100;
    public static final int MAXIMUM_WAIT_TIME = 20000;

    public static Command<SelenideElement> waitUntilVisible = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.visible, MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> waitUntilAppears = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.appears, MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> waitUntilEnabled = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.enabled, MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> waitUntilClickable = (proxy, locator, args) -> {
        proxy.waitUntil(and("Not clickable", Condition.visible, Condition.enabled), MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> isHidden = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.hidden, MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> waitUntilIsSelected = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.selected, MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> waitUntilAttributeCheckedPresented = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.attribute("checked"), MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> waitUntilAttributeLogoActivePresented = (proxy, locator, args) -> {
        proxy.waitUntil(Condition.attribute("class", "logo active"), MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
        return proxy;
    };

    public static Command<SelenideElement> jsClick = (proxy, locator, args) -> {
        JavascriptExecutor executorJS = (JavascriptExecutor) WebDriverRunner.getWebDriver();
        executorJS.executeScript("arguments[0].click();", proxy);
        return proxy;
    };

    public static Command<SelenideElement> clickAndWait = (proxy, locator, args) -> {
        proxy.click();
        setDriver(WebDriverRunner.getWebDriver());
        waitAllRequest();
        return proxy;
    };

    public static Command<SelenideElement> clearAndSetValue(String value) {
        return (proxy, locator, args) -> {
            proxy.waitUntil(Condition.visible, MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
            proxy.clear();
            proxy.setValue(value);
            return proxy;
        };
    }

    public static Command<SelenideElement> waitUntilConditionText(String value) {
        return (proxy, locator, args) -> {
            proxy.waitUntil(Condition.text(value), MAXIMUM_WAIT_TIME, POLLING_INTERVAL);
            return proxy;
        };
    }
}

