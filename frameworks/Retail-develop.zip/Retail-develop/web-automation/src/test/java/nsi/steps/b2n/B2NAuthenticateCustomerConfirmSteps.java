package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NAuthenticateCustomerConfirmPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class B2NAuthenticateCustomerConfirmSteps extends Steps {

    private final static String SUCCESS_AUTHENTICATION_MESSAGE = "The customer has been authenticated. Choose an operation in the left window.";

    private final B2NAuthenticateCustomerConfirmPage b2NAuthenticateCustomerConfirmPage = page(B2NAuthenticateCustomerConfirmPage.class);

    @And("B2NAuthenticateCustomerConfirmPage: validate CustomerName {string} and confirm")
    public void authenticatecustomerconfirmpageValidateCustomerNameAddressAndConfirm(String customerName) {
        switchToFrame("dynamic");

        b2NAuthenticateCustomerConfirmPage.getCustomerNameText().shouldHave(Condition.text(customerName));

        b2NAuthenticateCustomerConfirmPage.getConfirmButton().click();

        b2NAuthenticateCustomerConfirmPage.getConfirmInfoText().shouldHave(Condition.text(SUCCESS_AUTHENTICATION_MESSAGE));
    }

    @And("B2NAuthenticateCustomerConfirmPage: click confirm")
    public void b2NAuthenticateCustomerConfirmPageClickConfirm() {
        b2NAuthenticateCustomerConfirmPage.getConfirmButton().click();
        switchToFrame("dynamic");
        if ($(By.xpath("//form[@name='form1']//strong[contains(text(),'Security details')]")).isDisplayed()) {
            new B2NSecurityDetailsSteps().securitydetailspageSubmitAnswers();
        }
    }

    @And("B2NAuthenticateCustomerConfirmPage: validate CustomerName from JSON {string} and confirm")
    public void b2NAuthenticateCustomerConfirmPageValidateCustomerNameFromJSONBNAndConfirm(String jsonFile) throws IOException, ParseException {
        String title = getContext().getMainInvestorClientData().getTitle();
        String foreName = getContext().getMainInvestorClientData().getForeName();
        String surName = getContext().getMainInvestorClientData().getSurName();

        authenticatecustomerconfirmpageValidateCustomerNameAddressAndConfirm(title + " " + foreName.charAt(0) + " " + surName);
    }

    @And("B2NAuthenticateCustomerConfirmPage: check confirmation text")
    public void b2NAuthenticateCustomerCheckConfirmationText() {
        b2NAuthenticateCustomerConfirmPage.getConfirmInfoText().shouldHave(Condition.text(SUCCESS_AUTHENTICATION_MESSAGE));
    }
}