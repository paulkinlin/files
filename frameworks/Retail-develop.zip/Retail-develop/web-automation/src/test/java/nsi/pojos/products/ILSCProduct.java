package nsi.pojos.products;

public class ILSCProduct extends ProductPojo {
}
