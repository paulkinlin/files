package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class GiftCardPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "giftCertificateTo")
    private SelenideElement giftCardToField;

    @FindBy(id = "giftCertificateFrom")
    private SelenideElement giftCardFromField;

    @FindBy(id = "giftCertificateMessage")
    private SelenideElement giftCardMessageField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    @FindBy(xpath = "//label[@for='giftCertificateRequestValue:0']")
    private SelenideElement giftCardYesRadio;

    @FindBy(xpath = "//label[@for='giftCertificateRequestValue:1']")
    private SelenideElement giftCardNoRadio;

    @FindBy(xpath = "//label[@for='giftCardSendOptionsValue:0']")
    private SelenideElement giftCardByPostRadio;

    @FindBy(xpath = "//label[@for='giftCardSendOptionsValue:1']")
    private SelenideElement giftCardElectronicallyRadio;

    // LINKS

    // ----------------------------------------------------
}