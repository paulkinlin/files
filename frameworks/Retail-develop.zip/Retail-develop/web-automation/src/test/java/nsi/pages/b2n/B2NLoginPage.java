package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NLoginPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(xpath = "//input[@name='id']")
    private SelenideElement loginField;

    @FindBy(xpath = "//input[@name='password']")
    private SelenideElement passwordField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm01")
    private SelenideElement sendButton;

    @FindBy(xpath = "//input[@value='Clear']")
    private SelenideElement clearButton;

    // LINKS

    // ----------------------------------------------------
}