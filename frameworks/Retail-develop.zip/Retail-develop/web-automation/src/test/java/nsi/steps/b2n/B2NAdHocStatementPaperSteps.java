package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NAdHocStatementPage;
import nsi.steps.Steps;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NAdHocStatementPaperSteps extends Steps {

    private final B2NAdHocStatementPage b2NAdHocStatementPage = page(B2NAdHocStatementPage.class);

    @And("B2NAdHocStatementPaperPage: submit account number from json file {string}")
    public void adHocStatementPageSubmitAccountNumber(String jsonFile) throws IOException, ParseException {
        switchToFrame("dynamic");
        String surname = getContext().getMainInvestorClientData().getSurName();
        b2NAdHocStatementPage.getAccountNumberDropdown().execute(waitUntilVisible).selectOptionContainingText(surname);
        submitNextButton();
    }

    @And("B2NAdHocStatementPaperPage: verify no statement text")
    public void adHocStatementPageNegativeText() {
        switchToFrame("dynamic");
        b2NAdHocStatementPage.getNoStatementText()
                .execute(waitUntilVisible)
                .shouldBe(Condition.text("This summary contains no items"));
    }

    @And("B2NAdHocStatementPaperPage: verify succesful statement request text")
    public void adHocStatementPagePositiveText() {
        switchToFrame("dynamic");
        b2NAdHocStatementPage.getAdHocStatementText()
                .execute(waitUntilVisible)
                .shouldBe(Condition.text("The ad hoc statement request has been successfully generated."));
    }

    @And("B2NAdHocStatementPaperPage: verify statement type in a Summary of Account Statements")
    public void adHocStatementText() {
        switchToFrame("dynamic");
        b2NAdHocStatementPage.getStatementType()
                .execute(waitUntilVisible)
                .shouldBe(Condition.text("Ad hoc statement"));
    }


    @And("B2NAdHocStatementPaperPage: submit next button")
    public void submitNextButton() {
        switchToFrame("dynamic");

        b2NAdHocStatementPage.getConfirmButton()
                .execute(waitUntilVisible)
                .click();
    }
}