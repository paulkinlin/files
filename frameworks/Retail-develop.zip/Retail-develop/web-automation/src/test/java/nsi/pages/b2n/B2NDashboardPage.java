package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NDashboardPage extends Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS
    @FindBy(id = "ddimagetabs")
    private SelenideElement topMenu;

    @FindBy(id = "shortcuts")
    private SelenideElement shortcutsMenu;

    @FindBy(id = "masterdiv")
    private SelenideElement leftMenu;

    // ----------------------------------------------------

}