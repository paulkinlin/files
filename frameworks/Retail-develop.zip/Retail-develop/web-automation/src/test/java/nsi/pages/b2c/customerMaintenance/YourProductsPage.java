package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class YourProductsPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[contains(@class, 'account-select theme-ns')]")
    private ElementsCollection productTitles;

    @FindBy(xpath = "//*[contains(text(), 'Account number')]/strong")
    private ElementsCollection accountNumberText;

    @FindBy(xpath = "(//*[contains(text(), 'Balance')]/strong | //div[contains(@id,'currentBalance')]/div)")
    private ElementsCollection balanceText;

    @FindBy(xpath = "(//div[contains(@id,'currentBalance')]/div)")
    private SelenideElement balanceSingleElementText;

    @FindBy(xpath = "//div[@id='availableBalance']/div")
    private SelenideElement availableBalanceText;

    @FindBy(xpath = "//*[@id='accountName']/div")
    private SelenideElement accountName;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//a[contains(text(),'Take money out')]")
    private SelenideElement takeMoneyOutButton;

    @FindBy(xpath = "//a[contains(text(),'Pay money in') or contains(text(), 'Buy more')]")
    private SelenideElement payMoneyInButton;

    // LINKS

    // ----------------------------------------------------
}