package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourTaxDetailsPage extends Pages {

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='residentNonUK:0']")
    private SelenideElement taxNonUKYESRadio;

    @FindBy(xpath = "//label[@for='residentNonUK:1']")
    private SelenideElement taxNonUKNORadio;

    // FIELDS
    @FindBy(id = "birthCity")
    private SelenideElement taxBirthCityMainInvestorField;

    @FindBy(id = "taxIdentificationNumber")
    private SelenideElement taxIDMainInvestorField;

    // DROPDOWNS
    @FindBy(id = "birthCountry")
    private SelenideElement taxBirthCountryMainInvestorSelect;

    @FindBy(id = "taxCountry")
    private SelenideElement taxCountryMainInvestorSelect;

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement continueButton;

    // CHECKBOXES
    @FindBy(xpath = "//label[@for='noTaxIdentificationNumber']")
    private SelenideElement tinCheckbox;

    // ----------------------------------------------------
}