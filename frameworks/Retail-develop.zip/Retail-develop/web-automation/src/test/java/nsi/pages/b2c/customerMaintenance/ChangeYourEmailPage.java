package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourEmailPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//h1[contains(., 'Change your email address')]")
    private SelenideElement titleText;

    @FindBy(xpath = "//div[@id='emailAddress']//div")
    private SelenideElement currentEmailText;

    // FIELDS
    @FindBy(id = "newEmailAddress")
    private SelenideElement newEmailField;

    @FindBy(id = "newEmailAddressVerification")
    private SelenideElement confirmNewEmailField;

    // DROPDOWNS

    // RADIOBUTTONS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement continueButton;

    // LINKS

    // ----------------------------------------------------
}