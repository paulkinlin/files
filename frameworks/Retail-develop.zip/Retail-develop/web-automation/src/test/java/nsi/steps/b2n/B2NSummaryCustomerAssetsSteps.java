package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NSummaryCustomerAssetsPage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NSummaryCustomerAssetsSteps extends Steps {

    private final B2NSummaryCustomerAssetsPage b2NSummaryCustomerAssetsPage = page(B2NSummaryCustomerAssetsPage.class);

    @And("B2NSummaryCustomerAssetsPage: select product {string}")
    public void summarycustomerassetspageSelectProduct(String productName) {

        switchToFrame("dynamic");
        ElementsCollection lines = b2NSummaryCustomerAssetsPage.getProductsTexts();

        for (SelenideElement line : lines) {
            if (line.getText().toLowerCase().equals(productName.toLowerCase())) {
                line.parent().find("td input").click();
                break;
            }
        }
    }

    @And("B2NSummaryCustomerAssetsPage: check product {string} total value {string} and headroom {string}")
    public void summarycustomerassetspageCheckProductValueHeadroom(String product, String value, String headroom) {
        switchToFrame("dynamic");
        verifyPageTitle("Summary of customer's assets");

        b2NSummaryCustomerAssetsPage.getProductText().execute(waitUntilVisible).shouldHave(Condition.text(product));
        b2NSummaryCustomerAssetsPage.getTotalValueText().execute(waitUntilVisible).shouldHave(Condition.text(value));
        b2NSummaryCustomerAssetsPage.getHeadroomText().execute(waitUntilVisible).shouldHave(Condition.text(headroom));

        if(!(getContext().getProductPojoList().getFirst() instanceof PremiumBondProduct)) {
            getContext()
                    .getProductPojoList()
                    .getFirst()
                    .setAccountNumber(b2NSummaryCustomerAssetsPage.getHoldingAccountText().getText());
        } else {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList()
                    .getFirst())
                    .setHoldersNumber(b2NSummaryCustomerAssetsPage.getHoldingAccountText().getText()); }
        getContext().getProductPojoList().getFirst().setHeadroom(b2NSummaryCustomerAssetsPage.getHeadroomText().getText());
    }

    @And("B2NSummaryCustomerAssetsPage: check last product {string} total value {string} and headroom {string}")
    public void summarycustomerassetspageCheckLastProductValueHeadroom(String product, String value, String headroom) {
        switchToFrame("dynamic");
        verifyPageTitle("Summary of customer's assets");

        b2NSummaryCustomerAssetsPage.getProductText().execute(waitUntilVisible).shouldHave(Condition.text(product));
        b2NSummaryCustomerAssetsPage.getTotalValueText().execute(waitUntilVisible).shouldHave(Condition.text(value));
        b2NSummaryCustomerAssetsPage.getHeadroomText().execute(waitUntilVisible).shouldHave(Condition.text(headroom));

        getContext().getProductPojoList().getLast().setAccountNumber(b2NSummaryCustomerAssetsPage.getHoldingAccountText().getText());
        getContext().getProductPojoList().getLast().setHeadroom(b2NSummaryCustomerAssetsPage.getHeadroomText().getText());
    }

    @And("B2NSummaryCustomerAssetsPage: click {string}")
    public void summarycustomerassetspageClick(String buttonName) {
        switchToFrame("dynamic");

        switch (buttonName.toLowerCase()) {
            case "next":
                b2NSummaryCustomerAssetsPage.getNextButton().click();
                break;
            case "back":
                b2NSummaryCustomerAssetsPage.getBackButton().click();
                break;
            case "detailed view":
                b2NSummaryCustomerAssetsPage.getDetailedViewButton().click();
                break;
            case "customer details":
                b2NSummaryCustomerAssetsPage.getCustomerDetailsButton().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NSummaryCustomerAssetsPage: verify portfolio is empty")
    public void summarycustomerassetspageCheckProductValueHeadroom() {
        switchToFrame("dynamic");
        verifyPageTitle("Summary of customer's assets");
        b2NSummaryCustomerAssetsPage.getNoItemsSummaryTable().shouldHave(Condition.text("This summary contains no items"));
    }
}