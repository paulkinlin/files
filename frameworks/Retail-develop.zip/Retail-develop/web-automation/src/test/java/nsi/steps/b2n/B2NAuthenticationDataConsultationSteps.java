package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NAuthenticationDataConsultationPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NAuthenticationDataConsultationSteps extends Steps {

    private B2NAuthenticationDataConsultationPage b2NAuthenticationDataConsultationPage = page(B2NAuthenticationDataConsultationPage.class);

    @And("B2NAuthenticationDataConsultationPage: name {string} status {string} cDate {string} vDate {string} aDate {string} user {string}")
    public void authenticationdataconsultationpageNameStatusCDateVDateADateUser(String name, String status,
                                                                                String cDate, String vDate,
                                                                                String aDate, String user) {
        switchToFrame("dynamic");

        if (!name.isEmpty()) {
            b2NAuthenticationDataConsultationPage.getNameText().shouldHave(Condition.text(name));
        }
        if (!status.isEmpty()) {
            b2NAuthenticationDataConsultationPage.getStatusText().shouldHave(Condition.text(status));
        }
        if (!cDate.isEmpty()) {
            b2NAuthenticationDataConsultationPage.getCDateText().shouldHave(Condition.text(cDate));
        }
        if (!vDate.isEmpty()) {
            b2NAuthenticationDataConsultationPage.getVDateText().shouldHave(Condition.text(vDate));
        }
        if (!aDate.isEmpty()) {
            b2NAuthenticationDataConsultationPage.getADateText().shouldHave(Condition.text(aDate));
        }
        if (!user.isEmpty()) {
            b2NAuthenticationDataConsultationPage.getUserText().shouldHave(Condition.text(user));
        }
    }
}