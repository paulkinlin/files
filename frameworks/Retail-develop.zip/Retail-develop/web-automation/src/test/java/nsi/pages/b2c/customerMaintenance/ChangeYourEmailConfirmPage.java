package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourEmailConfirmPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h2")
    private SelenideElement titleText;

    // FIELDS

    // DROPDOWNS

    // RADIOBUTTONS

    // CHECKBOXES

    // BUTTONS

    @FindBy(id = "btnNext")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}