package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeYourSecurityTelephoneNumberPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ed04")
    private SelenideElement phoneNumberOneField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm80")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
