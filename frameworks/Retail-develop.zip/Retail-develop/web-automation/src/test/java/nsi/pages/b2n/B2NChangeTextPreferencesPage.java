package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeTextPreferencesPage extends Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES
    @FindBy(id = "RdA101")
    private SelenideElement allowCheckbox;

    @FindBy(id = "RdA102")
    private SelenideElement stopCheckbox;

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
