package nsi.pojos.products;

public class JisaProduct extends ProductPojo {
}
