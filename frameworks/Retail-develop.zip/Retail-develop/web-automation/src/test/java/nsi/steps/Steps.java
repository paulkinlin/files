package nsi.steps;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public abstract class Steps {

    protected static final String SECURITY_PASSWORD = System.getenv("userPass");
    protected static final String B2O_SECURITY_PASSWORD = System.getenv("b2oPass");

    public void switchToFrame(String frameName) {
        String frame = "";

        if (frameName.equals("default")) {
            Selenide.switchTo().innerFrame("top");
        } else {
            switch (frameName) {
                case "topFrame":
                    frame = frameName;
                    break;
                case "dynamic":
                    frame = frameName;
                    break;
                case "error":
                    frame = frameName;
                    break;
                case "menu":
                    frame = frameName;
                    break;
                default:
                    Assert.fail("No such frame");
            }
            Selenide.switchTo().innerFrame(frame);
        }
    }

    protected void verifyPageTitle(String title) {
        $(By.xpath("//form[@name='form1']")).shouldHave(Condition.text(title));
    }
}