package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangePasswordPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NChangePasswordSteps extends Steps {

    private B2NChangePasswordPage b2NChangePasswordPage = page(B2NChangePasswordPage.class);

    @And("B2NChangePasswordPage: submit Security details answers")
    public void changepasswordpageSubmitSecurityDetailsAnswers() {
        switchToFrame("dynamic");
        verifyPageTitle("Security details");

        final String questionsOneFieldValue = b2NChangePasswordPage.getQuestionOneField().getText().replaceAll("\\(([\\s\\S]*)\\)", "").replace("?", "").trim();
        final String questionsTwoFieldValue = b2NChangePasswordPage.getQuestionTwoField().getText().replaceAll("\\(([\\s\\S]*)\\)", "").replace("?", "").trim();

        String questionOneLastWord = questionsOneFieldValue.substring(questionsOneFieldValue.lastIndexOf(' ') + 1);
        String questionTwoLastWord = questionsTwoFieldValue.substring(questionsTwoFieldValue.lastIndexOf(' ') + 1);

        b2NChangePasswordPage.getAnswerOneField().execute(clearAndSetValue(questionOneLastWord));
        b2NChangePasswordPage.getAnswerTwoField().execute(clearAndSetValue(questionTwoLastWord));

        b2NChangePasswordPage.getConfirmButton().click();
    }
}
