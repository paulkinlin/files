package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeCustomerTaxDataPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ed02")
    private SelenideElement cityOfBirthField;

    @FindBy(id = "Cb02")
    private SelenideElement countryOfBirthSelect;

    @FindBy(id = "Cb01")
    private SelenideElement taxCountryOneSelect;

    @FindBy(id = "Ed01")
    private SelenideElement taxIdentificationNoOneField;

    @FindBy(id = "Cb11")
    private SelenideElement taxCountryTwoSelect;

    @FindBy(id = "Ed11")
    private SelenideElement taxIdentificationNoTwoField;

    @FindBy(id = "Cb12")
    private SelenideElement taxCountryThreeSelect;

    @FindBy(id = "Ed12")
    private SelenideElement taxIdentificationNoThreeField;

    @FindBy(id = "Cb13")
    private SelenideElement taxCountryFourSelect;

    @FindBy(id = "Ed13")
    private SelenideElement taxIdentificationNoFourField;

    @FindBy(id = "Cb03")
    private SelenideElement evidenceIdentitySelect;

    @FindBy(id = "Cb04")
    private SelenideElement evidenceAddressSelect;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}