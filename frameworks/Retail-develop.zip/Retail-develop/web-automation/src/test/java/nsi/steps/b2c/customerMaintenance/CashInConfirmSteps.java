package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.CashInConfirmPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class CashInConfirmSteps extends Steps {
    private CashInConfirmPage cashInConfirmPage = page(CashInConfirmPage.class);

    @Then("CashInConfirmPage: validate amount {string} and submit")
    public void cashInConfirm(String amount) {
        cashInConfirmPage.getHeaderText().shouldBe(Condition.visible);
        cashInConfirmPage.getAmountText().shouldHave(Condition.exactText(amount));
        cashInConfirmPage.getConfirmButton().click();
    }
}