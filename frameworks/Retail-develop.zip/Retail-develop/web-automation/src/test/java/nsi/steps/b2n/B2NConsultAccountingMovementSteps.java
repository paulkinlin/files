package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NConsultAccountingMovementPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class B2NConsultAccountingMovementSteps extends Steps {

    private final B2NConsultAccountingMovementPage b2NConsultAccountingMovementPage = page(B2NConsultAccountingMovementPage.class);

    @And("B2NConsultAccountingMovementPage: verify Account {string} ODate {string} VDate {string} KO {string} AM {string} OR {string} AD {string}")
    public void consultaccountingmovementpageVerifyAccountODateVDateKOAMORAD(String account, String operationDate,
                                                                             String valueDate, String kindOfOperation,
                                                                             String amountOfTheMovement, String operationReference,
                                                                             String accountingDate) {
        switchToFrame("dynamic");

        if (!account.isEmpty()) {
            b2NConsultAccountingMovementPage.getAccountText().shouldHave(Condition.exactText(account));
        }
        if (!operationDate.isEmpty()) {
            b2NConsultAccountingMovementPage.getOperationDateText().shouldHave(Condition.exactText(operationDate));
        }
        if (!valueDate.isEmpty()) {
            b2NConsultAccountingMovementPage.getValueDateText().shouldHave(Condition.exactText(valueDate));
        }
        if (!kindOfOperation.isEmpty()) {
            b2NConsultAccountingMovementPage.getKindOfOperationText().shouldHave(Condition.exactText(kindOfOperation));
        }
        if (!amountOfTheMovement.isEmpty()) {
            b2NConsultAccountingMovementPage.getAmountOfTheMovementText().shouldHave(Condition.exactText(amountOfTheMovement));
        }
        if (!operationReference.isEmpty()) {
            b2NConsultAccountingMovementPage.getOperationReferenceText().shouldHave(Condition.exactText(operationReference));
        }
        if (!accountingDate.isEmpty()) {
            b2NConsultAccountingMovementPage.getAccountingDateText().shouldHave(Condition.exactText(accountingDate));
        }
    }

    @And("B2NConsultAccountingMovementPage: verify context account ODate {string} VDate {string} KO {string} AM {string} OR {string} AD {string}")
    public void consultaccountingmovementpageVerifyAccountODateVDateKOAMORADfromJson(String operationDate,
                                                                             String valueDate, String kindOfOperation,
                                                                             String amountOfTheMovement, String operationReference,
                                                                             String accountingDate) {
        switchToFrame("dynamic");

        b2NConsultAccountingMovementPage.getAccountText().shouldHave(Condition.exactText(getContext().getProductPojoList().getFirst().getAccountNumber()));

        if (!operationDate.isEmpty()) {
            b2NConsultAccountingMovementPage.getOperationDateText().shouldHave(Condition.exactText(operationDate));
        }
        if (!valueDate.isEmpty()) {
            b2NConsultAccountingMovementPage.getValueDateText().shouldHave(Condition.exactText(valueDate));
        }
        if (!kindOfOperation.isEmpty()) {
            b2NConsultAccountingMovementPage.getKindOfOperationText().shouldHave(Condition.exactText(kindOfOperation));
        }
        if (!amountOfTheMovement.isEmpty()) {
            b2NConsultAccountingMovementPage.getAmountOfTheMovementText().shouldHave(Condition.exactText(amountOfTheMovement));
        }
        if (!operationReference.isEmpty()) {
            b2NConsultAccountingMovementPage.getOperationReferenceText().shouldHave(Condition.exactText(operationReference));
        }
        if (!accountingDate.isEmpty()) {
            b2NConsultAccountingMovementPage.getAccountingDateText().shouldHave(Condition.exactText(accountingDate));
        }

        b2NConsultAccountingMovementPage.getBackButton().click();
    }
}
