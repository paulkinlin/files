package nsi.pojos;

import io.cucumber.java.Before;

public class ContextFactory {

    private static ThreadLocal<ContextThread> contextThread;

    @Before(order = 1)
    public static void instantiateContextObject() {
        contextThread = ThreadLocal.withInitial(ContextThread::new);
    }

    public static Context getContext() {
        return contextThread.get().getContext();
    }
}
