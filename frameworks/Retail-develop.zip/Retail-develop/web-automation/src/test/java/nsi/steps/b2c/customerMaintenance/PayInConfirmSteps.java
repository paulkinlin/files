package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.PayInConfirmPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static com.codeborne.selenide.Selenide.switchTo;

public class PayInConfirmSteps extends Steps {

    private PayInConfirmPage payInConfirmPage = page(PayInConfirmPage.class);

    @Then("PayInConfirmPage: click confirm")
    public void payinConfirm() {
        payInConfirmPage.getHeaderText().shouldBe(Condition.visible);

        switchTo().frame("rtlframe");
        payInConfirmPage.getPayNowButton().click();
    }

    @Then("PayInConfirmPage: check accounts from {string} to {string} and confirm")
    public void payinCheckAccountsConfirm(String from, String to) {
        payInConfirmPage.getPayInAccountFromText().shouldHave(Condition.text(from));
        payInConfirmPage.getPayInAccountToText().shouldHave(Condition.text(to));
        payInConfirmPage.getConfirmButton().click();
    }
}