package nsi.dao;

import DataBase.DatabaseAccess;
import net.minidev.json.parser.ParseException;
import org.sql2o.Connection;
import org.sql2o.data.Table;

import java.io.IOException;

import static nsi.utils.JsonUtils.getDataFromFile;

public class ClientDao {
    DatabaseAccess databaseAccess = new DatabaseAccess();

    public String getExistingRandomNINumber() {
        final String query = "SELECT numidt FROM cld70 SAMPLE (1) WHERE typidt = '16' and ROWNUM <= 1";
        try (Connection connection = databaseAccess.sql2o.open()){
            return connection.createQuery(query).executeAndFetchFirst(String.class);
        }
    }

    public String getExistingClientNumber(String numidt){
        final String query = "SELECT numcli FROM cld70 WHERE typidt = '17' and NUMIDT = :numidt";
        try (Connection connection = databaseAccess.sql2o.open()){
            return connection.createQuery(query)
                    .addParameter("numidt", numidt)
                    .executeAndFetchFirst(String.class);
        }
    }

    public Table getLatestRegisteredClient() {
        final String query = "select * from (select a.numcli, a.numidt, b.nomcli from cld70 a, cld01 b " +
                "where a.typidt = '17' " +
                "and a.numcli in (select numcli from zld24 " +
                "where staaut = '2000' " +
                "and numcli in (select numcli from ccd01 " +
                "where natenc like '0903' " +
                "and not (natenc = '0902'))) " +
                "and a.numcli = b.numcli " +
                "order by a.numidt desc) " +
                "where rownum = 1";
        try (Connection connection = databaseAccess.sql2o.open()) {
            return connection.createQuery(query)
                    .executeAndFetchTable();
        }
    }

    public String getAccountNumberOfProduct(String jsonFile) throws IOException, ParseException {
        String clientNumber = getDataFromFile(jsonFile).getClientNumber();
        final String query = "select NUMCPT from CCD01 where NATENC = '0903' and numcli = '"+clientNumber+"'";
        try (Connection connection = databaseAccess.sql2o.open()) {
            return connection.createQuery(query)
                    .executeAndFetchFirst(String.class);
        }
    }

}
