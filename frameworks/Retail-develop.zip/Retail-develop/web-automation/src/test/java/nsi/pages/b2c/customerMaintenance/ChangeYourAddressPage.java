package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourAddressPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//h2[contains(.,'Confirm your phone number')]")
    private SelenideElement confirmPhoneNoHeaderText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//input[@name='btnCancel']")
    private SelenideElement cancelButton;

    // LINKS

    // ----------------------------------------------------
}