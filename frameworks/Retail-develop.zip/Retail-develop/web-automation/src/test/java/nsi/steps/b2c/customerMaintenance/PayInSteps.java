package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.PayInPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

public class PayInSteps extends Steps {

    private final PayInPage payInPage = page(PayInPage.class);

    @Then("PayInPage: submit amount {string}")
    public void payinAmount(String amount) {
        payInPage.getAmountField().execute(clearAndSetValue(amount));
        payInPage.getContinueButton().click();
        getContext().getProductPojoList().getLast().setAmount(amount);
    }

    @Then("PayInPage: submit amount {string} no context save")
    public void payinAmountNoContextSave(String amount) {
        payInPage.getAmountField().execute(clearAndSetValue(amount));
        payInPage.getContinueButton().click();
    }

    @And("PayInPage: check error text {string}")
    public void payinErrorText(String errorMsg) {
        payInPage.getErrorText().shouldHave(Condition.text(errorMsg));
    }

    @And("PayInPage: validate account block error text {string}")
    public void accountBlockErrorText(String errorMsg) {
        payInPage.getAccountBlockErrorText().shouldHave(Condition.text(errorMsg));
    }
}