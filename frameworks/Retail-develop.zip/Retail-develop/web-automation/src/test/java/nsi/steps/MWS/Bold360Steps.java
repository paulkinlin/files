package nsi.steps.MWS;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.MWS.Bold360Page;
import nsi.steps.Steps;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.codeborne.selenide.Selenide.*;
import static nsi.BaseClass.switchBrowserTab;
import static nsi.utils.CustomCommands.clearAndSetValue;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class Bold360Steps extends Steps {

    private final Bold360Page bold360Page = page(Bold360Page.class);

    @Given("an agent is available")
    public void an_agent_is_available() {

        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("window.open();");
        switchBrowserTab(1);
        open("https://agent.bold360.com/work");
        log.info("Open browser at: \n{}\n------------------------------------", "https://agent.bold360.com");

        logIn("paul.kinlin@atos.net", "_Qazwsxedcrfvtgb16");
        changeOperatorStatusToAvailable();
        switchBrowserTab(0);

    }

    @And("an agent response to message")
    public void agentResponseToMessage() {
        switchBrowserTab(1);
        sleep(5000);
        refreshLiveSessions();
        sleep(5000);
        clickMessage("Adam Nowak");
        sleep(5000);
        sendMessage();
        sleep(5000);
        switchBrowserTab(0);
    }

    @When("the chat is finished by agent")
    public void chatIsFinishedByAgent() {
        switchBrowserTab(1);
        sleep(2000);
        clickEndChat();
        sleep(1000);
        switchBrowserTab(0);
    }

    private void refreshLiveSessions() {
        String isNewChat = bold360Page.getTakeNextQueuedChat().getAttribute("class");
        if (!isNewChat.contains("disabled")) {
            bold360Page.getTakeNextQueuedChat().click();
        }
    }

    private void clickMessage(String authorName) {
        List<WebElement> mes = bold360Page.getMessage().findElements(By.xpath("/div[@class='visitor-name' and .='" + authorName + "']"));
        mes.get(0).click();
    }

    private void sendMessage() {
        bold360Page.getAgentFirstPredefinedMessage().click();
        WebElement iframe = WebDriverRunner.getWebDriver().findElement(By.xpath("//iframe[contains(@id, 'tiny-react')]"));
        Selenide.switchTo().frame(iframe);
        bold360Page.getAgentMessageTextArea().pressEnter();
        Selenide.switchTo().defaultContent();
    }

    private void logIn(String login, String password) {
        bold360Page.getLoginInput().execute(waitUntilVisible).execute(clearAndSetValue(login));
        bold360Page.getNextButton().execute(waitUntilVisible).click();
        bold360Page.getPasswordInput().execute(waitUntilVisible).execute(clearAndSetValue(password));
        bold360Page.getSignInButton().execute(waitUntilVisible).click();
    }

    private void changeOperatorStatusToAvailable() {
        bold360Page.getOperatorStatusServiceLink().execute(waitUntilVisible);
        sleep(2000);
        bold360Page.getOperatorStatusServiceLink().click();
    }

    private void clickEndChat() {
        bold360Page.getEndChatButton().execute(waitUntilVisible).click();
        bold360Page.getConfirmEndChatButton().execute(waitUntilVisible).click();
        bold360Page.getEndChatAlert().execute(waitUntilVisible);
    }
}
