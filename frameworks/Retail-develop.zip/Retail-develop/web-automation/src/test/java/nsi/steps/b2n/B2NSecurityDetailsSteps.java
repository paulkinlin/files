package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NSecurityDetailsPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NSecurityDetailsSteps extends Steps {

    private B2NSecurityDetailsPage b2NSecurityDetailsPage = page(B2NSecurityDetailsPage.class);

    @And("B2NSecurityDetailsPage: submit answers")
    public void securitydetailspageSubmitAnswers() {
        switchToFrame("dynamic");
        verifyPageTitle("Security details");

        final String questionOne = b2NSecurityDetailsPage.getQuestionOneText().getText()
                .replaceAll("\\(([\\s\\S]+)\\)", "")
                .replace("?", "")
                .trim();
        final String questionTwo = b2NSecurityDetailsPage.getQuestionTwoText().getText()
                .replaceAll("\\(([\\s\\S]+)\\)", "")
                .replace("?", "")
                .trim();

        String answerOne = questionOne.substring(questionOne.lastIndexOf(' ') + 1);
        String answerTwo = questionTwo.substring(questionTwo.lastIndexOf(' ') + 1);

        b2NSecurityDetailsPage.getAnswerOneField().setValue(answerOne);
        b2NSecurityDetailsPage.getAnswerTwoField().setValue(answerTwo);

        b2NSecurityDetailsPage.getConfirmButton().click();
    }
}