package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeDetailPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Cb02")
    private SelenideElement titleSelect;

    @FindBy(id = "Ed07")
    private SelenideElement NIField;

    // Customer extra details
    @FindBy(id = "Ed15")
    private SelenideElement faxNumberField;

    @FindBy(id = "Ed11")
    private SelenideElement emailField;

    @FindBy(id = "Cb01")
    private SelenideElement SPICodeSelect;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm30")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
