package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.PayInPage;
import nsi.pages.b2c.customerMaintenance.YourProductsPage;
import nsi.pojos.products.ProductPojo;
import nsi.pojos.products.SetUpProductB2C;
import nsi.steps.Steps;
import nsi.steps.b2c.initialSale.PaymentDetailsSteps;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.Optional;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class YourProductsSteps extends Steps {

    private final YourProductsPage yourProductsPage = page(YourProductsPage.class);
    private final PayInPage payInPage = page(PayInPage.class);
    private final PaymentDetailsSteps paymentDetailsStep = page(PaymentDetailsSteps.class);
    private final ThankYouInvestmentSteps thankYouInvestmentSteps = page(ThankYouInvestmentSteps.class);
    private final DashboardSteps dashboardSteps = page(DashboardSteps.class);

    @And("YourProductsPage: check amount {string} for first product")
    public void yourProductsCheckAmountForFirstProduct(String amount) {
        Optional<SelenideElement> productTitleOptional = yourProductsPage.getAccountNumberText()
                .shouldBe(CollectionCondition.sizeGreaterThan(0), 20000)
                .stream()
                .filter(p -> p.getText().equalsIgnoreCase(getContext().getProductPojoList().getFirst().getAccountNumber()))
                .findFirst();
        if (productTitleOptional.isPresent()) {
            productTitleOptional.get().$(By.xpath("./ancestor::ul/li[contains(text(), 'Balance')]"))
                    .shouldHave(Condition.text(amount));
        } else {
            Assert.fail("Amount " + amount + " for first product not found");
        }
    }

    @And("YourProductsPage: check amount {string} for product {string}")
    public void yourProductsCheckAmountForSecondProduct(String amount, String product) {
        Optional<SelenideElement> productTitleOptional = yourProductsPage.getBalanceText()
                .shouldBe(CollectionCondition.sizeGreaterThan(0), 20000)
                .stream()
                .filter(p -> p.getText().contains(amount))
                .findFirst();
        if (productTitleOptional.isPresent()) {
            productTitleOptional.get().shouldHave(Condition.text(amount));
            productTitleOptional.get().$(By.xpath("./ancestor::ul/li[contains(text(), 'Account name')]"))
                    .shouldHave(Condition.text(product));
        } else {
            Assert.fail("Amount " + amount + " for " + product + " not found");
        }
    }

    @And("YourProductsPage: check number of products {int}")
    public void yourProductsCheckNumberOdProducts(int number) {
        yourProductsPage.getProductTitles().shouldHave(CollectionCondition.size(number));
    }

    @And("YourProductsPage: check balance {string}")
    public void yourProductsCheckBalance(String balance) {
        Optional<SelenideElement> balanceOptional = yourProductsPage.getBalanceText()
                .shouldBe(CollectionCondition.sizeGreaterThan(0), 20000)
                .stream()
                .filter(p -> p.getText().contains(balance))
                .findFirst();
        if (balanceOptional.isPresent()) {
            balanceOptional.get().shouldHave(Condition.exactText(balance));
        } else {
            Assert.fail("Element balanceOptional not found");
        }
    }

    @And("YourProductsPage: check available balance {string}")
    public void yourProductsCheckAvailableBalance(String availableBalance) {
        yourProductsPage.getAvailableBalanceText().shouldHave(Condition.exactText(availableBalance));
    }

    @And("YourProductsPage: click takeMoneyOut")
    public void yourProductsTakeMoneyOut() {
        yourProductsPage.getTakeMoneyOutButton().click();
    }

    @And("YourProductsPage: click takeMoneyOut and save transaction type to context")
    public void yourProductsTakeMoneyOutAndSaveTransactionType() {

        String acctName = yourProductsPage.getAccountName().getText();
        yourProductsPage.getTakeMoneyOutButton().click();
        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(acctName);
            if (productPojo == null) {
                throw new RuntimeException("Product not recognised"); }
            getContext().getProductPojoList().add(productPojo);
            getContext().getProductPojoList().getLast().setTransactionType("takeMoneyOut");
            productPojo.setProduct(acctName);
    }

    @And("YourProductsPage: click payMoneyIn")
    public void yourProductsPayMoneyIn() {
        yourProductsPage.getPayMoneyInButton().click();
    }

    @And("YourProductsPage: click payMoneyIn and save transaction type to context")
    public void yourProductsPayMoneyInAndSaveTransactionType() {

        String acctName = yourProductsPage.getAccountName().getText();
        yourProductsPage.getPayMoneyInButton().click();
        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(acctName);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised"); }
        getContext().getProductPojoList().add(productPojo);
        productPojo.setProduct(acctName);
        getContext().getProductPojoList().getLast().setTransactionType("payMoneyIn");
    }

    @Then("PayInPage: submit amount {string} until balance {string} for {string}")
    public void payinAmountUntilBalance(String amount, String balance, String productName) {
        do {
            yourProductsPayMoneyIn();
            payInPage.getAmountField().execute(clearAndSetValue(amount));
            payInPage.getContinueButton().click();
            paymentDetailsStep.waitUntilPageIsDisplayedAndClickPayNowButton();
            thankYouInvestmentSteps.thankYouInvestBackToHomePage();
            dashboardSteps.dashboardViewAccount(productName);
            log.info("Balance: " + yourProductsPage.getBalanceSingleElementText().getText());
        } while (!yourProductsPage.getBalanceSingleElementText().getText().equals(balance));
        getContext().getProductPojoList().getLast().setTransactionType("payMoneyIn");
    }
}