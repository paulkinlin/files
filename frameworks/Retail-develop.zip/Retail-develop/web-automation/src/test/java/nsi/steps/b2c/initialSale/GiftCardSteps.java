package nsi.steps.b2c.initialSale;

import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.GiftCardPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class GiftCardSteps extends Steps {

    private GiftCardPage giftCardPage = page(GiftCardPage.class);

    @When("GiftCardPage: choose would you like gift card {string}")
    public void giftCardPageChooseGiftCard(String option) {
        switch (option.toLowerCase()) {
            case "yes":
                giftCardPage.getGiftCardYesRadio().click();
                break;
            case "no":
                giftCardPage.getGiftCardNoRadio().click();
                giftCardPage.getContinueButton().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("GiftCardPage: choose how do you want receive gift card {string} to {string} from {string} message {string}")
    public void giftCardPageChooseHowToReceiveGiftCard(String option, String to, String from, String message) {
        switch (option.toLowerCase()) {
            case "by post":
                giftCardPage.getGiftCardByPostRadio().click();
                break;
            case "electronically":
                giftCardPage.getGiftCardElectronicallyRadio().click();
                giftCardPage.getGiftCardToField().execute(clearAndSetValue(to));
                giftCardPage.getGiftCardFromField().execute(clearAndSetValue(from));
                giftCardPage.getGiftCardMessageField().execute(clearAndSetValue(message));
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
        giftCardPage.getContinueButton().click();
    }
}
