package nsi.dao;

import DataBase.DatabaseAccess;
import com.codeborne.selenide.Selenide;
import com.github.javafaker.Faker;
import lombok.extern.slf4j.Slf4j;
import org.sql2o.Connection;

import java.util.List;

import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class OperatorsDao {
    DatabaseAccess databaseAccess = new DatabaseAccess();

    public List<Operator> getAllOperators() {
        final String sql = "SELECT * FROM NSI01.BWD01" +
                " WHERE PASSWD = '432df17b2b3a168bcd33f6393bef1f98a962fab3'";

        try (Connection con = databaseAccess.sql2o.open()) {
            return con.createQuery(sql).executeAndFetch(Operator.class);
        }
    }

    public Operator getOperator(String operatorName) {
        final String sql = "SELECT NUMABT FROM NSI01.BWD01 WHERE NUMABT = :operatorName";

        try (Connection con = databaseAccess.sql2o.open()) {
            return con.createQuery(sql)
                    .addParameter("operatorName", operatorName)
                    .executeAndFetch(Operator.class).get(0);
        }
    }

    public Operator getFreeOperatorToTest() {
        Selenide.sleep(new Faker().number().numberBetween(0, 1000));

        final String sql = "SELECT NUMABT FROM NSI01.BWD01" +
                " WHERE NUMSES = '0' AND PASSWD = '432df17b2b3a168bcd33f6393bef1f98a962fab3'" +
                " AND NUMABT != :operatorName";

        List<Operator> operators;
        try (Connection con = databaseAccess.sql2o.open()) {
            operators = con.createQuery(sql)
                    .addParameter("operatorName", getContext().getLastUsedOperator())
                    .executeAndFetch(Operator.class);
        }
        if (operators.isEmpty()) throw new IllegalArgumentException("No free operators available in NSI01.BWD01 table");
        return operators.get(new Faker().number().numberBetween(0, operators.size() - 1));
    }

    public void cleanOperatorSession(String numabt){
        final String sql = "UPDATE NSI01.BWD01 SET NUMSES = 0, DATOPN = null, ACCKEY = 0, STATUT = 1 WHERE NUMABT = :numabt";
        try (Connection con = databaseAccess.sql2o.open()) {
            con.createQuery(sql, false)
                    .addParameter("numabt", numabt)
                    .executeUpdate()
                    .commit();
            log.info("Session cleaned for operator: " + numabt);
        } catch (Exception e){
            log.info("Cannot clean operators - DB connection failed");
        }
    }
}