package nsi.steps.b2c.initialSale;

import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.GiftAmountPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class GiftAmountSteps extends Steps {

    private GiftAmountPage giftAmountPage = page(GiftAmountPage.class);

    @When("GiftAmountPage: submit gift amount {string}")
    public void nsiinitialsale_enter_amt_gift(String amt) {
        giftAmountPage.getGiftAmountField().execute(clearAndSetValue(amt));
        giftAmountPage.getContinueButton().click();
    }
}
