package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NSummaryPaymentInstructionsPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.waitUntilClickable;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NSummaryPaymentInstructionsSteps extends Steps {

    private B2NSummaryPaymentInstructionsPage b2NSummaryPaymentInstructionsPage = page(B2NSummaryPaymentInstructionsPage.class);

    @And("B2NSummaryPaymentInstructionsPage: click button {string}")
    public void summarypaymentinstructionspageClickButton(String buttonName) {
        switchToFrame("dynamic");

        switch (buttonName.toLowerCase()) {
            case "modify":
                b2NSummaryPaymentInstructionsPage
                        .getModifyButton()
                        .execute(waitUntilClickable)
                        .click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NSummaryPaymentInstructionsPage: check that nominated account contains {string}")
    public void summarypaymentinstructionspageCheckNominatedAccountContains(String expectedNominatedAccount) {
        switchToFrame("dynamic");

        b2NSummaryPaymentInstructionsPage.getNominatedAccountValueField()
                .execute(waitUntilVisible)
                .shouldHave(Condition.text(expectedNominatedAccount));

    }

    @And("B2NSummaryPaymentInstructionsPage: check that Payee contains {string}")
    public void summarypaymentinstructionspageCheckPayeeContains(String expectedPayee) {
        switchToFrame("dynamic");

        b2NSummaryPaymentInstructionsPage.getPayeeValueField()
                .execute(waitUntilVisible)
                .shouldHave(Condition.exactText(expectedPayee));
    }
}
