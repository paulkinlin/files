package nsi.pages.b2n;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSummarySendingInstructionsPage extends Pages {

    // LINKS
    @FindBy(xpath = "//tr[@id='row01']//a")
    private SelenideElement topEntry;

    @FindBy(xpath = "//table[@name='Ta01']//tr[contains(@id, 'row') and not(contains(@class, 'TITLE'))]")
    private ElementsCollection listOfSendingsInstructions;
}
