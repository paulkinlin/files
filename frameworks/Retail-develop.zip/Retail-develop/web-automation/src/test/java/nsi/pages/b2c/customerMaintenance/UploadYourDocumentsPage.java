package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class UploadYourDocumentsPage extends Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//a[text()='Upload later']")
    private SelenideElement uploadLaterButton;

    // LINKS

    // ----------------------------------------------------
}