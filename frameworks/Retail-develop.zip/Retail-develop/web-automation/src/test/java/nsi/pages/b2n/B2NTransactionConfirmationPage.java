package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NTransactionConfirmationPage extends Pages {

    // TEXTS
    @FindBy(className = "NOMECR")
    private SelenideElement confirmationText;

    @FindBy(xpath = "//p[@class='PROMPT' and text()=\"The customer's sale is now complete.\"]")
    private SelenideElement saleIsNowCompleteText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS
}
