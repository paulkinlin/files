package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NAccountOwnerPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.waitUntilAppears;

@Slf4j
public class B2NAccountOwnerSteps extends Steps {

    private B2NAccountOwnerPage b2NAccountOwnerPage = page(B2NAccountOwnerPage.class);

    @And("B2NAccountOwnershipPage: submit Account Number {string}")
    public void accountownershippageSubmitAccountNumber(String accountNumber) {
        switchToFrame("dynamic");

        b2NAccountOwnerPage.getAccountNumberSelect().selectOptionContainingText(accountNumber);

        b2NAccountOwnerPage.getAccountNumberSelect().getSelectedOption().shouldHave(Condition.text(accountNumber));

        log.info("AccountOwnershipPage submit Account Number: {}", accountNumber);

        b2NAccountOwnerPage.getNextButton().click();
    }

    @And("B2NAccountOwnershipPage: verify error {string}")
    public void accountownershippageVerifyError(String errorText) {
        switchToFrame("error");

        b2NAccountOwnerPage.getErrorText()
                .execute(waitUntilAppears)
                .shouldHave(Condition.text(errorText));
    }
}
