package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NContactLogPage extends Pages {

    // TEXTS

    // FIELDS


    // DROPDOWNS
    @FindBy(id = "Cb01")
    private SelenideElement bankProductSelect;

    @FindBy(id ="Cb02")
    private SelenideElement typeOfContact;

    @FindBy(id = "Ed29")
    private SelenideElement taxIdentificationNo1;

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement nextButton;

}