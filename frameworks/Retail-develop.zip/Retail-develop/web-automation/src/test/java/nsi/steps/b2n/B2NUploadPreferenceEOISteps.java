package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NUploadPreferenceEOIPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NUploadPreferenceEOISteps extends Steps {

    private B2NUploadPreferenceEOIPage b2NUploadPreferenceEOIPage = page(B2NUploadPreferenceEOIPage.class);

    @And("B2NUploadPreferenceEOI: submit button Continue for EOI Upload Preference page")
    public void b2nuploadpreferenceeoiSubmitButtonContinueForEOIUploadPreferencePage() {
        switchToFrame("dynamic");
        verifyPageTitle("EOI Upload Preference");

        b2NUploadPreferenceEOIPage.getTitleText().shouldHave(Condition.exactText("One (or more) of the customers in this transaction have failed the online EOI check."));
        b2NUploadPreferenceEOIPage.getOptInText().shouldHave(Condition.exactText("Opt In to upload documents for all relevant parties:"));
        b2NUploadPreferenceEOIPage.getOptInCheckbox().shouldBe(Condition.selected);

        b2NUploadPreferenceEOIPage.getContinueButton().click();
    }
}
