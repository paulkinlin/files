package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSummaryPaymentInstructionsPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(xpath = "//table[@id='Ta01']//tr[@id='row01']/td[5]")
    private SelenideElement nominatedAccountValueField;

    @FindBy(xpath = "//table[@id='Ta01']//tr[@id='row01']/td[7]")
    private SelenideElement payeeValueField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//img[@alt='Modify']/parent::*")
    private SelenideElement modifyButton;

    // LINKS

    // ----------------------------------------------------
}
