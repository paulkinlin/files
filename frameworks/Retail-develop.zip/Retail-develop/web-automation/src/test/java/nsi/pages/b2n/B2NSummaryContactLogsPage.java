package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSummaryContactLogsPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ta01")
    private SelenideElement summaryTable;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement nextButton;

    @FindBy(xpath = "//input[@value='Add contact log']")
    private SelenideElement addContactLogButton;

    // LINKS

    // ----------------------------------------------------
}
