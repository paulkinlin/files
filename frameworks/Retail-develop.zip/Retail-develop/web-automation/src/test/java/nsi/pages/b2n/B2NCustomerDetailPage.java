package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NCustomerDetailPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx02")
    private SelenideElement customerCategoryText;

    @FindBy(id = "Tx03")
    private SelenideElement typeOfCustomerText;

    @FindBy(id = "Tx04")
    private SelenideElement titleText;

    @FindBy(id = "Tx05")
    private SelenideElement surnameText;

    @FindBy(id = "Tx06")
    private SelenideElement forenameText;

    @FindBy(id = "Tx07")
    private SelenideElement niText;

    @FindBy(id = "Tx08")
    private SelenideElement dateOfBirthText;

    @FindBy(id = "Tx09")
    private SelenideElement countryText;

    @FindBy(id = "Tx10")
    private SelenideElement telephoneText;

    @FindBy(id = "Tx11")
    private SelenideElement emailText;

    @FindBy(id = "Tx38")
    private SelenideElement telephonePrefixText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS

    // LINKS

    // ----------------------------------------------------
}
