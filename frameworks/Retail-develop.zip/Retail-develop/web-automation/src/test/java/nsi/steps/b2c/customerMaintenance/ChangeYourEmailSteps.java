package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.ChangeYourEmailPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ClientDataPojo.generateEmailAddress;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class ChangeYourEmailSteps extends Steps {
    public static String newEmailAddress;

    ChangeYourEmailPage changeYourEmailPage = page(ChangeYourEmailPage.class);

    @When("ChangeYourEmailPage: change email and submit")
    public void changeYourEmail() {
        changeYourEmailPage.getTitleText().shouldBe(Condition.visible);
        newEmailAddress = generateEmailAddress();
        changeYourEmailPage.getNewEmailField().execute(clearAndSetValue(newEmailAddress));
        changeYourEmailPage.getConfirmNewEmailField().execute(clearAndSetValue(newEmailAddress));
        changeYourEmailPage.getContinueButton().click();
    }
}