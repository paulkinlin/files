package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class CashInPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "movementAmount")
    private SelenideElement amountField;

    @FindBy(className = "error")
    private SelenideElement errorText;

    // DROPDOWNS

    // CHECKBOXES
    @FindBy(xpath = "//input[@value='false']/following-sibling::label")
    private SelenideElement deferNoRadio;

    // BUTTONS
    @FindBy(xpath = "//input[@name='btnNext']")
    private SelenideElement cashInButton;

    // LINKS

    // ----------------------------------------------------
}