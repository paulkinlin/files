package nsi.pojos.products;

public class GGBProduct extends ProductPojo {
}
