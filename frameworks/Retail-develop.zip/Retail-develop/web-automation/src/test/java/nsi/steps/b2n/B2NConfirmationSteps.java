package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.dao.ClientDao;
import nsi.pages.b2n.B2NConfirmationPage;
import nsi.steps.Steps;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NConfirmationSteps extends Steps {

    private B2NConfirmationPage b2NConfirmationPage = page(B2NConfirmationPage.class);
    private ClientDao clientDao = new ClientDao();

    @And("B2NConfirmationPage: capture NSI Number and Second Operator Security Code")
    public void confirmationpageCaptureNSINumberAndSecondOperatorSecurityCode() {
        switchToFrame("dynamic");
        verifyPageTitle("Confirmation");
        verifyPageTitle("Please pass to a second operator so the customer can set up their authentication details.");

        getContext().setNsiNumber(b2NConfirmationPage.getNsiNumberText().execute(waitUntilVisible).getText().trim());
        getContext().setClientNumber(clientDao.getExistingClientNumber(getContext().getNsiNumber()));
        getContext().setOperatorSecurityCode(b2NConfirmationPage.getSecurityCodeNumberText().execute(waitUntilVisible).getText().trim());
        b2NConfirmationPage.getContinueButton().click();
    }

    @And("B2NConfirmationPage: click continue button")
    public void clickContinueButton() {
        switchToFrame("dynamic");
        verifyPageTitle("Confirmation");
        b2NConfirmationPage.getContinueButton().click();
    }

    @Then("B2NConfirmationPage: verify and capture EOI information message, NSI number, Sales Reference and Second Operator Security Code")
    public void confirmationpageVerifyAndCaptureEOIinformationMessageNSInumberSalesReferenceAndSecondOperatorSecurityCode() {
        switchToFrame("dynamic");
        verifyPageTitle("Confirmation");
        verifyPageTitle("Please pass to a second operator so the customer can set up their authentication details.");
        verifyPageTitle("The customer should now go online and upload their EOI documents.");

        b2NConfirmationPage.getNsiNumberText().shouldBe(Condition.visible);
        b2NConfirmationPage.getSalesReferenceText().shouldBe(Condition.visible);
        b2NConfirmationPage.getSecurityCodeNumberText().shouldBe(Condition.visible);

        getContext().setNsiNumber(b2NConfirmationPage.getNsiNumberText().getText().trim());
        getContext().setClientNumber(clientDao.getExistingClientNumber(getContext().getNsiNumber()));
        getContext().setOperatorSecurityCode(b2NConfirmationPage.getSecurityCodeNumberText().getText().trim());

        b2NConfirmationPage.getContinueButton().click();
    }
}