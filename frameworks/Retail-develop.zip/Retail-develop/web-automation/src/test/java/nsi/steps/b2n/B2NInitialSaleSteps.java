package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.dao.ClientDao;
import DataBase.EnvironmentDao;
import nsi.pages.b2n.B2NInitialSalePage;
import nsi.pojos.ClientDataPojo;
import nsi.pojos.products.PremiumBondProduct;
import nsi.pojos.products.ProductPojo;
import nsi.pojos.products.SetUpProductB2N;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.concurrent.TimeUnit;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.*;
import static utils.DateUtils.getDOBFromBusinessDateMinusYearsMonthsDays;

@Slf4j
public class B2NInitialSaleSteps extends Steps {

    private static final String ATOS_ADDRESS = "Atos, Wearside House, Riverside Place, Durham";

    private final B2NInitialSalePage b2NInitialSalePage = page(B2NInitialSalePage.class);

    @When("B2NInitialSalePage: submit channel of enquiry {string}")
    public void initialsalepageSubmitChannelOfEnquiry(String channel) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");

        b2NInitialSalePage.getChannelOfEnquirySelect().selectOption(channel);
    }

    @When("B2NInitialSalePage: submit Product {string}")
    public void initialsalepageSubmitProduct(String product) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");

        ProductPojo productPojo = new SetUpProductB2N().returnProductObject(product);
        getContext().getProductPojoList().add(productPojo);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised");
        }
        productPojo.setProduct(product);
        getContext().getProductPojoList().getLast().setTransactionType("Initial Sale");

        b2NInitialSalePage.getProductSelect().selectOption(product);
        b2NInitialSalePage.getNextButton().execute(waitUntilVisible).click();
    }

    @When("B2NInitialSalePage: submit Product {string} with option {string}")
    public void b2ninitialsalepageSubmitProductWithOption(String product, String option) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");

        ProductPojo productPojo = new SetUpProductB2N().returnProductObject(product);
        getContext().getProductPojoList().add(productPojo);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised");
        }
        productPojo.setProduct(product);
        getContext().getProductPojoList().getLast().setTransactionType("Initial Sale");

        b2NInitialSalePage.getProductSelect().selectOption(product);
        b2NInitialSalePage.getProductSelect().shouldHave(Condition.text(product));

        selectProductOption(option);
        b2NInitialSalePage.getNextButton().execute(waitUntilVisible).click();
    }

    @And("B2NInitialSalePage: submit Title, Surname, Forenames, DOB, NI, Main Phone, Email for mainInvestor")
    public void initialsalepageSubmitTitleSurnameForenamesDobNiMainPhoneEmailContext() {
        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer details");

        loadSpecifiedCustomerDataIntoTheFields(mainInvestor);
    }

    @And("B2NInitialSalePage: submit Title {string} Surname {string} Forenames {string} DOB {string} NI {string} Main Phone {string} Email {string} for mainInvestor")
    public void initialsalepageSubmitTitleSurnameForenamesDobNiMainPhoneEmailManually(String title, String surname,
                                                                                      String forenames, String dob,
                                                                                      String ni, String phone, String email) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer details");

        if (!title.isEmpty()) {
            b2NInitialSalePage.getTitleSelect().execute(waitUntilVisible).selectOption(title);
        }
        if (!surname.isEmpty()) {
            b2NInitialSalePage.getSurnameField().execute(clearAndSetValue(surname));
        }
        if (!forenames.isEmpty()) {
            b2NInitialSalePage.getForenamesField().execute(clearAndSetValue(forenames));
        }
        if (!dob.isEmpty()) {
            b2NInitialSalePage.getDobField().execute(clearAndSetValue(dob));
        }
        if (!ni.isEmpty()) {
            b2NInitialSalePage.getNiNumberField().execute(clearAndSetValue(ni));
        }
        if (!phone.isEmpty()) {
            b2NInitialSalePage.getMainPhoneField().execute(clearAndSetValue(phone));
        }
        if (!email.isEmpty()) {
            b2NInitialSalePage.getEmailAddressField().execute(clearAndSetValue(email));
        }
    }

    @And("B2NInitialSalePage: submit Title, Surname, Forenames, DOB, NI, Main Phone, Email for secondInvestor")
    public void initialSalePageSubmitTitleSurnameForenamesDOBNIMainPhoneEmailForSecondInvestor() {
        ClientDataPojo secondInvestor = getContext().getSecondClientData();
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer details");

        loadSpecifiedCustomerDataIntoTheFields(secondInvestor);
    }

    @When("B2NInitialSalePage: submit Title, Surname, Forenames, DOB for investor own child")
    public void initialSalePageSubmitTitleSurnameForenamesDOBforInvestorOwnChild() {
        ClientDataPojo firstChildClientData = getContext().getFirstChildClientData();
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Minor details");

        loadInvestorOwnChildDataIntoTheFields(firstChildClientData);
    }

    @And("B2NInitialSalePage: submit country, postCode, address for mainInvestor")
    public void initialsalepageSubmitCountryPostcodeAddressContext() {

        ClientDataPojo client = getContext().getMainInvestorClientData();

        final String country = "United Kingdom";

        initialsalepageSubmitCountryPostCodeAddressForMainInvestor(country, client.getPostCode(), ATOS_ADDRESS);
    }

    @And("B2NInitialSalePage: Country {string} postCode {string} address {string} for mainInvestor")
    public void initialsalepageSubmitCountryPostCodeAddressForMainInvestor(String country, String postCode,
                                                                           String address) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer address");

        if (!country.isEmpty()) {
            b2NInitialSalePageCountry(country);
        }

        if (!postCode.isEmpty()) {
            b2NInitialSalePagePostCode(postCode);
            b2NInitialSalePage.getSearchButton().click();

            $(By.id("PCA11"))
                    .execute(waitUntilAppears)
                    .selectOption(address);

            getContext().getMainInvestorClientData().setPostCode(postCode);
            getContext().getMainInvestorClientData().setAddress($(By.id("PCA11")).getText());
        }
    }

    @And("B2NInitialSalePage: submit country, postCode, address for child")
    public void initialsalepageSubmitCountryPostcodeAddressContextForChild() {

        ClientDataPojo client = getContext().getFirstChildClientData();

        final String country = "United Kingdom";

        initialsalepageSubmitCountryPostCodeAddressForChild(country, client.getPostCode(), ATOS_ADDRESS);
    }

    @And("B2NInitialSalePage: Country {string} postCode {string} address {string} for child")
    public void initialsalepageSubmitCountryPostCodeAddressForChild(String country, String postCode,
                                                                    String address) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer address");

        if (!country.isEmpty()) {
            b2NInitialSalePageCountry(country);
        }

        if (!postCode.isEmpty()) {
            b2NInitialSalePagePostCode(postCode);
            b2NInitialSalePage.getSearchButton().click();

            $(By.id("PCA11"))
                    .execute(waitUntilAppears)
                    .selectOption(address);

            getContext().getFirstChildClientData().setPostCode(postCode);
            getContext().getFirstChildClientData().setAddress($(By.id("PCA11")).getText());
        }
    }

    @When("B2NInitialSalePage: submit same address as first investor")
    public void initialsalepageSameAddressAsMainInvestor() {
        if (!b2NInitialSalePage.getSameAddressCheckbox().isSelected()) {
            b2NInitialSalePage.getSameAddressCheckbox().click();
        }
        getContext().getSecondClientData().setAddress(getContext().getMainInvestorClientData().getAddress());
    }

    @When("B2NInitialSalePage: submit same address as child")
    public void initialsalepageSameAddressAsChild() {
        if (!b2NInitialSalePage.getSameAddressCheckbox().isSelected()) {
            b2NInitialSalePage.getSameAddressCheckbox().click();
        }
        getContext().getMainInvestorClientData().setAddress(getContext().getFirstChildClientData().getAddress());
    }

    @When("B2NInitialSalePage: submit different address: Country {string} postCode {string} address {string}")
    public void initialsalepageDifferentAddressThanMainInvestor(String country, String postCode,
                                                                String address) {
        if (b2NInitialSalePage.getSameAddressCheckbox().isSelected()) {
            b2NInitialSalePage.getSameAddressCheckbox().click();
        }

        initialsalepageSubmitCountryPostCodeAddressForSecondInvestor(country, postCode, address);
    }

    @When("B2NInitialSalePage: submit different address: Country {string} postCode {string} address {string} than child")
    public void initialsalepageDifferentAddressThanChild(String country, String postCode,
                                                         String address) {
        if (b2NInitialSalePage.getSameAddressCheckbox().isSelected()) {
            b2NInitialSalePage.getSameAddressCheckbox().click();
        }

        initialsalepageSubmitCountryPostCodeAddressForMainInvestor(country, postCode, address);
    }

    @And("B2NInitialSalePage: Country {string} postCode {string} address {string} for secondInvestor")
    public void initialsalepageSubmitCountryPostCodeAddressForSecondInvestor(String country, String postCode,
                                                                             String address) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer address");

        if (!country.isEmpty()) {
            b2NInitialSalePageCountry(country);
        }

        if (!postCode.isEmpty()) {
            b2NInitialSalePagePostCode(postCode);
            b2NInitialSalePage.getSearchButton().click();

            $(By.id("PCA11"))
                    .execute(waitUntilAppears)
                    .selectOption(address);

            getContext().getSecondClientData().setPostCode(postCode);
            getContext().getSecondClientData().setAddress($(By.id("PCA11")).getText());
        }
    }

    @And("B2NInitialSalePage: select Paperless {string} post {string}")
    public void initialsalepageSelectPaperlessPost(String paperless, String post) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer preference for receipt of documentation");

        if (paperless.equals("y")) {
            b2NInitialSalePage.getPaperlessCheckbox().click();
            b2NInitialSalePage.getPaperlessCheckbox().shouldBe(Condition.selected);
        } else if (post.equals("y")) {
            b2NInitialSalePage.getPostCheckbox().click();
            b2NInitialSalePage.getPostCheckbox().shouldBe(Condition.selected);
        } else {
            Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NInitialSalePage: select other than the UK {string}")
    public void initialsalepageSelectOtherThanTheUK(String isUk) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer tax details");

        switch (isUk.toLowerCase()) {
            case "y":
                SelenideElement yesCheckbox = $(By.xpath("//input[contains(@onclick,'toggle') and @value='Y']"));
                yesCheckbox.click();
                yesCheckbox.shouldBe(Condition.selected);
                break;
            case "n":
                SelenideElement noCheckbox = $(By.xpath("//input[contains(@onclick,'toggle') and @value='N']"));
                noCheckbox.click();
                noCheckbox.shouldBe(Condition.selected);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NInitialSalePage: submit button Next")
    public void initialsalepageSubmitButtonNextIsContext() {
        switchToFrame("dynamic");

        b2NInitialSalePage.getNextButton().execute(waitUntilVisible).click();
    }

    @And("B2NInitialSalePage: submit MediaCode {string} sortCode {string} AccountNumber {string} rollNumber {string} name {string} amount {string}")
    public void initialsalepageSubmitMediaCodeSortCodeAccountNumberRollNumberNameAmount(String mediaCode, String sortCode,
                                                                                        String accountNumber, String rollNumber,
                                                                                        String name, String amount) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Media code");

        if (!mediaCode.isEmpty()) {
            b2NInitialSalePage.getMediaCodeSelect().selectOption(mediaCode);
        }
        if (!sortCode.isEmpty()) {
            b2NInitialSalePage.getSortCodeField().execute(clearAndSetValue(sortCode));
        }
        if (!accountNumber.isEmpty()) {
            b2NInitialSalePage.getAccountNumberField().execute(clearAndSetValue(accountNumber));
        }
        if (!rollNumber.isEmpty()) {
            b2NInitialSalePage.getRollNumberField().execute(clearAndSetValue(rollNumber));
        }
        if (!name.isEmpty()) {
            b2NInitialSalePage.getNameField().execute(clearAndSetValue(name));
        }
        if (!amount.isEmpty()) {
            b2NInitialSalePage.getAmountDepositField().execute(clearAndSetValue(amount));
            getContext().getProductPojoList().getLast().setAmount(amount);
        }

        b2NInitialSalePage.getConfirmButton().execute(waitUntilClickable).click();
    }

    @And("B2NInitialSalePage: select pay to my external account")
    public void b2ninitialsalepageSelectPayToMyExternalAccount() {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Media code");

        b2NInitialSalePage.getPayToMyExternalAccountRadioButton().execute(waitUntilAppears).click();
        b2NInitialSalePage.getPayToMyExternalAccountRadioButton().shouldHave(Condition.attribute("selected"));
    }

    @And("B2NInitialSalePage: select pay NSI")
    public void b2ninitialsalepageSelectPayNSI() {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Media code");

        b2NInitialSalePage.getPayToMyNSIAccountRadioButton().execute(waitUntilAppears).click();
        b2NInitialSalePage.getPayToMyNSIAccountRadioButton().shouldHave(Condition.attribute("selected"));
    }

    @And("B2NInitialSalePage: submit MediaCode {string} sortCode {string} AccountNumber {string} rollNumber {string} name {string} amount {string} and pay by DebitCard")
    public void b2ninitialsalepageSubmitMediaCodeSortCodeAccountNumberRollNumberNameAmountAndPayByDebitCard(String mediaCode, String sortCode,
                                                                                                            String accountNumber, String rollNumber,
                                                                                                            String name, String amount) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Media code");

        if (!mediaCode.isEmpty()) {
            b2NInitialSalePage.getMediaCodeSelect().selectOption(mediaCode);
        }
        if (!sortCode.isEmpty()) {
            b2NInitialSalePage.getSortCodeField().execute(clearAndSetValue(sortCode));
        }
        if (!accountNumber.isEmpty()) {
            b2NInitialSalePage.getAccountNumberField().execute(clearAndSetValue(accountNumber));
        }
        if (!rollNumber.isEmpty()) {
            b2NInitialSalePage.getRollNumberField().execute(clearAndSetValue(rollNumber));
        }
        if (!name.isEmpty()) {
            b2NInitialSalePage.getNameField().execute(clearAndSetValue(name));
        }
        if (!amount.isEmpty()) {
            b2NInitialSalePage.getAmountDepositField().execute(clearAndSetValue(amount));

            getContext().getProductPojoList().getLast().setAmount(amount);
        }
        b2NInitialSalePage.getPayByDebitCardRadioButton().execute(waitUntilClickable).click();
        b2NInitialSalePage.getConfirmButton().execute(waitUntilClickable).click();
    }

    @And("B2NInitialSalePage: choose pay to my external account")
    public void payToMyExternalAccount() {
        b2NInitialSalePage.getPayToMyExternalAccountRadioButton()
                .execute(waitUntilEnabled)
                .click();
    }

    @And("B2NInitialSalePage: Pay Now")
    public void initialsalepagePayNow() {
        switchToFrame("dynamic");

        Selenide.switchTo().frame(0);
        b2NInitialSalePage.getPayNowButton()
                .waitUntil(Condition.and("Not clickable", Condition.visible, Condition.enabled), TimeUnit.MINUTES.toMillis(2), 200)
                .click();
    }

    @And("B2NInitialSalePage: select accountType {string}")
    public void initialsalepageSelectAccountType(String accountType) {
        switchToFrame("dynamic");
        verifyPageTitle("Customer details");

        b2NInitialSalePage.getAccountTypeSelect().selectOption(accountType);
    }

    @And("B2NInitialSalePage: select nominatedAccount {string} warrant {string} reinvest {string}")
    public void initialsalepageSelectNominatedAccountWarrantReinvest(String isNominatedAccount, String isWarrant,
                                                                     String isReinvest) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial Sale");
        verifyPageTitle("Prize payment option");

        if (!isNominatedAccount.isEmpty()) {
            b2NInitialSalePage.getNominatedAccountCheckbox().click();
            ((PremiumBondProduct) getContext().getProductPojoList().getLast())
                    .setPbInvestDetails("Pay to my nominated account");
        }
        if (!isWarrant.isEmpty()) {
            b2NInitialSalePage.getWarrantCheckbox().click();
            ((PremiumBondProduct) getContext().getProductPojoList().getLast())
                    .setPbInvestDetails("Digitally Excluded");
        }
        if (!isReinvest.isEmpty()) {
            b2NInitialSalePage.getReinvestCheckbox().click();
            ((PremiumBondProduct) getContext().getProductPojoList().getLast())
                    .setPbInvestDetails("Reinvest into Premium Bonds");
        }
    }

    @And("B2NInitialSalePage: select email {string} text {string} post {string}")
    public void initialsalepageSelectEmailTextPost(String isEmail, String isText, String isPost) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial Sale");
        verifyPageTitle("Prize notification option");

        if (!isEmail.isEmpty()) {
            b2NInitialSalePage.getEmailCheckbox().click();
            if (getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
                ((PremiumBondProduct) getContext().getProductPojoList().getLast()).setPrizeNotification("email");
            }
        }
        if (!isText.isEmpty()) {
            b2NInitialSalePage.getTextCheckbox().click();
            if (getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
                ((PremiumBondProduct) getContext().getProductPojoList().getLast()).setPrizeNotification("text");
            }
        }
        if (!isPost.isEmpty()) {
            b2NInitialSalePage.getPostCheckboxByPrizeNotificationOption().click();
            if (getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
                ((PremiumBondProduct) getContext().getProductPojoList().getLast()).setPrizeNotification("post");
            }
        }
    }

    @And("B2NInitialSalePage: select paperless {string}")
    public void initialsalepageSelectPaperless(String isPaperless) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial Sale");
        verifyPageTitle("Receipt of documentation option");

        if (!isPaperless.isEmpty()) {
            b2NInitialSalePage.getPaperlessCheckboxByReceiptDocumentationOption().click();
        }
    }

    @And("B2NInitialSalePage: select Channel of enquiry {string}")
    public void initialsalepageSelectChannelOfEnquiry(String channelName) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");

        b2NInitialSalePage.getChannelOfEnquirySelect().selectOption(channelName);
        b2NInitialSalePage.getChannelOfEnquirySelect().getSelectedOption().shouldHave(Condition.text(channelName));
    }

    @And("B2NInitialSalePage: set tax details city of birth {string}")
    public void initialsalepageSetTaxDetailsCityOfBirth(String cityOfBirth) {
        switchToFrame("dynamic");
        verifyPageTitle("Customer tax details");

        b2NInitialSalePage.getCityOfBirth().execute(clearAndSetValue(cityOfBirth));
    }

    @And("B2NInitialSalePage: select tax details country of birth {string}")
    public void initialsalepageSelectCountryOfBirth(String countryOfBirth) {
        switchToFrame("dynamic");
        verifyPageTitle("Customer tax details");

        b2NInitialSalePage.getCountryOfBirthSelect().selectOption(countryOfBirth);
        b2NInitialSalePage.getCountryOfBirthSelect().getSelectedOption().shouldHave(Condition.text(countryOfBirth));
    }

    @And("B2NInitialSalePage: select tax details tax country 1 {string}")
    public void initialsalepageSelectTaxCountry1(String taxCountry) {
        switchToFrame("dynamic");
        verifyPageTitle("Customer tax details");

        b2NInitialSalePage.getTaxCountrySelect1().selectOption(taxCountry);
        b2NInitialSalePage.getTaxCountrySelect1().getSelectedOption().shouldHave(Condition.text(taxCountry));
    }

    @And("B2NInitialSalePage: set tax details tax identification no 1 {string}")
    public void initialsalepageSetTaxIdentificationNo1(String taxIdNo) {
        switchToFrame("dynamic");
        verifyPageTitle("Customer tax details");

        b2NInitialSalePage.getTaxIdentificationNo1().execute(clearAndSetValue(taxIdNo));
    }

    private void selectProductOption(String option) {
        switch (option.toLowerCase()) {
            case "minor":
                b2NInitialSalePage.getMinorAccountCheckbox().click();
                break;
            case "jisa incoming transfer":
                //
                break;
            case "donor":
                //
                break;
            case "existing customer":
                break;
            case "holder's account number":
                //
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NInitialSalePage: check that customer details are locked except account type, title and email address")
    public void checkThatCustomerDetailsAreLocked() {
        b2NInitialSalePage.getAccountTypeSelect().execute(waitUntilVisible).shouldNotHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getTitleSelect().execute(waitUntilVisible).shouldNotHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getSurnameField().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getForenamesField().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getDobField().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getNiNumberField().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getMainPhoneField().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getEmailAddressField().execute(waitUntilVisible).shouldNotHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getCountrySelect().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
        b2NInitialSalePage.getPostCodeField().execute(waitUntilVisible).shouldHave(Condition.attribute("disabled"));
    }

    private void loadSpecifiedCustomerDataIntoTheFields(ClientDataPojo investor) {

        b2NInitialSalePage.getTitleSelect().execute(waitUntilVisible).selectOption(investor.getTitle());
        b2NInitialSalePage.getSurnameField().execute(clearAndSetValue(investor.getSurName()));
        b2NInitialSalePage.getForenamesField().execute(clearAndSetValue(investor.getForeName()));
        b2NInitialSalePage.getDobField().execute(clearAndSetValue(investor.getDateOfBirth()));
        b2NInitialSalePage.getNiNumberField().execute(clearAndSetValue(investor.getNino()));
        b2NInitialSalePage.getMainPhoneField().execute(clearAndSetValue(investor.getPhoneNumber()));
        b2NInitialSalePage.getEmailAddressField().execute(clearAndSetValue(investor.getEmail()));
    }

    private void loadInvestorOwnChildDataIntoTheFields(ClientDataPojo firstChildClientData) {

        b2NInitialSalePage.getTitleSelect().execute(waitUntilVisible).selectOption(firstChildClientData.getTitle());
        b2NInitialSalePage.getSurnameField().execute(clearAndSetValue(firstChildClientData.getSurName()));
        b2NInitialSalePage.getForenamesField().execute(clearAndSetValue(firstChildClientData.getClientTitleForeSureName()));
        b2NInitialSalePage.getDobField().execute(clearAndSetValue(firstChildClientData.getDateOfBirth()));
    }

    @And("B2NAccountOwnershipPage: verify maximum number account of this type reached error")
    public void maximumAccountOfPBVerifyError() {
        switchToFrame("error");

        final String errorText = "ZYRA3214 :  The customer is not allowed to hold another account of this type. Maximum number has been reached.";
        b2NInitialSalePage.getErrorText()
                .execute(waitUntilAppears)
                .shouldHave(Condition.text(errorText));
    }

    @And("B2NInitialSalePage: select SMS {string} Email {string}")
    public void initialsalepageSelectPreferenceForNotificationSMSEmail(String sms, String email) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");

        if (sms.equals("y")) {
            b2NInitialSalePage.getSmsNotificationCheckbox().click();
            b2NInitialSalePage.getSmsNotificationCheckbox().shouldBe(Condition.selected);
        } else if (email.equals("y")) {
            b2NInitialSalePage.getEmailNotificationCheckbox().click();
            b2NInitialSalePage.getEmailNotificationCheckbox().shouldBe(Condition.selected);
        } else {
            Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @And("B2NInitialSalePage: set NI Number with existing one")
    public void initialsalepageSetNiNumberWithExistingOne() {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer details");

        ClientDao clientDao = new ClientDao();
        b2NInitialSalePage.getNiNumberField().execute(clearAndSetValue(clientDao.getExistingRandomNINumber()));
    }

    @And("B2NInitialSalePage: set NI Number")
    public void initialsalepageSetNiNumber() {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer details");

        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();
        b2NInitialSalePage.getNiNumberField().execute(clearAndSetValue(mainInvestor.getNino()));
    }

    @And("B2NInitialSalePage: Country {string}")
    public void b2NInitialSalePageCountry(String countryName) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer address");

        b2NInitialSalePage.getCountrySelect().selectOption(countryName);
    }

    @And("B2NInitialSalePage: PostCode {string}")
    public void b2NInitialSalePagePostCode(String postCode) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");
        verifyPageTitle("Customer address");

        b2NInitialSalePage.getPostCodeField().execute(clearAndSetValue(postCode));
    }

    @And("B2NInitialSalePage: set DOB as business date minus {long} Years {long} Months and {long} Days")
    public void b2NInitialSalePageSetDOBAsBusinessDateMinusYearsMonthsAndDays(long years, long months, long days) {
        switchToFrame("dynamic");
        verifyPageTitle("Initial sale");

        EnvironmentDao environmentDao = new EnvironmentDao();
        b2NInitialSalePage.getDobField().execute(clearAndSetValue(getDOBFromBusinessDateMinusYearsMonthsDays(environmentDao.getBusinessDate(), years, months, days)));
    }
}