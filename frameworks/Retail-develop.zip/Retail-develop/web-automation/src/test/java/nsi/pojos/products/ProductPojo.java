package nsi.pojos.products;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProductPojo {
    // Product Data

    private String product;
    private String transactionType;
    private String amount;
    private String referenceNumber;
    private String accountNumber;
    private String headroom;
    private String targetAccount;
}