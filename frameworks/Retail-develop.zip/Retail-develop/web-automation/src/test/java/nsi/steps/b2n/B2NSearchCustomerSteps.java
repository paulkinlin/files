package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.parser.ParseException;
import nsi.pages.b2n.B2NSearchCustomerPage;
import nsi.steps.Steps;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class B2NSearchCustomerSteps extends Steps {

    private final B2NSearchCustomerPage b2NSearchCustomerPage = page(B2NSearchCustomerPage.class);

    @And("B2NSearchCustomerPage: submit Acc {string} UCI {string} NI {string} Name {string} FirstName {string} Country {string} PostCode {string} DOB {string} IFA {string} IFAID {string} FSA {string} EMS {string}")
    public void searchcustomerpageSubmitAccUCININameFirstNameCountryPostCodeDOBIFAIFAIDFSAEMS(String acc, String uci,
                                                                                              String ni, String name,
                                                                                              String firstName, String country,
                                                                                              String postCode, String dob,
                                                                                              String ifa, String ifaId,
                                                                                              String fsa, String ems) {

        switchToFrame("dynamic");
        verifyPageTitle("Search a customer");

        if (!acc.isEmpty()) {
            b2NSearchCustomerPage.getAccNumberField().execute(clearAndSetValue(acc));
        }
        if (!uci.isEmpty()) {
            b2NSearchCustomerPage.getUciNumberField().execute(clearAndSetValue(uci));
        }
        if (!ni.isEmpty()) {
            b2NSearchCustomerPage.getNiNumberField().execute(clearAndSetValue(ni));
        }
        if (!name.isEmpty()) {
            b2NSearchCustomerPage.getNameField().execute(clearAndSetValue(name));
        }
        if (!firstName.isEmpty()) {
            b2NSearchCustomerPage.getFirstNameField().execute(clearAndSetValue(firstName));
        }
        if (!country.isEmpty()) {
            b2NSearchCustomerPage.getCountrySelect().selectOption(country);
        }
        if (!postCode.isEmpty()) {
            b2NSearchCustomerPage.getPostCodeField().execute(clearAndSetValue(postCode));
        }
        if (!dob.isEmpty()) {
            b2NSearchCustomerPage.getDobField().execute(clearAndSetValue(dob));
        }
        if (!ifa.isEmpty()) {
            if (ifa.equals("yes")) {
                b2NSearchCustomerPage.getIfaAgentCheckbox().setSelected(true);
                b2NSearchCustomerPage.getIfaAgentCheckbox().shouldBe(Condition.selected);
            } else {
                b2NSearchCustomerPage.getIfaAgentCheckbox().setSelected(false);
                b2NSearchCustomerPage.getIfaAgentCheckbox().shouldBe(Condition.not(Condition.selected));
            }
        }
        if (!ifaId.isEmpty()) {
            b2NSearchCustomerPage.getIfaIDField().execute(clearAndSetValue(ifaId));
        }
        if (!fsa.isEmpty()) {
            b2NSearchCustomerPage.getFsaField().execute(clearAndSetValue(fsa));
        }
        if (!ems.isEmpty()) {
            b2NSearchCustomerPage.getEmsField().execute(clearAndSetValue(ems));
        }

        b2NSearchCustomerPage.getSearchButton().click();
    }

    @When("B2NSearchCustomerPage: submit mainInvestor NINO from JSON {string}")
    public void b2NSearchCustomerPageSubmitNINOFromJSON(String jsonFile) throws IOException, ParseException {
        switchToFrame("dynamic");
        verifyPageTitle("Search a customer");

        String nino = getContext().getMainInvestorClientData().getNino();

        b2NSearchCustomerPage.getNiNumberField().execute(clearAndSetValue(nino));
        b2NSearchCustomerPage.getSearchButton().click();
    }

    @When("B2NSearchCustomerPage: submit NSI number from JSON {string}")
    public void b2NSearchCustomerPageSubmitNSINoFromJSON(String jsonFile) throws IOException, ParseException {
        switchToFrame("dynamic");
        verifyPageTitle("Search a customer");

        String nsiNo = getContext().getNsiNumber();

        b2NSearchCustomerPage.getUciNumberField().execute(clearAndSetValue(nsiNo));
        b2NSearchCustomerPage.getSearchButton().execute(waitUntilVisible).click();
    }

    @Then("B2NSearchCustomerPage: check text in table {string}")
    public void searchcustomerpageCheckTextInTable(String expectedTableText) {
        switchToFrame("dynamic");

        b2NSearchCustomerPage.getTableTextField()
                .shouldBe(Condition.visible)
                .shouldHave(Condition.exactText(expectedTableText));
    }
}