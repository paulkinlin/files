package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangeYourSecurityQuestionsPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Tar1-1")
    private SelenideElement questionOneSelect;

    @FindBy(id = "Edr1")
    private SelenideElement answerOneField;

    @FindBy(id = "Tar1-2")
    private SelenideElement questionTwoSelect;

    @FindBy(id = "Edr2")
    private SelenideElement answerTwoField;

    @FindBy(id = "Tar1-3")
    private SelenideElement questionThreeSelect;

    @FindBy(id = "Edr3")
    private SelenideElement answerThreeField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm80")
    private SelenideElement confirmButton;

    // LINKS

}
