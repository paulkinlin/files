package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NConsultSendingInstructionPage extends Pages {

    //FIELD
    @FindBy(id = "Tx23")
    private SelenideElement streetAddress;

    @FindBy(id = "Tx24")
    private SelenideElement town;

    @FindBy(id = "Tx25")
    private SelenideElement postcode;

    @FindBy(id = "Tx25")
    private SelenideElement country;

}
