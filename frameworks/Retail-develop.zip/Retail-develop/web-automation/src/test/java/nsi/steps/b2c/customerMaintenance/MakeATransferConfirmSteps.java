package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.MakeATransferConfirmPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Condition.exactText;
import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clickAndWait;

@Slf4j
public class MakeATransferConfirmSteps extends Steps {

    private MakeATransferConfirmPage makeATransferConfirmPage = page(MakeATransferConfirmPage.class);

    @And("MakeATransferConfirmPage: click confirm")
    public void makeATransferConfirmPageConfirm() {
        makeATransferConfirmPage.getTitleText().shouldHave(exactText("Transfer - please confirm"));
        makeATransferConfirmPage.getConfirmButton().click();
    }

    @And("MakeATransferConfirmPage: confirm to close the account")
    public void makeatransferconfirmpageConfirmToCloseTheAccount() {
        makeATransferConfirmPage.getTitleText().shouldHave(exactText("Confirm your account closure"));
        makeATransferConfirmPage.getConfirmButton().execute(clickAndWait);
    }
}