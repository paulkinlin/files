package nsi;


import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.Given;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nsi.pojos.products.ProductPojo;
import nsi.pojos.products.SetUpProductB2C;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.awt.*;
import java.awt.event.KeyEvent;

import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.WebDriverRunner.url;
import static environment.EnvironmentFactory.getEnvironment;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class InitBrowser {

    @Given("open browser for B2C {string}")
    public void openBrowserForB2C(String page) {

        final String baseUrl = getEnvironment().getBaseUrlB2C();
        final String initialSale = "projectuk01-common-b2c/pages/initialSaleB2CSelect01.jsf?chainingAction=true&WTRS=ZYCCIS&bankProduct=";
        String urlEnd;

        if (page.equalsIgnoreCase("login")) {
            urlEnd = "policyenforcer/pages/loginb2c.jsf";
        } else {
            urlEnd = initialSale + Products.getProductNumber(page) + "&MENU=true";
        }

        open(baseUrl + urlEnd);
        log.info("Opened browser at: \n{}{}\n------------------------------------", baseUrl, urlEnd);

        if (!page.equalsIgnoreCase("Login")) {
            ProductPojo productPojo = new SetUpProductB2C().returnProductObject(page);
            if (productPojo == null) {
                throw new RuntimeException("Product not recognised"); }
            getContext().getProductPojoList().add(productPojo);
            getContext().getProductPojoList().getLast().setTransactionType("Initial Sale");
            productPojo.setProduct(page);
        }

        if (url().contains("policyenforcer/pages/attackB2C.jsf")) {
            if ($(By.className("hero-header")).getText().equalsIgnoreCase("We're sorry")) {
                $(By.xpath("//a[contains(.,'Log in')]")).click();
            }
        }
        injectCookieToAcceptCookiesPolicy();
    }

    @Given("open browser for B2N")
    public void openBrowserForB2N() {
        String baseUrl = getEnvironment().getBaseUrlB2N();

        open(baseUrl);
        log.info("Opened browser at: \n{}\n------------------------------------", baseUrl);

    }

    @Given("open browser for B2O")
    public void openBrowserForB2O() {
        String baseUrl = getEnvironment().getBaseUrlB2O();
        open(baseUrl);
        log.info("Opened browser at: \n{}\n------------------------------------", baseUrl);
    }

    private ChromeDriver customChromeDriverWithProxy() {
        String proxy = "10.18.2.19:8080";
        ChromeOptions proxyOption = new ChromeOptions().addArguments("--proxy-server=http://" + proxy).addArguments("start-maximized");
        return new ChromeDriver(proxyOption);
    }

    @Given("a customer is browsing NS&I marketing website")
    @Given("a customer is looking for information")
    public void open_browser_for_nsi_marketing_website() throws AWTException {

        final String baseUrl = getEnvironment().getBaseUrlMWS();

        WebDriverRunner.setWebDriver(customChromeDriverWithProxy());
        open(baseUrl);
        sleep(1000);
        log.info("Open browser at: \n{}\n------------------------------------", baseUrl);

        String cookie = "//div[contains(@class, 'modal-dialog')]//a[@id='accept-cookies']";

        if ( WebDriverRunner.getWebDriver().findElement(By.xpath(cookie)).isDisplayed() ) {
            WebDriverRunner.getWebDriver().findElement(By.xpath(cookie)).click();
        }

//        force reload needed to get chat icon ;/
        Robot r= new Robot();
        r.keyPress(KeyEvent.VK_CONTROL);
        r.keyPress(KeyEvent.VK_F5);
        r.keyRelease(KeyEvent.VK_F5);
        r.keyRelease(KeyEvent.VK_CONTROL);
        sleep(1000);
    }

    @AllArgsConstructor
    private enum Products {

        DISA("0901"),
        DS("0902"),
        PB("0903"),
        IB("0904"),
        GIB("0905"),
        GGB("0906"),
        ILSC("0907"),
        FISC("0908"),
        GEB("0909"),
        CB("0910"),
        IA("0911"),
        SIXTYFIVEGGB("0912"),
        JISA("0913"),
        IGIB("0914");

        private final String productNumber;

        public static String getProductNumber(String productName) {
            return Products.valueOf(productName).productNumber;
        }
    }

    private void injectCookieToAcceptCookiesPolicy() {
        WebDriverRunner.getWebDriver().manage().addCookie(new Cookie("CONSENTMGR", "consent:true"));
    }
}
