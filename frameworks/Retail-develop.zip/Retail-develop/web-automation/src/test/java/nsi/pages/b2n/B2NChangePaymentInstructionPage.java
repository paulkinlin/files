package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangePaymentInstructionPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Rd0101")
    private SelenideElement payToNSICheckbox;

    @FindBy(id = "Cb01")
    private SelenideElement newNominatedAccountSelect;

    @FindBy(id = "Rd0102")
    private SelenideElement payToExternalCheckbox;

    @FindBy(id = "Ed02")
    private SelenideElement newSortCodeField;

    @FindBy(id = "Ed03")
    private SelenideElement newNominatedAccountField;

    @FindBy(id = "Ed01")
    private SelenideElement refRollField;

    @FindBy(id = "Ed04")
    private SelenideElement payeeField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    @FindBy(id = "Subm11")
    private SelenideElement cancelButton;

    // LINKS

    // ----------------------------------------------------
}
