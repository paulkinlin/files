package nsi.pages.MWS;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class HomePage extends Pages {

    // TEXTS

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(className = "bcFloat")
    private SelenideElement chatbotButton;

    @FindBy(xpath = "//a[contains(@class,'nav-link utility-nav-link')][contains(text(),'Here to help')]")
    private SelenideElement hereToHelpButton;

    // LINKS
}
