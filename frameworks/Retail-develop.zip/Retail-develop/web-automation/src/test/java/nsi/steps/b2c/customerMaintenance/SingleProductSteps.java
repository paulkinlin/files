package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import nsi.pages.b2c.customerMaintenance.SingleProductPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class SingleProductSteps extends Steps {

    private SingleProductPage singleProductPage = page(SingleProductPage.class);

    @And("SingleProductPage: check balance {string}")
    public void singleProductCheckBalance(String balance) {
        singleProductPage.getBalanceText().shouldHave(Condition.text(balance));
    }

    @And("SingleProductPage: click Cash in")
    public void singleProductCheckBalance() {
        singleProductPage.getCashInButton().click();
    }
}
