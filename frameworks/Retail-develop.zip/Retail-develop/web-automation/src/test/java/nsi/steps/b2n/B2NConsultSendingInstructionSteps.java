package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NConsultSendingInstructionPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NConsultSendingInstructionSteps extends Steps {

    B2NConsultSendingInstructionPage b2NConsultSendingInstructionPage = page(B2NConsultSendingInstructionPage.class);

    @And("B2NConsultSendingInstructionPage: check address street {string}, town {string}, postcode {string}")
    public void checkAddress(String streetAddress, String town, String postcode) {
        switchToFrame("dynamic");
        verifyPageTitle("Consult a sending instruction");

        b2NConsultSendingInstructionPage.getStreetAddress().shouldHave(Condition.text(streetAddress));
        b2NConsultSendingInstructionPage.getTown().shouldHave(Condition.text(town));
        b2NConsultSendingInstructionPage.getPostcode().shouldHave(Condition.text(postcode));
    }
}