package nsi.pojos.products;

public class SetUpProductB2C {
    public  <T extends ProductPojo> T returnProductObject(String product) {
        switch (product){
            case "PB":
                return (T) new PremiumBondProduct();
            case "Premium Bonds":
                return (T) new PremiumBondProduct();
            case "DS":
                return (T) new DirectSaverProduct();
            case "Direct Saver":
                return (T) new DirectSaverProduct();
            case "DISA":
                return (T) new DISAProduct();
            case "Direct ISA":
                return (T) new DISAProduct();
            case "IB":
                return (T) new IncomeBondProduct();
            case "Income Bonds":
                return (T) new IncomeBondProduct();
            case "CB":
                return (T) new CBProduct();
            case "JISA":
                return (T) new JisaProduct();
            case "FISC":
                return (T) new FISCProduct();
            case "GEB":
                return (T) new GEBProduct();
            case "GGB":
                return (T) new GGBProduct();
            case "GIB":
                return (T) new GIBProduct();
            case "IAP":
                return (T) new IAProduct();
            case "IGGIB":
                return (T) new IGGIBProduct();
            case "ILSC":
                return (T) new ILSCProduct();
            case "SIXTYFIVEGGB":
                return (T) new SixtyFiveGGBProduct();
            case "IGIB":
                return (T) new IGGIBProduct();
            default:
                return null;
        }
    }
}