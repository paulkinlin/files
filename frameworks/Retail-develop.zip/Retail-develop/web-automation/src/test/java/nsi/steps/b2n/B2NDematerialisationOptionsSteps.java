package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NDematerialisationOptionsPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;
import static com.codeborne.selenide.Selenide.page;


@Slf4j
public class B2NDematerialisationOptionsSteps extends Steps {

    private B2NDematerialisationOptionsPage b2NDematerialisationOptionsPage = page(B2NDematerialisationOptionsPage.class);

    @And("B2NDematerialisationOptionsPage: verify productName {string} is: Paperless documents {string} Paper documents {string} Both {string}")
    public void dematerialisationoptionspageVerifyProductNameIsPaperlessDocumentsPaperDocumentsBoth(String productName, String paperlessDocuments,
                                                                                                    String paperDocuments, String both) {
        switchToFrame("dynamic");

        ElementsCollection lines = b2NDematerialisationOptionsPage.getTable().$$(By.tagName("tr"));

        for (SelenideElement line : lines) {
            if (line.getText().contains(productName)) {
                ElementsCollection columns = line.$$(By.tagName("input"));

                boolean isPaperlessDocuments = columns.get(0).isSelected();
                boolean isPaperDocuments = columns.get(1).isSelected();
                boolean isBoth = columns.get(2).isSelected();

                if (paperlessDocuments.equals("y")) {
                    columns.get(0).shouldBe(Condition.selected);
                    columns.get(1).shouldNotBe(Condition.selected);
                    columns.get(2).shouldNotBe(Condition.selected);
                } else if (paperDocuments.equals("y")) {
                    columns.get(1).shouldBe(Condition.selected);
                    columns.get(0).shouldNotBe(Condition.selected);
                    columns.get(2).shouldNotBe(Condition.selected);
                } else if (both.equals("y")) {
                    columns.get(2).shouldBe(Condition.selected);
                    columns.get(0).shouldNotBe(Condition.selected);
                    columns.get(1).shouldNotBe(Condition.selected);
                }
            }
        }
    }

    @And("B2NDematerialisationOptionsPage: select product {string} as: Paperless documents {string} Paper documents {string} Both {string}")
    public void dematerialisationoptionspageSelectProductAsPaperlessDocumentsPaperDocumentsBoth(String productName, String paperlessDocuments,
                                                                                                    String paperDocuments, String both) {
        switchToFrame("dynamic");
        ElementsCollection lines = b2NDematerialisationOptionsPage.getTable().$$(By.tagName("tr"));
        for (SelenideElement line : lines) {
            if (line.getText().contains(productName)) {
                ElementsCollection columns = line.$$(By.tagName("input"));
                SelenideElement paperlessDocumentsRadio = columns.get(0);
                SelenideElement paperDocumentsRadio = columns.get(1);
                SelenideElement bothRadio = columns.get(2);
                if (paperlessDocuments.equals("y")) {
                    paperlessDocumentsRadio.click();
                } else if (paperDocuments.equals("y")) {
                    paperDocumentsRadio.click();
                } else if (both.equals("y")) {
                    bothRadio.click();
                }
            }
        }
    }

    @And("B2NDematerialisationOptionsPage: click button confirm")
    public void dematerialisationoptionspageClickButtonConfirm() {
        switchToFrame("dynamic");

        b2NDematerialisationOptionsPage.getConfirmButton().click();
    }
}