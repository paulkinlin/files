package nsi.pages.b2o;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2OHomePage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "QLIn")
    private SelenideElement searchField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(className = "logOff")
    private SelenideElement disconnectionButton;

    // LINKS

    // ----------------------------------------------------
}