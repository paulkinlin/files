package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NErrorMessagePage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NErrorMessageSteps extends Steps {

    private B2NErrorMessagePage b2NErrorMessagePage = page(B2NErrorMessagePage.class);

    @Then("B2NErrorMessage: check error message {string}")
    public void errormessageCheckErrorMessage(String expectedErrorMessage) {
        switchToFrame("error");

        b2NErrorMessagePage.getErrorMessageField()
                .shouldBe(Condition.visible)
                .shouldHave(Condition.exactText(expectedErrorMessage));
    }

    @Then("B2NErrorMessage: check text message {string}")
    public void errormessageCheckTextMessage(String expectedTextMessage) {
        switchToFrame("error");

        b2NErrorMessagePage.getErrorMessageField()
                .shouldBe(Condition.visible)
                .shouldHave(Condition.matchText(expectedTextMessage));
    }
}
