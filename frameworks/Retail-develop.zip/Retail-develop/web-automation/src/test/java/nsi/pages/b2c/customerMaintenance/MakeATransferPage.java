package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class MakeATransferPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    // FIELDS
    @FindBy(id = "movementAmount")
    private SelenideElement amountToTransferField;

    @FindBy(xpath = "//*[@id='paymentB2CActionForm']//span[contains(@class, 'label-account')]")
    private SelenideElement targetAccount;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement nextButton;

    // LINKS

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='paymentB2CActionForm:accountSelectForTransfers_accountRadio_0']")
    private SelenideElement checkAccountRadio;

    @FindBy(xpath = "//input[@value='true']/following-sibling::label[1]")
    private SelenideElement yesTransferDefermentRadio;

    @FindBy(xpath = "//input[@value='true']/following-sibling::label[2]")
    private SelenideElement noTransferDefermentRadio;

    // ----------------------------------------------------
}