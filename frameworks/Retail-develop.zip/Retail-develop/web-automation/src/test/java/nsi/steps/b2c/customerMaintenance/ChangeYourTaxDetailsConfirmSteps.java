package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.ChangeYourTaxDetailsConfirmPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Condition.exactText;
import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class ChangeYourTaxDetailsConfirmSteps extends Steps {

    private ChangeYourTaxDetailsConfirmPage changeYourTaxDetailsConfirmPage = page(ChangeYourTaxDetailsConfirmPage.class);

    @And("ChangeYourTaxDetailsConfirmPage: verify and confirm nonUK tax details")
    public void changeYourTaxtDetailsConfirm() {
        changeYourTaxDetailsConfirmPage.getTitleText().shouldHave(exactText("Confirm your tax details"));
        changeYourTaxDetailsConfirmPage.getTaxNonUkText().shouldHave(text(ChangeYourTaxDetailsSteps.taxNonUK));
        changeYourTaxDetailsConfirmPage.getBirthCityText().shouldHave(exactText(ChangeYourTaxDetailsSteps.city));
        changeYourTaxDetailsConfirmPage.getBirthCountryText().shouldHave(exactText(ChangeYourTaxDetailsSteps.country));
        changeYourTaxDetailsConfirmPage.getTaxCountryText().shouldHave(exactText(ChangeYourTaxDetailsSteps.taxCountry));
        changeYourTaxDetailsConfirmPage.getTaxIdentificationNumberText().shouldHave(exactText(ChangeYourTaxDetailsSteps.tinNumber));
        changeYourTaxDetailsConfirmPage.getConfirmButton().click();
    }
}