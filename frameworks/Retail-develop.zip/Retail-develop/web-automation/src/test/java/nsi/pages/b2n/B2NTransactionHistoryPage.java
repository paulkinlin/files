package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NTransactionHistoryPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Cb01")
    private SelenideElement accountNumberSelect;

    @FindBy(id = "Ed02F")
    private SelenideElement startingOperationDateField;

    @FindBy(id = "Ed03")
    private SelenideElement lastOperationDateField;

    @FindBy(id = "Ed03")
    private SelenideElement amountSelect;

    @FindBy(id = "Ed04")
    private SelenideElement amountField;

    @FindBy(id = "Ed07")
    private SelenideElement valueDateField;

    @FindBy(id = "Cb03")
    private SelenideElement kindOfOperationSelect;

    @FindBy(id = "Ed08")
    private SelenideElement accountingReferenceField;

    @FindBy(id = "Ed09")
    private SelenideElement movementNumberField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}