package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NSubsequentSalePage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.pojos.products.ProductPojo;
import nsi.pojos.products.SetUpProductB2N;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NSubsequentSaleSteps extends Steps {

    private final B2NSubsequentSalePage b2NSubsequentSalePage = page(B2NSubsequentSalePage.class);

    @And("B2NSubsequentSalePage: select first account")
    public void subsequentsalepageSelectFirstAccount() {
        switchToFrame("dynamic");
        b2NSubsequentSalePage.getAccountNumberSelect().selectOption(1);
        b2NSubsequentSalePage.getMediaCodeSelect().selectOption(1);
    }

    @And("B2NSubsequentSalePage: select account {string}")
    public void subsequentsalepageSelectAccount(String account) {
        switchToFrame("dynamic");
        b2NSubsequentSalePage.getAccountNumberSelect().selectOptionContainingText(account);
    }

    @And("B2NSubsequentSalePage: select account {string} and save subsale data context")
    public void subsequentsalepageSelectAccountAndSaveContext(String productAccount) {
        switchToFrame("dynamic");
        b2NSubsequentSalePage.getAccountNumberSelect().selectOptionContainingText(productAccount);

        ProductPojo productPojo = new SetUpProductB2N().returnProductObject(productAccount);
        if (productPojo == null) {
            throw new RuntimeException("Product not recognised"); }
        getContext().getProductPojoList().add(productPojo);
        getContext().getProductPojoList().getLast().setTransactionType("Subsequent Sale");
        productPojo.setProduct(productAccount);
    }

    @And("B2NSubsequentSalePage: select MediaCode {string}")
    public void subsequentSalepageSubmitMediaCode(String mediaCode) {
        switchToFrame("dynamic");
        b2NSubsequentSalePage.getMediaCodeSelect().selectOption(mediaCode);
        b2NSubsequentSalePage.getNextButton().click();
    }

    @And("B2NSubsequentSalePage: click button Next")
    public void subsequentsalepageClickButtonNext(){
        switchToFrame("dynamic");
        b2NSubsequentSalePage.getNextButton().click();
    }

    @And("B2NSubsequentSalePage: submit amount {string}")
    public void subsequentsalepageSubmitAmount(String amount) {
        switchToFrame("dynamic");
        if(!(getContext().getProductPojoList().getFirst() instanceof PremiumBondProduct)) {
            getContext()
                    .getProductPojoList()
                    .getFirst()
                    .setAccountNumber(b2NSubsequentSalePage.getAccountNumberText().getText());
        } else {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList()
                    .getFirst())
                    .setHoldersNumber(b2NSubsequentSalePage.getAccountNumberText().getText()); }
        b2NSubsequentSalePage.getAmountField().execute(clearAndSetValue(amount));
        b2NSubsequentSalePage.getNextButton().click();
        getContext().getProductPojoList().getLast().setAmount(amount);
    }

    @And("B2NSubsequentSalePage: check headroom {string} and current balance {string}")
    public void checkHedroomAndCurrentBalance(String headroom, String currentBalance) {
        switchToFrame("dynamic");
        b2NSubsequentSalePage.getHeadroomText().shouldBe(Condition.exactText(headroom));
        b2NSubsequentSalePage.getCurrentBalanceText().shouldBe(Condition.exactText(currentBalance));
        getContext().getProductPojoList().getLast().setHeadroom(headroom);
    }
}