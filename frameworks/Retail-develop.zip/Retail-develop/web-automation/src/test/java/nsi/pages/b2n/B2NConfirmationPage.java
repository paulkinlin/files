package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NConfirmationPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx01")
    private SelenideElement nsiNumberText;

    @FindBy(id = "Tx02")
    private SelenideElement securityCodeNumberText;

    @FindBy(id = "Tx03")
    private SelenideElement SalesReferenceText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm81")
    private SelenideElement continueButton;

    // LINKS

    // ----------------------------------------------------
}
