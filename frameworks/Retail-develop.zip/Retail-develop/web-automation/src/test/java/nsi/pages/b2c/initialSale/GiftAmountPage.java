package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class GiftAmountPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "saleAmount")
    private SelenideElement giftAmountField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    // LINKS

    // ----------------------------------------------------
}