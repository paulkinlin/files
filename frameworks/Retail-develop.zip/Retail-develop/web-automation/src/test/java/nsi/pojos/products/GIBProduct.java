package nsi.pojos.products;

public class GIBProduct extends ProductPojo {
}
