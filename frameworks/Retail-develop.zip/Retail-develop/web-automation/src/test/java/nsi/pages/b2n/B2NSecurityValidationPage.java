package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSecurityValidationPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "CbA1")
    private SelenideElement channelOfEnquirySelect;

    @FindBy(id = "Ed01")
    private SelenideElement numericalKeyField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}
