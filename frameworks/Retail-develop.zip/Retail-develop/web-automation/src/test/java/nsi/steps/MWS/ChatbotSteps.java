package nsi.steps.MWS;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.MWS.ChatbotPage;
import nsi.steps.Steps;
import org.junit.Assert;
import nsi.utils.AssertMessages;
import static com.codeborne.selenide.Selenide.page;
import static com.codeborne.selenide.Selenide.sleep;
import static nsi.utils.CustomCommands.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;

@Slf4j
public class ChatbotSteps extends Steps {

    private ChatbotPage chatbotPage = page(ChatbotPage.class);

    @Then("chat with chatbot is available")
    @Then("the chat window is following the customer to maintain the chat")
    public void verifyChatbotIsAvailable() {
        chatbotPage.getChatbotContainer().shouldBe(Condition.visible);
    }

    @Then("the chatbot answering initial customer queries")
    public void verifyChatbotDefaultQueries() {
        verifyChatbotIsAvailable();
        for (SelenideElement element :
                chatbotPage.getDefaultQueryContainer()) {
            element.shouldBe(Condition.visible);
        }
    }

    @Then("welcome message is displayed in the chat window")
    public void verifyWelcomeMessageIsDisplayed() {
        verifyChatbotIsAvailable();
        chatbotPage.getWelcomeMessage().shouldBe(Condition.visible);
    }

    @Then("the message displayed informing about hours of service if an escalation to an agent is required")
    public void verifyHoursOfServiceMessage() {
        verifyChatbotIsAvailable();
        chatbotPage.getHoursOfServiceMessage().shouldBe(Condition.visible);
    }

    @Given("a chatbot couldn't resolve customer issue")
    public void chatbotCouldNotResolveCustomerIssue() {
        openChat();
        sendMessage("abrakadabra");
        customerIsAlertedWhenNewResponseIsReceived();
        sendMessage("lets chat");
        customerIsAlertedWhenNewResponseIsReceived();
    }

    @When("the other possible options of contacting NS&I are presented")
    public void the_other_possible_options_of_contacting_NS_I_are_presented() {
        chatbotPage.getConversationButtonsContainer().execute(waitUntilVisible);
    }

    @Then("chat with agent button is disabled | unavailable when there are no agents")
    public void chat_with_agent_button_is_disabled_unavailable_when_there_are_no_agents() {
        chatbotPage.getLiveChatButton().shouldBe(Condition.disabled);
    }

    @Then("chat with agent button is enabled")
    public void chat_with_agent_button_is_enabled() {
        sleep(2000);
        chatbotPage.getLiveChatButton().shouldBe(Condition.enabled);
    }

    @When("predefined query {int} is selected")
    public void selectPredefinedQuery(int queryPosition) {
        chatbotPage.getDefaultQueryContainer().get(queryPosition - 1).click();
    }

    @And("customer gives negative feedback")
    public void clickThumbDown() {
        chatbotPage.getThumbDownButton().execute(waitUntilVisible).click();
    }

    @And("customer gives positive feedback")
    public void clickThumbUp() {
        chatbotPage.getThumbUpButton().execute(waitUntilVisible).click();
    }

    @Given("customer is chatting with a chatbot")
    public void customerIsChattingWithAChatbot() {
        openChat();
        sendMessage("password reset");
    }

    @Given("customer is chatting with a chatbot via default query")
    public void customerIsChattingWithChatbotViaDefaultQuery() {
        openChat();
        selectPredefinedQuery(2);
    }

    @When("new message is received")
    public void newMessageIsReceived() {
        chatbotPage.getLastRequestMessage().execute(waitUntilVisible);
    }

    @Then("the customer is alerted when a new response is received in a current chat with a chatbot conversation visual and auditory")
    public void customerIsAlertedWhenNewResponseIsReceived() {
        chatbotPage.getLastResponseMessage().execute(waitUntilVisible);
        chatbotPage.getLastResponseMessage().shouldBe(Condition.visible);
    }

    @Then("there is a message displayed to inform if chat is handled by {string}")
    public void thereIsAMessageDisplayedToInformIfChatIsHandledBy(String operator) {
        switch (operator.toLowerCase()) {
            case "human":
                chatbotPage.getLastHumanResponse().shouldBe(Condition.visible);
                break;
            case "chatbot":
                chatbotPage.getLastBotResponse().shouldBe(Condition.visible);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("the chat is finished")
    public void chatIsFinished() {
        chatbotPage.getCloseButton().execute(waitUntilVisible).click();
    }

    @Then("click close")
    public void clickCloseButton() {
        chatbotPage.getChatCloseButton().execute(waitUntilVisible).click();
    }

    @Then("the customer is offered a transcript of the current chat")
    public void customerIsOfferedATranscriptOfTheCurrentChat() {
        chatbotPage.getDownloadTranscriptButton().execute(waitUntilVisible).shouldBe(Condition.enabled);
    }

    @Then("the customer is offered to leaving feedback")
    public void customerIsOfferedToLeaveFeedback() {
        chatbotPage.getLeaveFeedbackButton().execute(waitUntilVisible).shouldBe(Condition.enabled);
    }

    @When("sensitive data is send - {string}: {string}")
    public void sensitiveDataIsSend(String dataType, String text) {
        sendMessage(text);
    }

    @Then("customer message is masked")
    public void customerMessageIsMasked() {
        chatbotPage.getLastRequestMessage().shouldHave(Condition.text("*"));
    }

    @When("increase widget button is selected")
    public void increaseWidgetButtonIsSelected() {
        chatbotPage.getIncreaseButton().click();
    }

    @Then("widget is expanded")
    public void widgetIsExpanded() {
        sleep(1000);
        String width = chatbotPage.getWidgetWrapper().getCssValue("width").replace("px", "");
        assertThat("", Integer.parseInt(width), greaterThan(400));
    }

    @When("decrease widget button is selected")
    public void decreaseWidgetButtonIsSelected() {
        chatbotPage.getCollapseButton().click();
    }

    @Then("widget is minimized")
    public void widgetIsMinimized() {
        chatbotPage.getChatbotContainer().shouldNotBe(Condition.visible);
    }

    @When("close chat button is selected")
    public void closeChatButtonIsSelected() {
        chatbotPage.getCloseButton().click();
    }

    @Then("end conversation message is presented")
    public void endConversationMessageIsPresented() {
        chatbotPage.getEndConversationMessage().execute(waitUntilVisible).shouldBe(Condition.visible);
    }

    @When("continue button is selected")
    public void endConversationContinueButtonIsSelected() {
        chatbotPage.getEndConversationContinueButton().click();
    }

    @Then("chat continue to run")
    public void chatContinueToRun() {
        chatbotPage.getEndConversationMessage().shouldNotBe(Condition.visible);
        chatbotPage.getChatbotContainer().shouldBe(Condition.visible);
    }

    @When("close button is selected")
    public void endConversationCloseButtonIsSelected() {
        chatbotPage.getEndConversationCloseButton().click();
    }

    @Then("chat is ended")
    @Then("the chat is automatically closed")
    public void chatIsEnded() {
        chatbotPage.getChatbotContainer().shouldNotBe(Condition.visible);
    }

    @And("click chat to someone")
    public void clickChatToSomeone() {
        chatbotPage.getChatToSomeoneButton().execute(waitUntilVisible).execute(waitUntilClickable).click();
    }

    @And("mark Yes I understand and agree to notice")
    public void markYesIUnderstandAndAgreeToNotice() {
        chatbotPage.getYesIUnderstandAndAgreeRadio().execute(waitUntilVisible).click();
    }

    @And("type Your name")
    public void typeYourName() {
        chatbotPage.getNameInput().execute(waitUntilVisible).execute(clearAndSetValue("Adam Nowak"));
    }

    @And("select product")
    public void selectProduct() {
        chatbotPage.getProductSelect().execute(waitUntilVisible).selectOption("Not Applicable");
    }

    @And("type message to agent")
    public void typeMessageToAgent() {
        chatbotPage.getMessageTextarea().execute(waitUntilVisible).execute(clearAndSetValue("test message"));
    }

    @And("click start chat")
    public void clickStartChat() {
        chatbotPage.getStartChatButton().execute(waitUntilVisible).click();
    }

    @Then("time stamp of the agents response to be displayed in the chat dialog box")
    public void timeStampIsDisplayed() {
        for (SelenideElement element :
                chatbotPage.getTimeStampLabels()) {
            element.shouldBe(Condition.visible);
        }
    }

    @Then("the customer is able to input their name")
    public void verifyNameInputIsDisplayed() {
        chatbotPage.getNameInput().execute(waitUntilVisible).shouldBe(Condition.visible);
    }

    @When("there is no customer activity for specified period of time - {long} minutes")
    public void noCustomerActivity(long minutesOfInactivity) {
        sleep(minutesOfInactivity * 60000);
    }

    private void openChat() {
        HomeSteps homeSteps = new HomeSteps();
        homeSteps.clickToAccessChatbot();
        verifyChatbotIsAvailable();
    }

    private void sendMessage(String text) {
        chatbotPage.getQueryInput().execute(clearAndSetValue(text));
        chatbotPage.getQuerySendButton().click();
    }
}
