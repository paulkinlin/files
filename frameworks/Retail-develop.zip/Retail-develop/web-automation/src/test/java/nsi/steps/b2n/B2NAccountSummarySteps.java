package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NAccountSummaryPage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class B2NAccountSummarySteps extends Steps {

    private final B2NAccountSummaryPage b2NAccountSummaryPage = page(B2NAccountSummaryPage.class);

    @And("B2NAccountSummaryPage: verify AN {string} BP {string} C {string} AT {string} SC {string} H {string} CB {string} AA {string} C {string} RFB {string} BD {string} BA {string} ED {string} EDMD {string}")
    public void accountsummarypageVerify(String accountNumber, String bankProduct,
                                         String currency, String accountTitle,
                                         String signatureControl, String headroom,
                                         String currentBalance, String availableAmount,
                                         String closed, String reasonForBlocking,
                                         String blockingDate, String blockingAuthority,
                                         String electronicDocuments, String electronicDocumentsModifyDate) {
        switchToFrame("dynamic");

        if (!accountNumber.isEmpty()) {
            b2NAccountSummaryPage.getAccountNumberText().shouldHave(text(accountNumber));
        }
        if (!bankProduct.isEmpty()) {
            b2NAccountSummaryPage.getBankProductText().shouldHave(text(bankProduct));
        }
        if (!currency.isEmpty()) {
            b2NAccountSummaryPage.getCurrencyText().shouldHave(text(currency));
        }
        if (!accountTitle.isEmpty()) {
            b2NAccountSummaryPage.getAccountTitleText().shouldHave(text(accountTitle));
        }
        if (signatureControl.toLowerCase().equals("y")) {
            b2NAccountSummaryPage.getSignatureControlCheckbox().shouldHave(attribute("selected"));
        }
        if (!headroom.isEmpty()) {
            b2NAccountSummaryPage.getHeadroomText().shouldHave(text(headroom));
        }
        if (!currentBalance.isEmpty()) {
            b2NAccountSummaryPage.getCurrentBalanceText().shouldHave(text(currentBalance));
        }
        if (!availableAmount.isEmpty()) {
            b2NAccountSummaryPage.getAvailableAmountText().shouldHave(text(availableAmount));
        }
        if (closed.toLowerCase().equals("y")) {
            b2NAccountSummaryPage.getClosedCheckbox().shouldHave(attribute("selected"));
        }
        if (!reasonForBlocking.isEmpty()) {
            b2NAccountSummaryPage.getReasonForBlockingText().shouldHave(text(reasonForBlocking));
        }
        if (!blockingDate.isEmpty()) {
            b2NAccountSummaryPage.getBlockingDateText().shouldHave(text(blockingDate));
        }
        if (!blockingAuthority.isEmpty()) {
            b2NAccountSummaryPage.getBlockingAuthorityText().shouldHave(text(blockingAuthority));
        }
        if (electronicDocuments.toLowerCase().equals("y")) {
            b2NAccountSummaryPage.getElectronicDocumentsCheckbox().shouldHave(attribute("selected"));
        }
        if (!electronicDocumentsModifyDate.isEmpty()) {
            b2NAccountSummaryPage.getElectronicDocumentsModifyText().shouldHave(text(electronicDocumentsModifyDate));
        }
    }

    @And("B2NAccountSummaryPage: check product {string} headroom {string} and current balance {string}")
    public void b2naccountsummarypageCheckProductHeadroomAndCurrentBalance(String bankProduct, String headroom, String currentBalance) {
        switchToFrame("dynamic");
        b2NAccountSummaryPage.getBankProductText().shouldHave(exactText(bankProduct));
        b2NAccountSummaryPage.getHeadroomText().shouldHave(exactText(headroom));
        b2NAccountSummaryPage.getCurrentBalanceText().shouldHave(exactText(currentBalance));
        getContext().getProductPojoList().getFirst().setHeadroom(headroom);
        if(!(getContext().getProductPojoList().getFirst() instanceof PremiumBondProduct)) {
            getContext()
                    .getProductPojoList()
                    .getFirst()
                    .setAccountNumber(b2NAccountSummaryPage.getAccountNumberText().getText());
        } else {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList()
                    .getFirst())
                    .setHoldersNumber(b2NAccountSummaryPage.getAccountNumberText().getText()); }
    }

    @And("B2NAccountSummaryPage: check last product {string} headroom {string} and current balance {string}")
    public void b2naccountsummarypageCheckLastProductHeadroomAndCurrentBalance(String bankProduct, String headroom, String currentBalance) {
        switchToFrame("dynamic");
        b2NAccountSummaryPage.getBankProductText().shouldHave(exactText(bankProduct));
        b2NAccountSummaryPage.getHeadroomText().shouldHave(exactText(headroom));
        b2NAccountSummaryPage.getCurrentBalanceText().shouldHave(exactText(currentBalance));
        getContext().getProductPojoList().getLast().setHeadroom(headroom);
        if(!(getContext().getProductPojoList().getLast() instanceof PremiumBondProduct)) {
            getContext()
                    .getProductPojoList()
                    .getLast()
                    .setAccountNumber(b2NAccountSummaryPage.getAccountNumberText().getText());
        } else {
            ((PremiumBondProduct) getContext()
                    .getProductPojoList()
                    .getLast())
                    .setHoldersNumber(b2NAccountSummaryPage.getAccountNumberText().getText()); }
    }

    @And("B2NAccountSummaryPage: click back")
    public void accountsummarypageClickBack() {
        switchToFrame("dynamic");
        verifyPageTitle("Account summary");

        b2NAccountSummaryPage.getBackButton().click();
    }

}