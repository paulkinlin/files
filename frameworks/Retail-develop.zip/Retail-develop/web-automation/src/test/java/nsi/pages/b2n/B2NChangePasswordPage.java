package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NChangePasswordPage extends Pages {

    // FIELDS
    @FindBy(xpath = "(//fieldset//td[not(contains(@class, 'OUTPUT'))])[1]")
    private SelenideElement questionOneField;

    @FindBy(id = "Ed01")
    private SelenideElement answerOneField;

    @FindBy(xpath = "(//fieldset//td[not(contains(@class, 'OUTPUT'))])[2]")
    private SelenideElement questionTwoField;

    @FindBy(id = "Ed02")
    private SelenideElement answerTwoField;

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;
}
