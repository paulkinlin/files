package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NChangeAddressPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NChangeAddressSteps extends Steps {

    private B2NChangeAddressPage b2NChangeAddressPage = page(B2NChangeAddressPage.class);

    @And("B2NChangeAddressPage: submit country {string} postCode {string} address {string}")
    public void changeaddresspageSubmitCountryPostCode(String country, String postCode, String address) {
        switchToFrame("dynamic");

        b2NChangeAddressPage.getCountrySelect().selectOption(country);
        b2NChangeAddressPage.getCountrySelect()
                .getSelectedOption()
                .shouldHave(Condition.text(country));

        b2NChangeAddressPage.getPostCodeField().execute(clearAndSetValue(postCode));
        b2NChangeAddressPage.getPostCodeField().shouldHave(Condition.value(postCode));

        b2NChangeAddressPage.getSearchButton().click();

        b2NChangeAddressPage.getFoundAddressesSelect().selectOption(address);
        b2NChangeAddressPage.getFoundAddressesSelect()
                .getSelectedOption()
                .shouldHave(Condition.text(address));

        log.info("ChangeAddressPage submit country '{}' postCode '{}' address '{}'", country, postCode, address);

        b2NChangeAddressPage.getConfirmButton().click();
    }
}