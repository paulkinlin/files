package nsi.pages.b2o;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2OLoginPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "j_username_pwd")
    private SelenideElement loginField;

    @FindBy(id = "j_password_pwd")
    private SelenideElement passwordField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement loginButton;

    // LINKS

    // ----------------------------------------------------
}