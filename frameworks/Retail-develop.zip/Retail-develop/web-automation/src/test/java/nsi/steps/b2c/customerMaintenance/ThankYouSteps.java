package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.ThankYouPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class ThankYouSteps extends Steps {

    private ThankYouPage thankYouPage = page(ThankYouPage.class);

    @Then("ThankYouPage: ThankYou We've updated {string}")
    public void thankYouUpdatedPhoneNoBackToYourDetails(String text) {
        thankYouPage.getTitleText().shouldHave(Condition.text(text));
        thankYouPage.getBackToYourDetailsButton().click();
    }
}