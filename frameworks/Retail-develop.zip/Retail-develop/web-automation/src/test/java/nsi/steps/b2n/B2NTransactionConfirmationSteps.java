package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import nsi.pages.b2n.B2NTransactionConfirmationPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class B2NTransactionConfirmationSteps extends Steps {

    private B2NTransactionConfirmationPage b2NTransactionConfirmationPage = page(B2NTransactionConfirmationPage.class);

    @And("B2NTransactionConfirmationPage: check title")
    public void transactionConfrimationPageCheckTitle() {
        switchToFrame("dynamic");
        b2NTransactionConfirmationPage.getConfirmationText().shouldBe(Condition.exactText("Confirmation"));
        b2NTransactionConfirmationPage.getSaleIsNowCompleteText().shouldBe(Condition.
                exactText("The customer's sale is now complete."));
    }
}