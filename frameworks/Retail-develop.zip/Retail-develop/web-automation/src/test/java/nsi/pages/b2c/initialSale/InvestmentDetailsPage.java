package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class InvestmentDetailsPage extends Pages {

    // TEXTS
    @FindBy(className = "error")
    private SelenideElement investAmountTextError;

    @FindBy(xpath = "//span[contains(@id, 'nationalInsuranceNumber_part1-error')]")
    private SelenideElement ninoOneTextError;

    @FindBy(xpath = "//span[contains(@id, 'nationalInsuranceNumber_part2-error')]")
    private SelenideElement ninoTwoTextError;

    @FindBy(xpath = "//span[contains(@id, 'nationalInsuranceNumber_part3-error')]")
    private SelenideElement ninoThreeTextError;

    @FindBy(xpath = "//span[contains(@id, 'nationalInsuranceNumber_part4-error')]")
    private SelenideElement ninoFourTextError;

    @FindBy(xpath = "//span[contains(@id, 'nationalInsuranceNumber_part5-error')]")
    private SelenideElement ninoFiveTextError;

    @FindBy(xpath = "//span[contains(@id, 'nominatedAccountSortCode_part1-error')]")
    private SelenideElement sortCode1TextError;

    @FindBy(xpath = "//span[contains(@id, 'nominatedAccountSortCode_part2-error')]")
    private SelenideElement sortCode2TextError;

    @FindBy(xpath = "//span[contains(@id, 'nominatedAccountSortCode_part3-error')]")
    private SelenideElement sortCode3TextError;

    @FindBy(xpath = "//span[contains(@class, 'error')]")
    private SelenideElement acctNumberTextError;

    @FindBy(xpath = "//span[contains(@id, 'nominatedAccountPayee-error')]")
    private SelenideElement acctNameTextError;

    @FindBy(xpath = "//div[@id='paymentDiv']/h3")
    private SelenideElement nominatedAccountTitleText;

    // FIELDS
    @FindBy(id = "saleAmount")
    private SelenideElement investAmountField;

    @FindBy(xpath = "//input[contains(@id, 'nominatedAccountSortCode') and contains(@id, 'part1')]")
    private SelenideElement sortcode1Field;

    @FindBy(xpath = "//input[contains(@id, 'nominatedAccountSortCode') and contains(@id, 'part2')]")
    private SelenideElement sortcode2Field;

    @FindBy(xpath = "//input[contains(@id, 'nominatedAccountSortCode') and contains(@id, 'part3')]")
    private SelenideElement sortcode3Field;

    @FindBy(xpath = "//input[contains(@id, 'nominatedAccountNumber')]")
    private SelenideElement acctNumberField;

    @FindBy(xpath = "//input[contains(@id, 'nominatedAccountPayee')]")
    private SelenideElement acctNameField;

    @FindBy(id = "rollNumber")
    private SelenideElement rollNumberField;

    @FindBy(id = "nationalInsuranceNumber_part1")
    private SelenideElement ninoOneField;

    @FindBy(id = "nationalInsuranceNumber_part2")
    private SelenideElement ninoTwoField;

    @FindBy(id = "nationalInsuranceNumber_part3")
    private SelenideElement ninoThreeField;

    @FindBy(id = "nationalInsuranceNumber_part4")
    private SelenideElement ninoFourField;

    @FindBy(id = "nationalInsuranceNumber_part5")
    private SelenideElement ninoFiveField;

    // DROPDOWNS

    // RADIOBUTTONS
    @FindBy(xpath = "//label[contains(@for, 'term:0')]")
    private SelenideElement termRadio;

    @FindBy(xpath = "//label[contains(.,' Pay to my nominated account')]")
    private SelenideElement payToRadio;

    @FindBy(xpath = "//label[contains(.,' Reinvest into Premium Bonds')]")
    private SelenideElement reInvestRadio;

    @FindBy(xpath = "//label[contains(.,' Use an NS&I Direct Saver account')]")
    private SelenideElement useNSIDirectSaverRadio;

    @FindBy(id = "nominatedAccountOption:0")
    private SelenideElement useNSIDirectSaverConfirmationRadio;

    @FindBy(xpath = "//label[contains(.,' Add a new nominated account')]")
    private SelenideElement addNewNominatedAccRadio;

    @FindBy(id = "nominatedAccountOption:2")
    private SelenideElement addNewNominatedAccConfirmationRadio;

    @FindBy(xpath = "//div[@class='field field--radio']/label")
    private SelenideElement checkDirectSaverAccRadio;

    @FindBy(xpath = "//div[@class='field field--radio']/input")
    private SelenideElement checkDirectSaverAccConfirmationRadio;

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    // LINKS
    @FindBy(xpath = "//label[contains(@for,'paperlessValue:0')]")
    private SelenideElement paperLessStatementLink;

    @FindBy(xpath = "//label[contains(@for,'paperlessValue:1')]")
    private SelenideElement byPostStatementLink;

    // ----------------------------------------------------
}