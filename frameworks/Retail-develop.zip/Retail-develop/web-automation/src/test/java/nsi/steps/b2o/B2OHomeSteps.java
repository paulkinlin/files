package nsi.steps.b2o;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import nsi.pages.b2o.B2OHomePage;
import nsi.pages.b2o.B2OLogoutPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.waitUntilVisible;

public class B2OHomeSteps extends Steps {

    private final B2OHomePage b2OHomePage = page(B2OHomePage.class);
    private final B2OLogoutPage b2OLogoutePage = page(B2OLogoutPage.class);

    @When("B2OHomePage: Search Field submit {string}")
    public void b2OHomePageSearchFieldSubmit(String code) {
        b2OHomePage.getSearchField()
                .shouldBe(Condition.and("", Condition.visible, Condition.enabled))
                .setValue(code)
                .pressEnter();
    }

    @And("B2OHomePage: Disconnection")
    public void b2OHomePageDisconnection(){
        b2OHomePage.getDisconnectionButton().execute(waitUntilVisible).click();
        b2OLogoutePage.getSuccessfullyLoggedOut().shouldBe(Condition.visible);
    }
}
