package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import nsi.pages.b2c.customerMaintenance.CashInCloseAccountPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class CashInCloseAccountSteps extends Steps {

    private CashInCloseAccountPage cashInCloseAccountPage = page(CashInCloseAccountPage.class);

    @And("CashInCloseAccountPage: check header")
    public void cashInCloseAccountText() {
        cashInCloseAccountPage.getTitleText().shouldHave(Condition.text("Do you want to close your account?"));
    }

    @And("CashInCloseAccountPage: choose account closure")
    public void cashInCloseAccountConfirm() {
        cashInCloseAccountPage.getYesCloseAccountRadio().click();
        cashInCloseAccountPage.getNextButton().click();
    }
}