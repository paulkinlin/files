package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.ChangeYourMarketingPrefsPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class ChangeYourMarketingPrefsSteps extends Steps {

    private ChangeYourMarketingPrefsPage changeYourMarketingPrefsPage = page(ChangeYourMarketingPrefsPage.class);

    @Then("ChangeYourMarketingPrefs: submit marketingPrefs post {string} email {string} phone {string} onLine {string}")
    public void changeYourMarketingPrefsSubmitMarketingPrefsPostEmailPhoneOnLine(String post, String email,
                                                                                 String phone, String online) {
        changeYourMarketingPrefsPagePost(post);
        changeYourMarketingPrefsPageEmail(email);
        changeYourMarketingPrefsPagePhone(phone);
        changeYourMarketingPrefsPageOnline(online);

        log.info("Submitted marketing prefs: POST {}, EMAIL {}, PHONE {}, WEB {}", post, email, phone, online);
        changeYourMarketingPrefsPage.getConfirmButton().click();
    }

    private void changeYourMarketingPrefsPagePost(String post) {
        if (post.equalsIgnoreCase("yes")) {
            changeYourMarketingPrefsPage.getYesPostCheckbox().click();
            getContext().setMarketingPreferenceByPost(true);
        } else {
            changeYourMarketingPrefsPage.getNoPostCheckbox().click();
            getContext().setMarketingPreferenceByPost(false);
        }
    }

    private void changeYourMarketingPrefsPageEmail(String email) {
        if (email.equalsIgnoreCase("yes")) {
            changeYourMarketingPrefsPage.getYesEmailCheckbox().click();
            getContext().setMarketingPreferenceByEmail(true);
        } else {
            changeYourMarketingPrefsPage.getNoEmailCheckbox().click();
            getContext().setMarketingPreferenceByEmail(false);
        }
    }

    private void changeYourMarketingPrefsPagePhone(String phone) {
        if (phone.equalsIgnoreCase("yes")) {
            changeYourMarketingPrefsPage.getYesPhoneCheckbox().click();
            getContext().setMarketingPreferenceByPhone(true);
        } else {
            changeYourMarketingPrefsPage.getNoPhoneCheckbox().click();
            getContext().setMarketingPreferenceByPhone(false);
        }
    }

    public void changeYourMarketingPrefsPageOnline(String online) {
        if (online.equalsIgnoreCase("yes")) {
            changeYourMarketingPrefsPage.getYesWebCheckbox().click();
            getContext().setMarketingPreferenceOnline(true);
        } else {
            changeYourMarketingPrefsPage.getNoWebCheckbox().click();
            getContext().setMarketingPreferenceOnline(false);
        }
    }
}