package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ThankYouInstructionsPage extends Pages {

    // TEXTS

    @FindBy(xpath = "//h1[@class='hero-header'][contains(.,'Thank you for your instructions')]")
    private SelenideElement thankYouHeaderText;

    // FIELDS

    // DROPDOWNS

    // RADIOBUTTONS

    // CHECKBOXES

    // BUTTONS

    @FindBy(xpath = "//a[contains(.,'Your homepage')]")
    private SelenideElement yourHomePageButton;

    // LINKS

    // ----------------------------------------------------
}