package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NAdHocStatementPage extends Pages {
    // TEXTS

    // FIELDS
    @FindBy(id = "Cb01")
    private SelenideElement accountNumberDropdown;

    // TEXTS

    @FindBy(id = "Tx01")
    private SelenideElement transmissionMediumText;

    @FindBy(id = "Me01")
    private SelenideElement adHocStatementText;


    // TABLES

    @FindBy(xpath = "//*[@id='Ta01']//child::tr[last()]/td[6]")
    private SelenideElement statementType;

    @FindBy(xpath = "//*[@id='Ta01']/tbody//*[contains(@class, 'COLS0')]")
    private SelenideElement noStatementText;

    // BUTTONS

    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

}