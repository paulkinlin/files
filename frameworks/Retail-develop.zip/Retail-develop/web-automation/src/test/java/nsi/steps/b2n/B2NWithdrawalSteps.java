package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NWithdrawalPage;
import nsi.pojos.products.ProductPojo;
import nsi.pojos.products.SetUpProductB2C;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NWithdrawalSteps extends Steps {

    private static final String ATOS_ADDRESS = "Atos, Wearside House, Riverside Place, Durham";

    private final B2NWithdrawalPage b2NWithdrawalPage = page(B2NWithdrawalPage.class);

    @And("B2NWithdrawalPage: select payment channel {string}")
    public void withdrawalPageSelectPaymentChannel(String paymentChannel) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getPaymentChannelSelect().selectOption(paymentChannel);
    }

    @And("B2NWithdrawalPage: select payment mode {string}")
    public void withdrawalPageSelectPaymentMode(String paymentMode) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getPaymentModeSelect().selectOption(paymentMode);
    }

    @And("B2NWithdrawalPage: select reinvestment to account {string}")
    public void withdrawalPageSelectReinvestmentToAccount(String accountNumber) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getReinvestmentToAccountNumberSelect().selectOptionContainingText(accountNumber);
    }

    @And("B2NWithdrawalPage: select account type {string}")
    public void withdrawalPageSelectAccountType(String accountType) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getAccountTypeSelect().selectOption(accountType);
        ProductPojo productPojo = new SetUpProductB2C().returnProductObject(accountType);
            if (productPojo == null) {
                throw new RuntimeException("Product not recognised"); }
            getContext().getProductPojoList().add(productPojo);
            getContext().getProductPojoList().getLast().setTransactionType("Withdrawal");
            productPojo.setProduct(accountType);
    }

    @And("B2NWithdrawalPage: select account number {string}")
    public void withdrawalPageSelectAccountNumber(String account) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getAccountNumberSelect().selectOptionContainingText(account);
    }

    @And("B2NWithdrawalPage: submit account number from context")
    public void withdrawalPageChooseAccountNumberFromJson() {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getAccountNumberSelect().selectOptionContainingText(getContext().getProductPojoList().getFirst().getAccountNumber());
    }

    @And("B2NWithdrawalPage: click button Next")
    public void withdrawalPageClickButtonNext() {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getNextButton().click();
    }

    @And("B2NWithdrawalPage: click button Confirm")
    public void withdrawalPageClickButtonConfirm() {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getConfirmButton().click();
    }

    @And("B2NWithdrawalPage: submit amount requested {string}")
    public void withdrawalPageSubmitAmountRequested(String amount) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getAmountRequestedField().execute(clearAndSetValue(amount));
        b2NWithdrawalPage.getConfirmButton().click();
    }

    @And("B2NWithdrawalPage: verify withdrawal amount requested: {string} payment mode: {string}")
    public void withdrawalPageSelectPaymentMode(String amountRequested, String paymentMode) {
        switchToFrame("dynamic");
        verifyPageTitle("Withdrawal");
        b2NWithdrawalPage.getPaymentModeSelected().shouldHave(Condition.text(paymentMode));
        b2NWithdrawalPage.getAmountRequested().shouldHave(Condition.text(amountRequested));
        getContext().getProductPojoList().getLast().setAmount(amountRequested.replaceAll(" GPB", ""));
    }

    @And("B2NWithdrawalPage: submit Security details answers")
    public void submitSecurityQuestionsAnswers() {
        switchToFrame("dynamic");
        verifyPageTitle("Security details");

        final String questionsOneFieldValue = b2NWithdrawalPage.getQuestionOneField().getText().replaceAll("\\(([\\s\\S]*)\\)", "").replace("?", "").trim();
        final String questionsTwoFieldValue = b2NWithdrawalPage.getQuestionTwoField().getText().replaceAll("\\(([\\s\\S]*)\\)", "").replace("?", "").trim();

        String questionOneLastWord = questionsOneFieldValue.substring(questionsOneFieldValue.lastIndexOf(' ') + 1);
        String questionTwoLastWord = questionsTwoFieldValue.substring(questionsTwoFieldValue.lastIndexOf(' ') + 1);

        b2NWithdrawalPage.getAnswerOneField().execute(clearAndSetValue(questionOneLastWord));
        b2NWithdrawalPage.getAnswerTwoField().execute(clearAndSetValue(questionTwoLastWord));

        b2NWithdrawalPage.getConfirmButton().click();
    }
}