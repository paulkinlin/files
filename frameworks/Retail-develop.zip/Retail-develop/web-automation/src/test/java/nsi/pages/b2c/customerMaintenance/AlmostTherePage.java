package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class AlmostTherePage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[@id='holding']/div")
    private SelenideElement holdersNumberText;

    @FindBy(xpath = "//*[@id='reference']/div")
    private SelenideElement referenceNumber;

    @FindBy(xpath = "//div[@id='saleAmount']/div")
    private SelenideElement totalAmountText;

    @FindBy(xpath = "//*[@id='initialSaleConfirmationScreen']//*[@class='column']")
    private SelenideElement confirmationText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(xpath = "//div[@class='btn-group btn-group--right']/a")
    private SelenideElement continueButton;

    // LINKS

    // ----------------------------------------------------
}