package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NTransactionHistoryPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.*;

@Slf4j
public class B2NTransactionHistorySteps extends Steps {

    private B2NTransactionHistoryPage b2NTransactionHistoryPage = page(B2NTransactionHistoryPage.class);

    @And("B2NTransactionHistoryPage: click next")
    public void transactionhistorypageClickNext() {
        switchToFrame("dynamic");

        sleep(2000);
        b2NTransactionHistoryPage.getNextButton().click();
    }

    @And("B2NTransactionHistoryPage: check movement {string} description {string} amount {string}")
    public void transactionhistorypageCheckMovementDescriptionAmount(String movement, String description, String amount) {
        switchToFrame("dynamic");

        $(By.xpath("//table[@id='Ta01']//td[@align='CENTER' and text()='" + movement + "']/following-sibling::td/a"))
                .shouldHave(Condition.exactText(description));
        $(By.xpath("//table[@id='Ta01']//td[@align='CENTER' and text()='" + movement + "']/following-sibling::td[5]"))
                .shouldHave(Condition.exactText(amount));
    }
}