package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class CashInConfirmPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[@id='movementAmount']/div")
    private SelenideElement amountText;

    @FindBy(xpath = "//h1[contains(.,'Cash in - please confirm')]")
    private SelenideElement headerText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}