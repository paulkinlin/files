package nsi.utils;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;

@Slf4j
public class waitUtils {

    private static WebDriver jsWaitDriver;
    private static WebDriverWait jsWait;
    private static JavascriptExecutor jsExec;

    public static void setDriver(WebDriver driver){
        jsWaitDriver = WebDriverRunner.getWebDriver();
        jsWait = new WebDriverWait(jsWaitDriver,10);
        jsExec = (JavascriptExecutor) jsWaitDriver;
    }

    private static void ajaxComplete(){
        jsExec.executeScript("var callback = arguments[arguments.length - 1];"
        + "var xhr = new XMLHttpRequest();" + "xhr.open('GET', '/Ajax_call', true);"
                + "xhr.onreadystatechange = function() {" + " if (xhr.readyState == 4) {"
                + " callback(xhr.responseText);" + " }" + "};" + "xhr.send();");
    }

    private static void waitForJQueryLoad(){
        try {
            ExpectedCondition<Boolean> jQueryLoad = driver -> ((long)((JavascriptExecutor) WebDriverRunner.getWebDriver())
            .executeScript("return jQuery.active") == 0);
            boolean jqueryReady = (Boolean) jsExec.executeScript("return jQuery.active==0");
            if(!jqueryReady){
                jsWait.until(jQueryLoad);
            }
        } catch (WebDriverException ignored){
        }
    }

    private static void waitForAngularLoad(){
        String angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequest.length ===0";
        angularLoads(angularReadyScript);
    }

    private static void waitUntilJSReady() {
        try {
            ExpectedCondition<Boolean> jsLoad = driver -> ((JavascriptExecutor) WebDriverRunner.getWebDriver())
                    .executeScript("return document.readyState").toString().equals("complete");
            boolean jsReady = jsExec.executeScript("return document.readyState").toString().equals("complete");
            if (!jsReady){
                jsWait.until(jsLoad);
            }
        } catch (WebDriverException ignored){
        }
    }

    private static void waitUntilJQueryReady(){
        Boolean jQueryDefined = (Boolean) jsExec.executeScript("return typeof jQuery != 'undefined'");
        if (jQueryDefined) {
            sleep(20);
            waitForJQueryLoad();
            sleep(20);
        }
    }

    private static void waitUntilAngularReady(){
        try{
            Boolean angularUnDefined = (Boolean) jsExec.executeScript("return window.angular === undefined");
            if (!angularUnDefined){
                Boolean angularInjectorUnDefined = (Boolean) jsExec.executeScript("return angular.element(document).injector() === undefined");
                if(!angularInjectorUnDefined){
                    sleep(20);
                    waitForAngularLoad();
                    sleep(20);
                }
            }
        } catch(WebDriverException ignored){
        }
    }

    private static void angularLoads(String angularReadyScript){
        try {
            ExpectedCondition<Boolean> angularLoad = driver -> Boolean.valueOf(((JavascriptExecutor) WebDriverRunner.getWebDriver())
                    .executeScript(angularReadyScript).toString());
            boolean angularReady = Boolean.valueOf(jsExec.executeScript(angularReadyScript).toString());
            if (!angularReady) {
                jsWait.until(angularLoad);
            }
        } catch (WebDriverException ignored){
        }
    }

    public static void waitAllRequest(){
        waitUntilJSReady();
        ajaxComplete();
        waitUntilJQueryReady();
        waitUntilAngularReady();
    }

    public static void waitPleaseWaitWidgetToDisappear(){
        if($("#loader").isDisplayed()){
            $("#loader").should(Condition.disappear);
            sleep(500);
        }
        if($("#loader").isDisplayed()){
            $("#loader").should(Condition.disappear);
            sleep(500);
        }
    }



}
