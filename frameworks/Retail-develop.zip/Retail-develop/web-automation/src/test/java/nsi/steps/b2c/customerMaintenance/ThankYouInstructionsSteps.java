package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.ThankYouInstructionsPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clickAndWait;
import static nsi.utils.CustomCommands.waitUntilVisible;

public class ThankYouInstructionsSteps extends Steps {

    private ThankYouInstructionsPage thankYouInstructionsPage = page(ThankYouInstructionsPage.class);

    @Then("ThankYouInstructionsPage: click backToHomePage")
    public void thankYouInstructionsBackToHomePage() {
        thankYouInstructionsPage.getYourHomePageButton().execute(waitUntilVisible).execute(clickAndWait);
    }
}