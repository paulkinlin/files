package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NSecurityChangePage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class B2NSecurityChangeSteps extends Steps {

    private B2NSecurityChangePage b2NSecurityChangePage = page(B2NSecurityChangePage.class);

    @And("B2NSecurityChangePage: read The numeric key")
    public void securitychangepageReadTheNumericKey() {
        switchToFrame("dynamic");
        verifyPageTitle("Security change");

        getContext().setOperatorSecurityCode(b2NSecurityChangePage.getPasswordText().getText().trim());
    }
}