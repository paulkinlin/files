package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ThankYouPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[@class='group hero-content']//p")
    private SelenideElement titleText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnConfirm")
    private SelenideElement backToYourDetailsButton;

    // LINKS

    // ----------------------------------------------------
}