package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NPasswordValidationPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ed01")
    private SelenideElement passwordField;

    @FindBy(id = "Ed02")
    private SelenideElement confirmPasswordField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
