package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourPhoneNumberPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//label[@for='challengeQuestion0']")
    private SelenideElement question1Text;

    @FindBy(xpath = "//label[@for='challengeQuestion1']")
    private SelenideElement question2Text;

    @FindBy(xpath = "//div[@id='privatePhoneCallingCode']/div")
    private SelenideElement phoneNo1ConfirmationText;

    @FindBy(xpath = "//div[@id='officePhoneCallingCode']/div")
    private SelenideElement phoneNo2ConfirmationText;

    @FindBy(xpath = "//h3[contains(.,'For your security,')]")
    private SelenideElement headerText;

    // FIELDS
    @FindBy(id = "telephoneNumberOne")
    private SelenideElement phoneNo1Field;

    @FindBy(id = "telephoneNumberTwo")
    private SelenideElement phoneNo2Field;

    @FindBy(xpath = "//input[@id='challengeQuestion0']")
    private SelenideElement answer1Field;

    @FindBy(xpath = "//input[@id='challengeQuestion1']")
    private SelenideElement answer2Field;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement continueConfirmButton;

    // LINKS

    // ----------------------------------------------------
}