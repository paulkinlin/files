package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import nsi.pages.b2c.customerMaintenance.AccountDetailsPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.steps.b2c.customerMaintenance.ChangeYourEmailSteps.newEmailAddress;
import static nsi.steps.b2c.customerMaintenance.ChangeYourPhoneNumberSteps.phoneNumberOne;
import static nsi.steps.b2c.customerMaintenance.ChangeYourPhoneNumberSteps.phoneNumberTwo;

public class AccountDetailsSteps extends Steps {

    private AccountDetailsPage accountDetailsPage = page(AccountDetailsPage.class);

    @And("AccountDetailsPage: click change your address")
    public void accountyourdetailsClickChangeYourAddress() {
        accountDetailsPage.getChangeYourAddressButton().click();
    }

    @And("AccountDetailsPage: click change your phone numbers")
    public void accountyourdetailsClickChangeYourPhoneNumbers() {
        accountDetailsPage.getChangeYourPhoneNumbersButton().click();
    }

    @And("AccountDetailsPage: click change your email address")
    public void accountyourdetailsClickChangeYourEmailAddress() {
        accountDetailsPage.getChangeYourEmailAddressButton().click();
    }

    @And("AccountDetailsPage: click change your marketing preferences")
    public void accountyourdetailsClickChangeYourMarketingPreferences() {
        accountDetailsPage.getChangeYourMarketingPreferencesButton().click();
    }

    @And("AccountDetailsPage: click change your transactional text updates")
    public void accountyourdetailsClickChangeYourTransactionalTextUpdates() {
        accountDetailsPage.getChangeTransactionalTextUpdatesButton().click();
    }

    @And("AccountDetailsPage: click change security questions")
    public void accountyourdetailsClickChangeSecurityQuestions() {
        accountDetailsPage.getChangeSecurityQuestionsButton().click();
    }

    @And("AccountDetailsPage: click change password")
    public void accountyourdetailsClickChangePassword() {
        accountDetailsPage.getChangePasswordButton().click();
    }

    @And("AccountDetailsPage: click change tax details")
    public void accountyourdetailsClickChangeTaxDetails() {
        accountDetailsPage.getChangeTaxDetailsButton().click();
    }

    @And("AccountDetailsPage: phone number confirmation")
    public void accountyourdetailsYourPhoneNumberConfirmation() {
        String prefix = "+44 ";
        String phoneNo1 = prefix + phoneNumberOne.replaceAll("\\s", "");
        String phoneNo2 = prefix + phoneNumberTwo.replaceAll("\\s", "");

        accountDetailsPage.getMainPhoneNumberText().shouldHave(Condition.exactText(phoneNo1));
        accountDetailsPage.getSecondPhoneNumberText().shouldHave(Condition.exactText(phoneNo2));
    }

    @And("AccountDetailsPage: verify default marketing preferences")
    public void accountDetailsCheckDefaultMarketingPrefs() {
        // by default only email address is checked

        accountDetailsPage.getUncheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("by post"));
        accountDetailsPage.getCheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("by email"));
        accountDetailsPage.getUncheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("by phone"));
        accountDetailsPage.getUncheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("online"));
    }

    @And("AccountDetailsPage: verify changed marketing preferences")
    public void accountDetailsCheckChangedMarketingPrefs() {
        accountDetailsPage.getCheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("by post"));
        accountDetailsPage.getUncheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("by email"));
        accountDetailsPage.getCheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("by phone"));
        accountDetailsPage.getCheckedMarketingPrefs().shouldHave(CollectionCondition.itemWithText("online"));
    }

    @And("AccountDetailsPage: emailAddress confirmation")
    public void accountyourdetailsEmailAddressConfirmation() {
        accountDetailsPage.getEmailText().shouldHave(Condition.text(newEmailAddress));
    }
}