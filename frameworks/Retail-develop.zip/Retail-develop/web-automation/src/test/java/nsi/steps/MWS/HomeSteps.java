package nsi.steps.MWS;

import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.MWS.HomePage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.waitUntilVisible;

@Slf4j
public class HomeSteps extends Steps {

    private HomePage homePage = page(HomePage.class);

    @When("the chat is initiated")
    public void clickToAccessChatbot() {
        homePage.getChatbotButton().execute(waitUntilVisible);
        homePage.getChatbotButton().click();
    }

    @When("the customer move to another NS&I webpage")
    public void customerMoveToAnotherWebpage() {
        homePage.getHereToHelpButton().click();
    }
}
