package nsi.pojos;

public enum B2NOperators {
    PKN ("10026818"),
    PKL ("10026819"),
    MK1 ("10026816"),
    MK2 ("10026817"),
    MK3 ("10042675"),
    Mk4 ("10042676"),
    MK5 ("10042677"),
    MK6 ("10042678"),
    MK7 ("10042679"),
    MK8 ("10042680"),
    MKO ("10042681"),
    MKK ("10042682"),
    KP1 ("10042683"),
    KP2 ("10042684"),
    KP3 ("10042685"),
    KP4 ("10042686"),
    ST1 ("10070603"),
    ST2 ("10070604"),
    ST3 ("10070605"),
    ST4 ("10070606"),
    SI1 ("10042687"),
    SI2 ("10042688"),
    SI3 ("10042689"),
    SI4 ("10042690"),
    GK1 ("10042691"),
    GK2 ("10042692"),
    GK3 ("10042693"),
    GK4 ("10042694"),
    SM1 ("10042695"),
    SM2 ("10042696"),
    SM3 ("10042697"),
    SM4 ("10042698"),
    MTPoperatorOne ("10036763"),
    MTPoperatorTwo ("10036764");

    private final String login;
    private final String operatorPass = System.getenv("operatorPass");

    B2NOperators(String login) {
        this.login = login;
    }

    public String returnLogin() {
        return login;
    }

    public String returnPassword() {
        return operatorPass;
    }
}
