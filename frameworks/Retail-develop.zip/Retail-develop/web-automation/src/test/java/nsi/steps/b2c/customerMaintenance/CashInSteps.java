package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.CashInPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

public class CashInSteps extends Steps {

    private CashInPage cashInPage = page(CashInPage.class);

    @Then("CashInPage: submit amount {string}")
    public void cashInAmount(String amount) {
        cashInPage.getAmountField().execute(clearAndSetValue(amount));
        cashInPage.getDeferNoRadio().click();
        cashInPage.getCashInButton().click();
    }

    @And("CashInPage: check error text {string}")
    public void cashInErrorText(String errorMsg) {
        cashInPage.getErrorText().shouldHave(Condition.text(errorMsg));
    }
}