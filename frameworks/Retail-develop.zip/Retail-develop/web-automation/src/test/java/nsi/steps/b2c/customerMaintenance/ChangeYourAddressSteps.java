package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.ChangeYourAddressPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class ChangeYourAddressSteps extends Steps {
    private ChangeYourAddressPage changeYourAddressPage = page(ChangeYourAddressPage.class);

    @Then("ChangeYourAddressPage: validate phone header is displayed and cancel")
    public void changeYourAddressCancel() {
        changeYourAddressPage.getConfirmPhoneNoHeaderText().shouldBe(Condition.visible);
        changeYourAddressPage.getCancelButton().click();
    }
}