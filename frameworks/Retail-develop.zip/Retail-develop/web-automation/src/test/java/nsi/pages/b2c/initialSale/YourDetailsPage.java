package nsi.pages.b2c.initialSale;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

@Getter
public class YourDetailsPage extends Pages {

    //LABELS
    @FindBy(className = "hero-header")
    private SelenideElement heroHeaderText;

    // TEXTS
    @FindBy(id = "unauthenticatedCustomerAddress_addressSelectedLine1")
    private SelenideElement chosenMainInvestorAddressText;

    @FindBy(id = "secondInvestorAddressUnreg_addressSelectedLine1")
    private SelenideElement chosenSecondInvestorAddressText;

    @FindBy(id = "childAddress_addressSelectedLine1")
    private SelenideElement chosenChildAddressText;

    @FindBy(id = "thirdPartyParentAddress_addressSelectedLine1")
    private SelenideElement chosenParentAddressText;

    @FindBy(xpath = "//label[contains(@for,'titleCode_1')]")
    private SelenideElement titleMainInvestorText;

    @FindBy(xpath = "//label[contains(@for,'forename_1')]")
    private SelenideElement forenameMainInvestorText;

    @FindBy(xpath = "//label[contains(@for,'surname_1')]")
    private SelenideElement surnameMainInvestorText;

    @FindBy(xpath = "//label[contains(@for,'dateOfBirth_1_day')]")
    private SelenideElement dobMainInvestorText;

    @FindBy(xpath = "//label[contains(@for,'unauthenticatedCustomerAddress_countryCode')]")
    private SelenideElement countryMainInvestorText;

    @FindBy(xpath = "//label[contains(@for,'unauthenticatedCustomerAddress_houseNumber')]")
    private SelenideElement houseNoMainInvestorText;

    @FindBy(xpath = "//label[contains(@for,'unauthenticatedCustomerAddress_postCode')]")
    private SelenideElement postcodeMainInvestorText;

    @FindBy(xpath = "//span[contains(@id, 'titleCode_1-error')]")
    private SelenideElement titleErrorMsgMainInvestorText;

    @FindBy(xpath = "//span[contains(@id, 'forename_1-error')]")
    private SelenideElement forenameErrorMsgMainInvestorText;

    @FindBy(xpath = "//span[contains(@id, 'surname_1-error')]")
    private SelenideElement surnameErrorMsgMainInvestorText;

    @FindBy(xpath = "//span[contains(@id, 'dateOfBirth_1_day-error')]")
    private SelenideElement dobDayErrorMsgMainInvestorText;

    @FindBy(xpath = "//span[contains(@id, 'dateOfBirth_1_month-error')]")
    private SelenideElement dobMonthErrorMsgMainInvestorText;

    @FindBy(xpath = "//span[contains(@id, 'dateOfBirth_1_year-error')]")
    private SelenideElement dobYearErrorMsgMainInvestorText;

    @FindBy(xpath = "//input[@id='unauthenticatedCustomerAddress_postCode']/following-sibling::span")
    private SelenideElement postcodeErrorMsgMainInvestorText;

    @FindBy(xpath = "//select[@id='unauthenticatedCustomerAddress_addressId']//following-sibling::span")
    private SelenideElement addressSelectErrorMsgMainInvestorText;

    @FindBy(id = "unauthenticatedCustomerAddress_infoukNoAddrList")
    private SelenideElement infoChosenAddressErrorMsgMainInvestorText;

    @FindBy(id = "unauthenticatedCustomerAddress_infoukNoPc")
    private SelenideElement infoPostcodeErrorMsgBoxMainInvestorText;

    @FindBy(xpath = "//div[@class='info-panel info-panel--error']")
    private SelenideElement infoAccountInvestmentNotOnSaleText;

    // LINKS
    @FindBy(id = "unauthenticatedCustomerAddress_noPostCodeLink")
    private SelenideElement dontKnowPostcodeLink;

    @FindBy(xpath = "//a[contains(@id, 'addSecondInvestor')]")
    private SelenideElement addASecondInvestorLink;

    @FindBy(xpath = "//a[contains(@id, 'removeSecondInvestor')]")
    private SelenideElement removeSecondInvestorLink;

    @FindBy(id = "unauthenticatedCustomerAddress_noAddrListLink")
    private SelenideElement cantFindAddressLink;

    // DROPDOWNS
    @FindBy(xpath = "//select[@id='titleCode_1']")
    private SelenideElement titleMainInvestorSelect;

    @FindBy(xpath = "//select[@id='titleCode_2' or @id='titleCode_unknownIdentifier']")
    private SelenideElement titleSecondInvestorSelect;

    @FindBy(id = "titleCode_3")
    private SelenideElement titleChildParentSelect;

    @FindBy(id = "childTitleCode")
    private SelenideElement titleChildSelect;

    @FindBy(id = "dateOfBirth_1_day")
    private SelenideElement dobDayMainInvestorSelect;

    @FindBy(xpath = "//select[@id='dateOfBirth_2_day' or @id='dateOfBirth_unknownIdentifier_day']")
    private SelenideElement dobDaySecondInvestorSelect;

    @FindBy(id = "dateOfBirth_3_day")
    private SelenideElement dobDayChildParentSelect;

    @FindBy(id = "childDateOfBirth_day")
    private SelenideElement dobDayChildSelect;

    @FindBy(id = "dateOfBirth_1_month")
    private SelenideElement dobMonthMainInvestorSelect;

    @FindBy(xpath = "//select[@id='dateOfBirth_2_month' or @id='dateOfBirth_unknownIdentifier_month']")
    private SelenideElement dobMonthSecondInvestorSelect;

    @FindBy(id = "dateOfBirth_3_month")
    private SelenideElement dobMonthChildParentSelect;

    @FindBy(id = "childDateOfBirth_month")
    private SelenideElement dobMonthChildSelect;

    @FindBy(id = "dateOfBirth_1_year")
    private SelenideElement dobYearMainInvestorSelect;

    @FindBy(xpath = "//select[@id='dateOfBirth_2_year' or @id='dateOfBirth_unknownIdentifier_year']")
    private SelenideElement dobYearSecondInvestorSelect;

    @FindBy(id = "dateOfBirth_3_year")
    private SelenideElement dobYearChildParentSelect;

    @FindBy(id = "childDateOfBirth_year")
    private SelenideElement dobYearChildSelect;

    @FindBy(id = "unauthenticatedCustomerAddress_countryCode")
    private SelenideElement countryMainInvestorSelect;

    @FindBy(id = "unauthenticatedCustomerAddress_addressId")
    private SelenideElement addressMainInvestorSelect;

    @FindBy(id = "secondInvestorAddressUnreg_addressId")
    private SelenideElement addressSecondInvestorSelect;

    @FindBy(id = "childAddress_addressId")
    private SelenideElement addressChildSelect;

    @FindBy(id = "thirdPartyParentAddress_addressId")
    private SelenideElement addressParentSelect;

    @FindBy(id = "birthCountry")
    private SelenideElement taxBirthCountryMainInvestorSelect;

    @FindBy(id = "taxCountry")
    private SelenideElement taxCountryMainInvestorSelect;

    @FindBy(id = "birthCountryPbMinor")
    private SelenideElement taxBirthCountryChildSelect;

    @FindBy(id = "taxCountryPbMinor")
    private SelenideElement taxCountryChildSelect;

    // FIELDS
    @FindBy(id = "forename_1")
    private SelenideElement forenameMainInvestorField;

    @FindBy(xpath = "//input[@id='forename_2' or @id='forename_unknownIdentifier']")
    private SelenideElement forenameSecondInvestorField;

    @FindBy(id = "forename_3")
    private SelenideElement forenameChildParentField;

    @FindBy(id = "surname_1")
    private SelenideElement surnameMainInvestorField;

    @FindBy(xpath = "//input[@id='surname_2' or @id='surname_unknownIdentifier']")
    private SelenideElement surnameSecondInvestorField;

    @FindBy(id = "surname_3")
    private SelenideElement surnameChildParentField;

    @FindBy(id = "unauthenticatedCustomerAddress_houseNumber")
    private SelenideElement houseNoMainInvestorField;

    @FindBy(id = "unauthenticatedCustomerAddress_postCode")
    private SelenideElement postcodeMainInvestorField;

    @FindBy(id = "secondInvestorAddressUnreg_postCode")
    private SelenideElement postcodeSecondInvestorField;

    @FindBy(id = "childAddress_postCode")
    private SelenideElement postcodeChildField;

    @FindBy(id = "thirdPartyParentAddress_postCode")
    private SelenideElement postcodeParentField;

    @FindBy(id = "birthCity")
    private SelenideElement taxBirthCityMainInvestorField;

    @FindBy(id = "taxIdentificationNumber")
    private SelenideElement taxIDMainInvestorField;

    @FindBy(id = "childForename")
    private SelenideElement forenameChildField;

    @FindBy(id = "childSurname")
    private SelenideElement surnameChildField;

    @FindBy(id = "birthCityPbMinor")
    private SelenideElement taxBirthCityChildField;

    @FindBy(id = "taxIdentificationNumberPbMinor")
    private SelenideElement taxIDChildField;

    // BUTTONS
    @FindBy(id = "unauthenticatedCustomerAddress_lookupButton")
    private SelenideElement lookUpPostcodeButton;

    @FindBy(id = "secondInvestorAddressUnreg_lookupButton")
    private SelenideElement lookUpPostcodeSecondInvestorButton;

    @FindBy(id = "childAddress_lookupButton")
    private SelenideElement lookUpPostcodeChildButton;

    @FindBy(id = "thirdPartyParentAddress_lookupButton")
    private SelenideElement lookUpPostcodeParentButton;

    @FindBy(xpath = "//input[@value='Continue']")
    private SelenideElement continueButton;

    @FindBy(id = "unauthenticatedCustomerAddress_backButton3")
    private SelenideElement cantFindEditButton;

    // RADIOBUTTONS
    @FindBy(xpath = "//label[@for='residentNonUK_1:0']")
    private SelenideElement taxNonUKYESRadio;

    @FindAll({
            @FindBy(id = "residentNonUK_1:0"),
            @FindBy(id = "pbSoleNonUK:0")
    })
    private SelenideElement taxNonUKYESConfirmationRadio;

    @FindBy(xpath = "//label[@for='residentNonUK_1:1' or @for='pbSoleNonUK:1']")
    private SelenideElement taxNonUKNORadio;

    @FindAll({
            @FindBy(id = "residentNonUK_1:1"),
            @FindBy(id = "pbSoleNonUK:1")
    })
    private SelenideElement taxNonUKNOConfirmationRadio;

    @FindBy(xpath = "//label[@for='pbSoleNonUK:0']")
    private SelenideElement taxNonUKPBYESRadio;

    @FindBy(xpath = "//label[@for='pbSoleNonUK:1']")
    private SelenideElement taxNonUKPBNORadio;

    @FindBy(xpath = "//label[@for='buyingForMinor:0']")
    private SelenideElement buyingForChildYESRadio;

    @FindBy(id = "buyingForMinor:0")
    private SelenideElement buyingForChildYESConfirmationRadio;

    @FindBy(xpath = "//label[@for='buyingForMinor:1']")
    private SelenideElement buyingForChildNORadio;

    @FindBy(id = "buyingForMinor:1")
    private SelenideElement buyingForChildNOConfirmationRadio;

    @FindBy(xpath = "//label[@for='minorThirdPty:0']")
    private SelenideElement buyingForOwnChildRadio;

    @FindBy(id = "minorThirdPty:0")
    private SelenideElement buyingForOwnChildConfirmationRadio;

    @FindBy(xpath = "//label[@for='minorThirdPty:1']")
    private SelenideElement buyingForSomeoneElseChildRadio;

    @FindBy(id = "minorThirdPty:1")
    private SelenideElement buyingForSomeoneElseChildConfirmationRadio;

    @FindBy(xpath = "//label[@for='taxIdentificationSwitch_1']")
    private SelenideElement tinRadio;

    @FindBy(xpath = "//label[@for='childNonUK_2PbMinor:0']")
    private SelenideElement childTaxYESRadio;

    @FindBy(xpath = "//label[@for='childNonUK_2PbMinor:1']")
    private SelenideElement childTaxNORadio;

    @FindBy(xpath = "//label[@for='clientIdentifierKnown:0']")
    private SelenideElement knowNSINumberRadio;

    @FindBy(id = "clientIdentifierKnown:0")
    private SelenideElement knowNSINumberConfirmationRadio;

    @FindBy(xpath = "//label[@for='clientIdentifierKnown:1']")
    private SelenideElement dontKnowNSINumberRadio;

    @FindBy(id = "clientIdentifierKnown:1")
    private SelenideElement dontKnowNSINumberConfirmationRadio;

    //CHECKBOXES
    @FindBy(xpath = "//label[contains(@for, 'childSameAddress')]")
    private SelenideElement childSameAddressCheckbox;

    @FindBy(xpath = "//input[contains(@id, 'childSameAddress')]")
    private SelenideElement childSameAddressConfirmationCheckbox;

    @FindBy(xpath = "//label[@for='parentSameAddress']")
    private SelenideElement parentSameAddressCheckbox;

    @FindBy(id = "parentSameAddress")
    private SelenideElement parentSameAddressConfirmationCheckbox;

    @FindBy(xpath = "//label[@for='taxIdentificationSwitch_1']")
    private SelenideElement taxnoTaxIDCheckbox;

    @FindBy(xpath = "//label[contains(@for, 'sameAddress')]")
    private SelenideElement secondInvestorSameAddressCheckbox;

    @FindBy(xpath = "//input[@id='sameAddressUnauthenticated' or @id='sameAddressAuthenticated']")
    private SelenideElement secondInvestorSameAddressConfirmationCheckbox;

    @FindBy(xpath = "//label[@for='grandParentIndicator']")
    private SelenideElement childsGrandParentCheckbox;

    @FindBy(id = "grandParentIndicator")
    private SelenideElement childsGrandParentConfirmationCheckbox;

    // ----------------------------------------------------
}