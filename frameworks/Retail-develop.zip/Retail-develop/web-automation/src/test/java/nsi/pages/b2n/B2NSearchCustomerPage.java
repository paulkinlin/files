package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSearchCustomerPage extends Pages {

    // TEXTS

    // FIELDS
   @FindBy(id = "Ed04F")
   private SelenideElement accNumberField;

   @FindBy(id = "Ed08")
   private SelenideElement uciNumberField;

   @FindBy(id = "Ed06")
   private SelenideElement niNumberField;

   @FindBy(id = "Ed01")
   private SelenideElement nameField;

   @FindBy(id = "Ed07")
   private SelenideElement firstNameField;

   @FindBy(id = "Ce01")
   private SelenideElement countrySelect;

   @FindBy(name = "Ce02")
   private SelenideElement postCodeField;

   @FindBy(id = "Ed02")
   private SelenideElement dobField;

   @FindBy(id = "Ed09")
   private SelenideElement ifaIDField;

   @FindBy(id = "Ed10")
   private SelenideElement fsaField;

   @FindBy(id = "Ed11")
   private SelenideElement emsField;

   @FindBy(xpath = "//table[@id='Ta01']//tr[not(@class='TITLE')]/td")
   private SelenideElement tableTextField;

    // DROPDOWNS

    // CHECKBOXES
    @FindBy(id = "Ck01")
    private SelenideElement ifaAgentCheckbox;

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement searchButton;

    // LINKS

    // ----------------------------------------------------

}