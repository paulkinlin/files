package nsi.pojos;

import lombok.Data;
import lombok.NoArgsConstructor;
import nsi.pojos.products.ProductPojo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@NoArgsConstructor
@Data
public class Context {
    // Scenarios data
    ClientDataPojo mainInvestorClientData;
    ClientDataPojo secondClientData;
    ClientDataPojo thirdClientData;
    ClientDataPojo firstChildClientData;
    ClientDataPojo secondChildClientData;
    ClientDataPojo latestRegisteredClientData;

    String nsiNumber;
    String operatorSecurityCode;

    // Products data
    LinkedList<ProductPojo> productPojoList = new LinkedList<>();

    Boolean marketingPreferenceByPost = true;
    Boolean marketingPreferenceByEmail = true;
    Boolean marketingPreferenceByPhone = true;
    Boolean marketingPreferenceOnline = true;
    
    // Framework
    String scenarioName;
    String lastUsedOperator = "0";

    // Data from Database
    String clientNumber;

    // to be deleted
    String accountNumber;
    String totalAmount;
    String applicationReference;

    // B2N operator login ids used in the scenario
    transient List<String> userIds = new ArrayList<>();
    List<Map<String, Object>> accountMovements;
}
