package nsi.steps.b2c.initialSale;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.NotifyDetailsPage;
import nsi.pojos.products.PremiumBondProduct;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class NotifyDetailsSteps extends Steps {

    private NotifyDetailsPage notifyDetailsPage = page(NotifyDetailsPage.class);

    @When("NotifyDetailPage: submit prizeNotifyType {string}")
    public void nsiinitialsalepbPrizeNotifyType(String notifyType) {
        switch (notifyType.toLowerCase()) {
            case "email":
                notifyDetailsPage.getPrizeNotifyEmailRadio().click();
                break;
            case "text":
                notifyDetailsPage.getPrizeNotifyTextRadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
        if (getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
            ((PremiumBondProduct) getContext().getProductPojoList().getLast()).setPrizeNotification(notifyType);
        }
        notifyDetailsPage.getContinueButton().click();
    }

    @When("NotifyDetailPage: choose notifyType {string}")
    public void nsiinitialsalepbNotifyType(String notifyType) {
        switch (notifyType.toLowerCase()) {
            case "email":
                notifyDetailsPage.getNotifyEmailRadio().click();
                break;
            case "text":
                notifyDetailsPage.getNotifyTextRadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
        if (getContext().getProductPojoList().getLast() instanceof PremiumBondProduct) {
            ((PremiumBondProduct) getContext().getProductPojoList().getLast()).setPrizeNotification(notifyType);
        }
        notifyDetailsPage.getContinueButton().click();
    }

    @And("NotifyDetailPage: click Continue")
    public void nsiinitialsaleClickContinue() {
        notifyDetailsPage.getContinueButton().click();
    }
}