package nsi.steps.b2c.customerMaintenance;

import io.cucumber.java.en.Then;
import nsi.pages.b2c.customerMaintenance.UploadYourDocumentsPage;
import nsi.steps.Steps;

import static com.codeborne.selenide.Selenide.page;

public class UploadYourDocumentsSteps extends Steps {

    private UploadYourDocumentsPage uploadYourDocumentsPage = page(UploadYourDocumentsPage.class);

    @Then("UploadYourDocumentsPage: upload documents later")
    public void thankYouUpdatedPhoneNoBackToYourDetails() {
        uploadYourDocumentsPage.getUploadLaterButton().click();
    }
}