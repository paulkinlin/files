package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NDematerialisationOptionsPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ta02")
    private SelenideElement table;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
