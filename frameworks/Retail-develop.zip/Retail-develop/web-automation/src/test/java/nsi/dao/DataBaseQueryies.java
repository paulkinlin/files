package nsi.dao;

import DataBase.DatabaseAccess;
import org.sql2o.Connection;
import org.sql2o.data.Table;

import java.util.List;
import java.util.Map;

import static nsi.pojos.ContextFactory.getContext;

public class DataBaseQueryies {

    DatabaseAccess databaseAccess = new DatabaseAccess();

    private Table getAccountMovementsQuery(String numCli) {
        final String query = "select a.numcli, a.numidt as NSI_No, b.nomcli as Surname, c.natenc as Product, " +
                "e.natcpt as Channel, c.numcpt as AcctNo, d.refcta as TRANS_REF, d.nummvt as MOVMNT_NUM, " +
                "e.DATCTA as TRANS_DATE, d.monmvt as TRANS_AMT, d.sgnmvt as TRANS_TYPE, e.SOLCRA_NEW as BALANCE " +
                "from cld70 a, cld01 b, ccd01 c, cgd30 d, msd40 e " +
                "where a.typidt = '17' " +
                "and a.numcli = :numCli " +
                "and a.numcli = b.numcli " +
                "and a.numcli = c.numcli " +
                "and c.NUMCPT = d.NUMCPT " +
                "and d.numcpt = e.numcpt " +
                "and d.REFCTA = e.refcta " +
                "order by c.natenc asc, d.numcpt asc, d.nummvt asc, d.REFCTA asc";
        try (Connection connection = databaseAccess.sql2o.open()) {
            return connection.createQuery(query)
                    .addParameter("numCli", numCli)
                    .executeAndFetchTable();
        }
    }

    public List<Map<String, Object>> getAccountMovements() {
        return getAccountMovementsQuery(getContext().getClientNumber()).asList();
    }
}
