package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NAuthenticateCustomerConfirmPage extends Pages {

    // TEXTS
    @FindBy(id = "Tx02")
    private SelenideElement customerNameText;

    @FindBy(id = "Tx01")
    private SelenideElement addressText;

    @FindBy(id = "Me01")
    private SelenideElement confirmInfoText;
    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    @FindBy(id = "Subm11")
    private SelenideElement cancelButton;

    // LINKS

    // ----------------------------------------------------
}