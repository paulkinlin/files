package nsi.pojos.products;

public class DISAProduct extends ProductPojo {
}
