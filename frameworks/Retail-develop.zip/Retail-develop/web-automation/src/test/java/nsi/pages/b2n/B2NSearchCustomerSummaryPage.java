package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSearchCustomerSummaryPage extends Pages {

    // TEXTS

    // FIELDS
    @FindBy(id = "Ta01")
    private SelenideElement tableWithResults;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm15")
    private SelenideElement authenticateCustomerButton;

    @FindBy(id = "Subm16")
    private SelenideElement summaryOfInitialSalesButton;

    @FindBy(id = "Subm17")
    private SelenideElement registrationButton;

    @FindBy(id = "Subm18")
    private SelenideElement reprintButton;

    @FindBy(id = "Subm80")
    private SelenideElement enquiriesHistoryButton;

    @FindBy(id = "Subm81")
    private SelenideElement fulfilmentButton;

    @FindBy(id = "Subm82")
    private SelenideElement addCustomerButton;

    // LINKS

    // ----------------------------------------------------
}
