package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class TakeMoneyOutConfirmPage extends Pages {

    // TEXTS
    @FindBy(tagName = "h1")
    private SelenideElement titleText;

    // FIELDS

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "btnNext")
    private SelenideElement nextButton;

    // LINKS

    // ----------------------------------------------------
}