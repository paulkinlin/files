package nsi.steps;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pojos.ClientDataPojo;
import nsi.steps.b2n.B2NDashboardSteps;
import nsi.utils.JsonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.io.IOException;
import java.util.ArrayList;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.*;
import static nsi.pojos.ContextFactory.getContext;

@Slf4j
public class CommonSteps {
    CommonStepsElements ele = new CommonStepsElements();

    @Given("Generate main investor client")
    public void generateFirstUKClient() {
        ClientDataPojo mainInvestor = new ClientDataPojo().createClientFromUK();

        getContext().setMainInvestorClientData(mainInvestor);

        log.info("Generated main investor Client From UK: {}", getContext().getMainInvestorClientData());
    }

    @Given("^Generate main investor client between the age of (?:16 and 17)$")
    public void generateMainInvestorClientBetweenSixteenAndSeventeen() {
        ClientDataPojo mainInvestor = new ClientDataPojo().createClientFromUKbetween16and17();

        getContext().setMainInvestorClientData(mainInvestor);

        log.info("Generated main investor Client between the age of 16 and 17 From UK: {}", getContext().getMainInvestorClientData());
    }

    @Given("Generate Second UK client")
    public void generateSecondUKClient() {
        ClientDataPojo secondClient = new ClientDataPojo().createClientFromUK();

        getContext().setSecondClientData(secondClient);

        log.info("Generated Second Client From UK: {}", getContext().getSecondClientData());
    }

    //Use this for all joint tests where second investor is a partner/family
    @Given("Generate Second UK client for Joint Account")
    public void generateSecondUKClientForJointAccount() {
        ClientDataPojo secondClient = new ClientDataPojo().createClientFromUKForJointAccount();

        getContext().setSecondClientData(secondClient);

        log.info("Generated Second Client From UK for joint account: {}", getContext().getSecondClientData());
    }

    @Given("Generate Third UK client")
    public void generateThirdUKClient() {
        ClientDataPojo thirdClient = new ClientDataPojo().createClientFromUK();

        getContext().setThirdClientData(thirdClient);

        log.info("Generated Third Client From UK: {}", getContext().getThirdClientData());
    }

    //Use this for all tests with different child
    @Given("Generate First UK client under 18")
    public void generateFirstUKClientUnder18() {
        ClientDataPojo childClient = new ClientDataPojo().createClientFromUKUnder18();

        getContext().setFirstChildClientData(childClient);

        log.info("Generated First Client From UK under 18 for joint account: {}", getContext().getFirstChildClientData());
    }

    //Use this for all tests with own/my child
    @Given("Generate First UK client under 18 for Joint Account")
    public void generateFirstUKClientUnder18ForJoingAccount() {
        ClientDataPojo childClient = new ClientDataPojo().createClientFromUKUnder18ForJointAccount();

        getContext().setFirstChildClientData(childClient);

        log.info("Generated First Client From UK under 18: {}", getContext().getFirstChildClientData());
    }

    @Given("Generate Second UK client under 18")
    public void generateSecondUKClientUnder18() {
        ClientDataPojo childClient = new ClientDataPojo().createClientFromUKUnder18();

        getContext().setSecondChildClientData(childClient);

        log.info("Generated Second Client From UK under 18: {}", getContext().getSecondChildClientData());
    }

    private static class CommonStepsElements {
        SelenideElement errorBlock = $(By.className("error-summary"));
        SelenideElement heroTitle = $(By.className("hero-content"));
    }

    @When("CommonAction navigate back")
    public void navigate_back() {
        back();
    }

    protected void executeAPIRequestInNewTab(String encodedStr) {
        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("window.open();");
        ArrayList<String> tabs = new ArrayList<String>(WebDriverRunner.getWebDriver().getWindowHandles());
        WebDriverRunner.getWebDriver().switchTo().window(tabs.get(1));
        WebDriverRunner.getWebDriver().get("http://localhost:9010/apirequest/" + encodedStr);
        $(By.cssSelector("pre")).shouldHave(text("Success"));
        WebDriverRunner.getWebDriver().close();
        WebDriverRunner.getWebDriver().switchTo().window(tabs.get(0));

        sleep(100);
    }

    @Then("CommonAction ErrorMessage {string} visible")
    public void commonaction_errormessage_visible(String errorMessage) {
        ele.errorBlock.shouldHave(Condition.text(errorMessage));
    }

    @Given("CommonAction HeroTitle {string} visible")
    public void commonactionHeroTitleVisible(String text) {
        ele.heroTitle.scrollTo().shouldHave(Condition.text(text));
    }

    @And("Save context to JSON")
    public void saveContextToJSON() throws IOException {
        JsonUtils.writeContextToJsonfile(getContext());
    }

    @And("Update surname in the context to be {}")
    public void saveSurNameToJSON(String surname) {
        ClientDataPojo b2OTestClient = new ClientDataPojo().latestRegisteredClientData();
        b2OTestClient.setSurName(surname);
        getContext().setLatestRegisteredClientData(b2OTestClient);
    }

    public static void clearLogOffOperatorAfterFailScenario() {
        B2NDashboardSteps b2NDashboardSteps = new B2NDashboardSteps();
        b2NDashboardSteps.dashboardpageSelect("Log out");
    }
}