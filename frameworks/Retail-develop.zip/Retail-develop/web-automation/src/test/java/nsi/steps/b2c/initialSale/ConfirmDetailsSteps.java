package nsi.steps.b2c.initialSale;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.initialSale.ConfirmDetailsPage;
import nsi.steps.Steps;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;
import static utils.DateUtils.convertDateToDateWithWholeNameOfMonth;

@Slf4j
public class ConfirmDetailsSteps extends Steps {

    private ConfirmDetailsPage confirmDetailsPage = page(ConfirmDetailsPage.class);

    @When("ConfirmDetailsPage: verify name main investor")
    public void nsiinitialsale_verify_name_dob_main_investor() {
        String name = getContext().getMainInvestorClientData().getClientTitleForeSureName();
        String dobBeforeFormat = getContext().getMainInvestorClientData().getDateOfBirth();

        confirmDetailsPage.getNameMainInvestorText().shouldHave(Condition.text(name));
        confirmDetailsPage.getDobMainInvestorText().shouldHave(Condition.text(convertDateToDateWithWholeNameOfMonth(dobBeforeFormat)));
    }

    @When("ConfirmDetailsPage: verify name second investor")
    public void nsiinitialsale_verify_name_dob_second_investor() {
        String name = getContext().getSecondClientData().getClientTitleForeSureName();
        String dobBeforeFormat = getContext().getSecondClientData().getDateOfBirth();

        confirmDetailsPage.getNameSecondInvestorText().shouldHave(Condition.exactText(name));
        confirmDetailsPage.getDobSecondInvestorText().shouldHave(Condition.exactText(convertDateToDateWithWholeNameOfMonth(dobBeforeFormat)));
    }

    @When("ConfirmDetailsPage: verify child name")
    public void nsiinitialsale_verify_name_dob_child() {
        String name = getContext().getFirstChildClientData().getClientTitleForeSureName();
        String dobBeforeFormat = getContext().getFirstChildClientData().getDateOfBirth();

        confirmDetailsPage.getNameChildText().shouldHave(Condition.exactText(name));
        confirmDetailsPage.getDobChildText().shouldHave(Condition.exactText(convertDateToDateWithWholeNameOfMonth(dobBeforeFormat)));
    }

    @When("ConfirmDetailsPage: verify parent name")
    public void nsiinitialsale_verify_name_dob_parent() {
        String name = getContext().getThirdClientData().getClientTitleForeSureName();
        String dobBeforeFormat = getContext().getThirdClientData().getDateOfBirth();

        confirmDetailsPage.getNameParentText().shouldHave(Condition.exactText(name));
        confirmDetailsPage.getDobParentText().shouldHave(Condition.exactText(convertDateToDateWithWholeNameOfMonth(dobBeforeFormat)));
    }


    @When("ConfirmDetailsPage: verify address main investor {string} {string}")
    public void nsiinitialsale_verify_address_main_investor(String address1, String address2) {
        confirmDetailsPage.getAddressMainInvestorText().shouldHave(Condition.text(address1));
        confirmDetailsPage.getAddressMainInvestorText().shouldHave(Condition.text(address2));
        getContext().getMainInvestorClientData().setAddress(confirmDetailsPage.getAddressMainInvestorText().getText().replace("\n", " "));
    }

    @When("ConfirmDetailsPage: verify address second investor {string} {string}")
    public void nsiinitialsale_verify_address_second_investor(String address1, String address2) {
        confirmDetailsPage.getAddressSecondInvestorText().shouldHave(Condition.text(address1));
        confirmDetailsPage.getAddressSecondInvestorText().shouldHave(Condition.text(address2));
        getContext().getSecondClientData().setAddress(confirmDetailsPage.getAddressSecondInvestorText().getText().replace("\n", " "));
    }

    @When("ConfirmDetailsPage: verify address child {string} {string}")
    public void nsiinitialsale_verify_address_child(String address1, String address2) {
        confirmDetailsPage.getAddressChildText().shouldHave(Condition.text(address1));
        confirmDetailsPage.getAddressChildText().shouldHave(Condition.text(address2));
        getContext().getFirstChildClientData().setAddress(confirmDetailsPage.getAddressChildText().getText().replace("\n", " "));
    }

    @When("ConfirmDetailsPage: verify address parent {string} {string}")
    public void nsiinitialsale_verify_address_parent(String address1, String address2) {
        confirmDetailsPage.getAddressParentText().shouldHave(Condition.text(address1));
        confirmDetailsPage.getAddressParentText().shouldHave(Condition.text(address2));
        getContext().getThirdClientData().setAddress(confirmDetailsPage.getAddressParentText().getText().replace("\n", " "));
    }

    @When("ConfirmDetailsPage: verify saleAmt {string}")
    public void nsiinitialsale_verify_saleAmt(String amount) {
        confirmDetailsPage.getInvestmentAmountText().shouldHave(Condition.exactText(amount));
    }

    @When("ConfirmDetailsPage: verify nino for main investor")
    public void nsiinitialsale_verify_nino() {
        String nino = getContext().getMainInvestorClientData().getNinoWithSpaces();
        $(By.xpath("//div[contains(text(),'" + nino + "')]")).shouldHave(Condition.exactText(nino));
    }

    @When("ConfirmDetailsPage: verify prizes paid {string}")
    public void nsiinitialsale_verify_reinvest(String prizePaid) {
        switch (prizePaid.toLowerCase()) {
            case "pay":
                confirmDetailsPage.getPayToAcctText().shouldBe(Condition.visible);
                confirmDetailsPage.getReinvestText().shouldBe(Condition.hidden);
                break;
            case "reinvest":
                confirmDetailsPage.getPayToAcctText().shouldBe(Condition.hidden);
                confirmDetailsPage.getReinvestText().shouldBe(Condition.visible);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("ConfirmDetailsPage: verify acctName {string} sortcode {string} acctNo {string}")
    public void nsiinitialsale_verify_acctName_sortcode_acctNo(String acctName, String sortcode, String acctNo) {
        confirmDetailsPage.getAccountNameText().shouldHave(Condition.exactText(acctName));
        confirmDetailsPage.getSortCodeText().shouldHave(Condition.exactText(sortcode));
        confirmDetailsPage.getAccountNumberText().shouldHave(Condition.exactText(acctNo));
    }

    @When("ConfirmDetailsPage: verify notifyType = {string}")
    public void nsiinitialsale_verify_notifyType(String notifyType) {
        switch (notifyType.toLowerCase()) {
            case "email":
                confirmDetailsPage.getNotifyEmailText().shouldBe(Condition.visible);
                confirmDetailsPage.getNotifyEmailText().shouldBe(Condition.hidden);
                break;
            case "text":
                confirmDetailsPage.getNotifyEmailText().shouldBe(Condition.hidden);
                confirmDetailsPage.getNotifyTextText().shouldBe(Condition.visible);
                break;
            case "paperless":
                confirmDetailsPage.getNotifyNoPaperText().shouldBe(Condition.visible);
                break;
            case "paper":
                confirmDetailsPage.getNotifyPaperText().shouldBe(Condition.visible);
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }

    @When("ConfirmDetailsPage: verify and submit TermsConditions")
    public void nsiinitialsale_verify_and_submit_TermsConditions() {
        confirmDetailsPage.getCustomerBrochureLink().shouldBe(Condition.visible);
        confirmDetailsPage.getPrivacyLink().shouldBe(Condition.visible);
        confirmDetailsPage.getTickToConfirmCheckBox().click();
        confirmDetailsPage.getContinueButton().click();
    }

    @When("ConfirmDetailsPage: verify nonUK tax address")
    public void nsiinitialsale_verify_nonUK_tax_address() {
        confirmDetailsPage.getTaxNonUKYesText().shouldBe(Condition.visible);
        confirmDetailsPage.getTaxNonUKBirthCityText().shouldBe(Condition.visible);
        confirmDetailsPage.getTaxNonUKBirthCountryText().shouldBe(Condition.visible);
        confirmDetailsPage.getTaxNonUKTaxCountryText().shouldBe(Condition.visible);
        confirmDetailsPage.getTaxNonUKTINText().shouldBe(Condition.visible);
    }

    @When("ConfirmDetailsPage: fill tax nonUK second investor {string} city {string} country {string} tax country {string} tax number {string}")
    public void confirmDetailsPageSubmitTaxStatusSecondInvestor(String tax, String city, String country,
                                                                String taxCountry, String taxNumber) {
        switch (tax.toLowerCase()) {
            case "yes":
                confirmDetailsPage.getTaxNonUKYESSecondInvestorRadio().click();

                confirmDetailsPage.getTaxBirthCitySecondInvestorField().execute(clearAndSetValue(city));
                confirmDetailsPage.getTaxBirthCountrySecondInvestorSelect().selectOptionContainingText(country);
                confirmDetailsPage.getTaxCountrySecondInvestorSelect().selectOptionContainingText(taxCountry);
                confirmDetailsPage.getTaxIDSecondInvestorField().execute(clearAndSetValue(taxNumber));
                break;
            case "no":
                confirmDetailsPage.getTaxNonUKNOSecondInvestorRadio().click();
                break;
            default:
                Assert.fail(AssertMessages.NO_CASE_FOUND.toString());
        }
    }
}
