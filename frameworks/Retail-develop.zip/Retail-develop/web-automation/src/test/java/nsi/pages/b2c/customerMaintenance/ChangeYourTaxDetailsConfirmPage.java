package nsi.pages.b2c.customerMaintenance;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class ChangeYourTaxDetailsConfirmPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//div[@id='hero-main-content']/div/h2")
    private SelenideElement titleText;

    @FindBy(xpath = "//div[contains(@id,'residentNonUK')]/div")
    private SelenideElement taxNonUkText;

    @FindBy(xpath = "//div[contains(@id,'birthCity')]/div")
    private SelenideElement birthCityText;

    @FindBy(xpath = "//div[contains(@id,'birthCountry')]/div")
    private SelenideElement birthCountryText;

    @FindBy(xpath = "//div[contains(@id,'taxCountry')]/div")
    private SelenideElement taxCountryText;

    @FindBy(xpath = "//div[contains(@id,'taxIdentificationNumber')]/div")
    private SelenideElement taxIdentificationNumberText;

    // FIELDS

    // DROPDOWNS

    // RADIOBUTTONS

    // CHECKBOXES

    // BUTTONS

    @FindBy(id = "btnNext")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}