package nsi.steps.b2n;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NPasswordValidationPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NPasswordValidationSteps extends Steps {

    private B2NPasswordValidationPage b2NPasswordValidationPage = page(B2NPasswordValidationPage.class);

    @And("B2NPasswordValidationPage: submit password")
    public void passwordvalidationpageSubmitPasswordConfirmPassword() {
        switchToFrame("dynamic");
        verifyPageTitle("Password validation");

        b2NPasswordValidationPage.getPasswordField().execute(clearAndSetValue(SECURITY_PASSWORD));
        b2NPasswordValidationPage.getConfirmPasswordField().execute(clearAndSetValue(SECURITY_PASSWORD));

        b2NPasswordValidationPage.getConfirmButton().click();
        switchToFrame("dynamic");
        if ($(By.xpath("//form[@name='form1']//strong[contains(text(),'Security details')]")).isDisplayed()) {
            new B2NSecurityDetailsSteps().securitydetailspageSubmitAnswers();
        }
    }

    @And("B2NPasswordValidationPage: submit password {string} confirmPassword {string}")
    public void passwordvalidationpageSubmitPasswordConfirmPassword(String password, String confirmPassword) {
        switchToFrame("dynamic");
        verifyPageTitle("Password validation");
        if (password.equals("pass")) {
            password = SECURITY_PASSWORD;
        }
        if (confirmPassword.equals("pass")) {
            confirmPassword = SECURITY_PASSWORD;
        }
        b2NPasswordValidationPage.getPasswordField().execute(clearAndSetValue(password));
        b2NPasswordValidationPage.getConfirmPasswordField().execute(clearAndSetValue(confirmPassword));

        b2NPasswordValidationPage.getConfirmButton().click();
    }
}
