package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NSecurityDetailsPage extends Pages {

    // TEXTS
    @FindBy(xpath = "//fieldset[@class='COLORING']//tr[1]//td[1]")
    private SelenideElement questionOneText;

    @FindBy(xpath = "//fieldset[@class='COLORING']//tr[3]//td[1]")
    private SelenideElement questionTwoText;

    // FIELDS
    @FindBy(id = "Ed01")
    private SelenideElement answerOneField;

    @FindBy(id = "Ed02")
    private SelenideElement answerTwoField;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    // LINKS

    // ----------------------------------------------------
}
