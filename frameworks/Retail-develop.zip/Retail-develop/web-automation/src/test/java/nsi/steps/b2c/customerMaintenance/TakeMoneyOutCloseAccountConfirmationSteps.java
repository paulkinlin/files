package nsi.steps.b2c.customerMaintenance;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2c.customerMaintenance.ConfirmAccountClosureWithSecurityQuestionsPage;
import nsi.pages.b2c.customerMaintenance.TakeMoneyOutCloseAccountConfirmationPage;
import nsi.pojos.ClientDataPojo;
import nsi.steps.Steps;

import static com.codeborne.selenide.Condition.exactText;
import static com.codeborne.selenide.Selenide.page;
import static com.codeborne.selenide.WebDriverRunner.url;
import static nsi.pojos.ContextFactory.getContext;
import static nsi.utils.CustomCommands.clearAndSetValue;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

@Slf4j
public class TakeMoneyOutCloseAccountConfirmationSteps extends Steps {

    private TakeMoneyOutCloseAccountConfirmationPage takeMoneyOutCloseAccountConfirmationPage =
            page(TakeMoneyOutCloseAccountConfirmationPage.class);
    private ConfirmAccountClosureWithSecurityQuestionsPage confirmAccountClosureWithSecurityQuestionsPage = page(ConfirmAccountClosureWithSecurityQuestionsPage.class);

    @And("TakeMoneyOutCloseAccountConfirmationPage: check title")
    public void takemoneyoutCloseAccountConfirmationCheckTitle() {
        takeMoneyOutCloseAccountConfirmationPage.getTitleText()
                .shouldHave(Condition.exactText("Confirm your account closure"));
    }

    @And("TakeMoneyOutCloseAccountConfirmationPage: click confirm")
    public void takemoneyoutCloseAccountClickConfirm() {
        takeMoneyOutCloseAccountConfirmationPage.getConfirmButton().click();
    }

    @And("TakeMoneyOutCloseAccountConfirmationPage: check confirmation title")
    public void takemoneyoutCloseAccountCheckTitle() {
        ClientDataPojo mainInvestor = getContext().getMainInvestorClientData();
        assertThat(url().contains("paymentB2CActions03.jsf"), equalTo(true));
        if(confirmAccountClosureWithSecurityQuestionsPage.getAnswerSecurityQuestionsText().isDisplayed()) {
            confirmAccountClosureWithSecurityQuestionsPage.getAnswerQuestion1Field().execute(clearAndSetValue(mainInvestor.getAnswerQuestion1()));
            confirmAccountClosureWithSecurityQuestionsPage.getAnswerQuestion2Field().execute(clearAndSetValue(mainInvestor.getAnswerQuestion2()));
            confirmAccountClosureWithSecurityQuestionsPage.getConfirmButton().click();
        }
        else {
            takeMoneyOutCloseAccountConfirmationPage.getConfirmPhoneNoText()
                    .shouldHave(exactText("Confirm your phone number"));
        }
    }

    @And("TakeMoneyOutCloseAccountConfirmationPage: check current balance {string} fromAccount {string} toAccount {string}")
    public void takemoneyoutCloseAccountCheckBalanceAccounts(String balance, String fromAccount, String toAccount) {
        takeMoneyOutCloseAccountConfirmationPage.getCurrentBalanceText().shouldHave(Condition.text(balance));
        takeMoneyOutCloseAccountConfirmationPage.getFromAccountText().shouldHave(Condition.text(fromAccount));
        takeMoneyOutCloseAccountConfirmationPage.getToAccountText().shouldHave(Condition.text(toAccount));
    }

    @And("TakeMoneyOutCloseAccountConfirmationPage: check requested amount {string} interest {string} amount to be paid {string}")
    public void takemoneyoutCloseAccountCheckInterestTotalAmount(String requestedAmount, String interest, String amountToBePaid) {
        takeMoneyOutCloseAccountConfirmationPage.getHeader().shouldHave(Condition.exactText("How much you will receive"));
        takeMoneyOutCloseAccountConfirmationPage.getRequestedAmountText().shouldHave(Condition.text(requestedAmount));
        takeMoneyOutCloseAccountConfirmationPage.getInterestAmountText().shouldHave(Condition.text(interest));
        takeMoneyOutCloseAccountConfirmationPage.getAmountToBePaidText().shouldHave(Condition.text(amountToBePaid));
    }
}