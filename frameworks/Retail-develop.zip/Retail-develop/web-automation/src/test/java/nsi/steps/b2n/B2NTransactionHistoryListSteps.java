package nsi.steps.b2n;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NTransactionHistoryListPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.page;

@Slf4j
public class B2NTransactionHistoryListSteps extends Steps {

    private B2NTransactionHistoryListPage b2NTransactionHistoryListPage = page(B2NTransactionHistoryListPage.class);

    @And("B2NTransactionHistoryListPage: select Description {string}")
    public void transactionhistorylistpageSelectDescription(String description) {
        switchToFrame("dynamic");

        b2NTransactionHistoryListPage.getHistoryTable()
                .shouldBe(Condition.visible)
                .findAll(By.tagName("tr"))
                .find(Condition.text(description))
                .find(By.tagName("a"))
                .shouldBe(Condition.and("not clickable", Condition.visible, Condition.enabled))
                .click();
    }
}