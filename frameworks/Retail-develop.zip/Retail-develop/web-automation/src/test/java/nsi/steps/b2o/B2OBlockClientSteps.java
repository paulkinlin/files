package nsi.steps.b2o;

import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import nsi.pages.b2o.B2OBlockAccountPage;
import nsi.pages.b2o.B2OBlockClientPage;
import nsi.steps.Steps;
import static com.codeborne.selenide.Selenide.page;
import static nsi.pojos.ContextFactory.getContext;

public class B2OBlockClientSteps extends Steps {

    private B2OBlockAccountPage b2OBlockAccountPage = page(B2OBlockAccountPage.class);
    private B2OBlockClientPage b2OBlockClientPage = page(B2OBlockClientPage.class);

    @When("B2OBlockClientPage: Search field submit client number from context")
    public void b2OSearchFieldClientNumberSubmit() {
        String clientNumber = getContext().getClientNumber();
        b2OBlockClientPage.getClientNumberSearchField()
                .shouldBe(Condition.and("",Condition.visible, Condition.enabled))
                .setValue(clientNumber)
                .pressEnter();
    }

    @And("B2OBlockClientPage: Validate blocking code {} and blocking label {}")
    public void b2OValidateBlockingReasonValues(String associatedCode, String associatedLabel){
        b2OBlockClientPage.getBlockingCodeText().shouldHave(Condition.text(associatedCode));
        b2OBlockClientPage.getBlockingCodeLabelText().shouldHave(Condition.text(associatedLabel));
        b2OBlockAccountPage.getBlockAccountConfirmButton().click();
    }
}
