package nsi.steps.b2n;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import nsi.pages.b2n.B2NAuthenticateCustomerPage;
import nsi.steps.Steps;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static nsi.utils.CustomCommands.clearAndSetValue;

@Slf4j
public class B2NAuthenticateCustomerSteps extends Steps {

    private B2NAuthenticateCustomerPage b2NAuthenticateCustomerPage = page(B2NAuthenticateCustomerPage.class);

    @And("B2NAuthenticateCustomerPage: submit password")
    public void authenticatecustomerpageSubmitPassword() {
        switchToFrame("dynamic");

        int orderPassOne = Integer.parseInt(b2NAuthenticateCustomerPage.getPasswordOrderOneText().getText());
        int orderPassTwo = Integer.parseInt(b2NAuthenticateCustomerPage.getPasswordOrderTwoText().getText());

        String firstCharacter = SECURITY_PASSWORD.substring(orderPassOne - 1, orderPassOne);
        String secondCharacter = SECURITY_PASSWORD.substring(orderPassTwo - 1, orderPassTwo);

        b2NAuthenticateCustomerPage.getPasswordOneField().execute(clearAndSetValue(firstCharacter));
        b2NAuthenticateCustomerPage.getPasswordTwoField().execute(clearAndSetValue(secondCharacter));

        log.info("character one: {}, characterTwo: {}", firstCharacter, secondCharacter);

        b2NAuthenticateCustomerPage.getNextButton().click();
        switchToFrame("dynamic");
        if ($(By.xpath("//form[@name='form1']//strong[contains(text(),'Security details')]")).isDisplayed()) {
            new B2NSecurityDetailsSteps().securitydetailspageSubmitAnswers();
        }
    }

    @And("B2NAuthenticateCustomerPage: set customer ID {string}")
    public void authenticatecustomerpageSetCustomerId(String customerID) {
        switchToFrame("dynamic");

        b2NAuthenticateCustomerPage.getCustomerIDField().execute(clearAndSetValue(customerID));
    }

    @When("B2NAuthenticateCustomerPage: click next")
    public void authenticatecustomerpageClickNext() {
        switchToFrame("dynamic");

        b2NAuthenticateCustomerPage.getNextButton().click();
    }

}