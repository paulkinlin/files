package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NAddContactLogPage extends Pages {
    // TEXTS

    // FIELDS
    @FindBy(id = "Cb01")
    private SelenideElement typeOfContactSelect;

    @FindBy(id = "Cb02")
    private SelenideElement bankProductSelect;

    @FindBy(xpath = "//textarea[@name='Me01']")
    private SelenideElement noteField;

    @FindBy(xpath = "//td/*[@id='Tx01']")
    private SelenideElement lookUpcustomerName;

    @FindBy(xpath = "//td/*[@id='Tx04']")
    private SelenideElement lookUpTypeOfContact;

    @FindBy(xpath = "//td/*[@id='Tx06']")
    private SelenideElement lookUpBankProduct;

    @FindBy(xpath = "//textarea")
    private SelenideElement lookUpNoteTextArea;

    @FindBy(id = "Rd99")
    private SelenideElement latestContactLogEntryRadioButton;

    // DROPDOWNS

    // CHECKBOXES

    // BUTTONS
    @FindBy(id = "Subm10")
    private SelenideElement confirmButton;

    @FindBy(xpath = "//img[contains(@src, 'button04.gif')]")
    private SelenideElement lookUpButton;

    // TABLES

    @FindBy(id = "row01")
    private SelenideElement latestContactLogEntry;

    // LINKS

    // ----------------------------------------------------
}