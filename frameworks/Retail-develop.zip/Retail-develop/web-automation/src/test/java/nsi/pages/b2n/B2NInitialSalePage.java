package nsi.pages.b2n;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import nsi.pages.Pages;
import org.openqa.selenium.support.FindBy;

@Getter
public class B2NInitialSalePage extends Pages {

    // TEXTS

    @FindBy(xpath = "//form[@name='form1']")
    private SelenideElement pageTitle;

    // FIELDS
    //product Selection
    @FindBy(id = "Cb01")
    private SelenideElement productSelect;

    @FindBy(id = "CbA1")
    private SelenideElement channelOfEnquirySelect;

    @FindBy (id = "Ck02")
    private SelenideElement minorAccountCheckbox;


    //customer details
    @FindBy(id = "Cb08")
    private SelenideElement accountTypeSelect;

    @FindBy(xpath = "//p[contains(text(),'Title')]/../..//select")
    private SelenideElement titleSelect;

    @FindBy(xpath = "//p[contains(text(), 'Surname')]/../..//input")
    private SelenideElement surnameField;

    @FindBy(xpath = "//p[contains(text(), 'Forenames')]/../..//input")
    private SelenideElement forenamesField;

    @FindBy(xpath = "//p[contains(text(), 'Date of birth')]/../..//input")
    private SelenideElement dobField;

    @FindBy(xpath = "//p[contains(text(), 'NI Number')]/../..//input")
    private SelenideElement niNumberField;

    @FindBy(xpath = "//p[contains(text(), 'Main phone number')]/../..//input")
    private SelenideElement mainPhoneField;

    @FindBy(xpath = "//p[contains(text(), 'Email address')]/../..//input")
    private SelenideElement emailAddressField;

    //customer address
    @FindBy(id = "Cb07")
    private SelenideElement countrySelect;

    @FindBy(id = "Ed01F")
    private SelenideElement postCodeField;

    @FindBy(id = "Ed02")
    private SelenideElement addressField;

    //customer preference
    @FindBy(id = "Rd16Y")
    private SelenideElement paperlessCheckbox;

    @FindBy(id = "Rd16N")
    private SelenideElement postCheckbox;

    @FindBy(id = "Rd17Y")
    private SelenideElement smsNotificationCheckbox;

    @FindBy(id = "Rd17N")
    private SelenideElement emailNotificationCheckbox;

    //media code
    @FindBy(id = "Cb06")
    private SelenideElement mediaCodeSelect;

    //nominated account
    @FindBy(id = "Rd0101")
    private SelenideElement payToMyNSIAccountRadioButton;

    @FindBy(id = "Rd0102")
    private SelenideElement payToMyExternalAccountRadioButton;

    @FindBy(id = "RdA1BAC")
    private SelenideElement payToNominatedAccountRadioButton;

    @FindBy(id = "Ed17")
    private SelenideElement sortCodeField;

    @FindBy(id = "Ed20")
    private SelenideElement accountNumberField;

    @FindBy(id = "Ed21")
    private SelenideElement rollNumberField;

    @FindBy(id = "Ed22")
    private SelenideElement nameField;

    @FindBy(id = "error")
    private SelenideElement errorText;

    //payment details
    @FindBy(id = "Ed23")
    private SelenideElement amountDepositField;

    @FindBy(id = "Rd0202")
    private SelenideElement payByDebitCardRadioButton;

    //prize payment option
    @FindBy(id = "RdA1BAC")
    private SelenideElement nominatedAccountCheckbox;

    @FindBy(id = "RdA1WAR")
    private SelenideElement warrantCheckbox;

    @FindBy(id = "CkC2")
    private SelenideElement reinvestCheckbox;

    //prize notification option
    @FindBy(id = "RdB1CEE")
    private SelenideElement emailCheckbox;

    @FindBy(id = "RdB1SMS")
    private SelenideElement textCheckbox;

    @FindBy(id = "RdB1PAP")
    private SelenideElement postCheckboxByPrizeNotificationOption;

    //receipt of documentation option
    @FindBy(id = "CkC1")
    private SelenideElement paperlessCheckboxByReceiptDocumentationOption;

    @FindBy(id = "Ed30")
    private SelenideElement cityOfBirth;

    // DROPDOWNS
    @FindBy(id = "Cb32")
    private SelenideElement countryOfBirthSelect;

    @FindBy(id ="Cb31")
    private SelenideElement taxCountrySelect1;

    @FindBy(id = "Ed29")
    private SelenideElement taxIdentificationNo1;

    // CHECKBOXES
    @FindBy(id = "Ck90")
    private SelenideElement sameAddressCheckbox;

    // BUTTONS
    @FindBy(xpath = "//input[@value='Next']")
    private SelenideElement nextButton;

    @FindBy(id = "Subm83")
    private SelenideElement searchButton;

    @FindBy(id = "Subm84")
    private SelenideElement resetButton;

    @FindBy(id = "Subm82")
    private SelenideElement confirmButton;

    @FindBy(id = "btnSubmit")
    private SelenideElement payNowButton;

    // LINKS

    // ----------------------------------------------------
}