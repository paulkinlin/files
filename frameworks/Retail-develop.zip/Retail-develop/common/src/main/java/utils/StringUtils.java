package utils;

import org.apache.commons.lang3.RandomStringUtils;

public class StringUtils {
    public static String generateTextWhenParamEqualsString(String bodyParam, int numberOfCharacters){
        return bodyParam.equals("randomTextWithTheGivenNumberOfCharacters") ? RandomStringUtils.randomAlphanumeric(numberOfCharacters) : bodyParam;
    }
}
