package utils;

import DataBase.EnvironmentDao;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;

@Slf4j
public class DateUtils {

    public static String getAdjustedDOBDay(int adjustDays) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, adjustDays);
        String newDateFormat = sdf.format(cal.getTime());
        return newDateFormat.split("-")[2];
    }

    public static String getAdjustedDOBMonth(int adjustDays) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, adjustDays);
        String newDateFormat = sdf.format(cal.getTime());
        return newDateFormat.split("-")[1];
    }

    public static String getAdjustedDOBYear(int adjustDays) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, adjustDays);
        String newDateFormat = sdf.format(cal.getTime());
        return newDateFormat.split("-")[0];
    }

    public static String getYearOfNextTuesday() {
        return getNextTues().split("-")[0];
    }

    public static String getMonthOfNextTuesday() {
        return getNextTues().split("-")[1];
    }

    public static String getDayOfNextTuesday() {
        return getNextTues().split("-")[2];
    }

    public static String getYearOfNextWednesday() {
        return getNextWed().split("-")[0];
    }

    public static String getMonthOfNextWednesday() {
        return getNextWed().split("-")[1];
    }

    public static String getDayOfNextWednesday() {
        return getNextWed().split("-")[2];
    }

    public static String getYearOfNextSaturday() {
        return getNextSat().split("-")[0];
    }

    public static String getMonthOfNextSaturday() {
        return getNextSat().split("-")[1];
    }

    public static String getDayOfNextSaturday() {
        return getNextSat().split("-")[2];
    }

    public static String getNextTues() {
        LocalDate nextTues = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.TUESDAY));
        return nextTues.toString();
    }

    public static String getNextWed() {
        LocalDate nextWed = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.WEDNESDAY));
        return nextWed.toString();
    }

    public static String getNextSat() {
        LocalDate nextSat = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.SATURDAY));
        return nextSat.toString();
    }

    public static String getDateOfNextWeekday(String dayOfWeek) {
        String dateToReturn = "";
        LocalDate weekDate = null;
        switch (dayOfWeek.toLowerCase()) {
            case "monday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            case "tuesday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.TUESDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            case "wednesday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.WEDNESDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            case "thursday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.THURSDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            case "friday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.FRIDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            case "saturday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.SATURDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            case "sunday":
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
                dateToReturn = weekDate.toString().split("-")[2];
                break;

            default:
                weekDate = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.WEDNESDAY));
                dateToReturn = weekDate.toString().split("-")[2];
        }
        return dateToReturn;
    }

    public static int checkForWeekEnd(int adjustDays) {
        int weekDayAdjustment = 0;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, adjustDays);
        String weekday = Integer.toString(Calendar.DAY_OF_WEEK);

        switch (weekday) {
            case "1": // sunday so make it tuesday
                weekDayAdjustment = weekDayAdjustment + 2;
                break;

            case "7": // saturday so make it thursday
                weekDayAdjustment = weekDayAdjustment - 2;
                break;

            default:
                weekDayAdjustment = 0;
        }

        return weekDayAdjustment;
    }

    public static String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH_mm");
        Date dn = new Date();
        return sdf.format(dn);
    }

    public static String convertDateToDateWithWholeNameOfMonth(String dobBeforeFormat) {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter formatRequired = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        String dob = LocalDate.parse(dobBeforeFormat, format).format(formatRequired);
        return dob;
    }

    public static String getDOBFromBusinessDateMinusYearsMonthsDays(String businessDate, long years, long months, long days) {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter formatRequired = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return LocalDate.parse(businessDate, format).minusYears(years).minusMonths(months).minusDays(days).format(formatRequired);
    }

    public static String getBusinessDateForApiRequest() {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMdd");
        return LocalDateTime.of(LocalDate.parse(new EnvironmentDao().getBusinessDate(), format), LocalTime.now()).atOffset(ZoneOffset.UTC).toString();
    }

    public static String getFakeBusinessDateForApiRequest() {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMdd");
        return LocalDateTime.of(LocalDate.parse(new EnvironmentDao().getBusinessDate(), format), LocalTime.now()).plusDays(1).atOffset(ZoneOffset.UTC).toString();
    }

}