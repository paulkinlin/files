package environment;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum EnvironmentType {
    MTI("https://c1nm0306lmtfc30.ns901.net:63343/thc/",
            "https://c1nm0305lmkyd30.ns901.net/kyudob2nmti/jsp/authenticationB2NOTPEN.jsp?init",
            "https://c1nm0307lmtfo30.ns901.net:56443/tho/policyenforcer/pages/loginB2O.jsf",
            "jdbc:oracle:thin:@mn-rac-ret-scan.ns901.net:1800/TLRMTI1_SVC",
            "https://ol-sit.ns901.net",
            "https://eacc-nsi-idp.worldline-solutions.com/api",
            "https://qa.nsandi.com/") {
    },
    MTC("https://c1nm0306lmtfc30.ns901.net:62743/thc/",
            "https://c1nm0305lmkyd30.ns901.net/kyudob2nmtc/jsp/authenticationB2NOTPEN.jsp?init",
            "https://c1nm0307lmtfo30.ns901.net:55843/tho/policyenforcer/pages/loginB2O.jsf",
            "jdbc:oracle:thin:@mn-rac-scan.ns901.net:1800/TLRMTC1_SVC",
            "https://ol-sit.ns901.net",
            "https://eacc-nsi-idp.worldline-solutions.com/api",
            "https://qa.nsandi.com/") {
    },
    IDT("https://gnsvlbwdtatfa05:63343/thc/",
            "https://10.61.10.90/kyudob2nidt/jsp/authenticationB2NOTPEN.jsp",
            "https://10.65.166.19:56443/tho/policyenforcer/pages/loginB2O.jsf",
            "jdbc:oracle:thin:@dev-iib-cluster-scan:1527/TLRIDT1_SVC",
            "https://ol-sit.ns901.net",
            "https://eacc-nsi-idp.worldline-solutions.com/api",
            "https://qa.nsandi.com/") {
    },
    MTK("https://c1nm0306lmtfc30.ns901.net:63543/thc/",
            "https://c1nm0305lmkyd30.ns901.net/kyudob2nmtk/jsp/authenticationB2NOTPEN.jsp",
            "https://c1nm0307lmtfo30.ns901.net:56643/tho/policyenforcer/pages/loginB2O.jsf",
            "jdbc:oracle:thin:@mn-rac-ret-scan.ns901.net:1800/TLRMTK1_SVC",
            "https://ol-sit.ns901.net",
            "https://eacc-nsi-idp.worldline-solutions.com/api",
            "https://qa.nsandi.com/") {
    },
    MTO("https://c1nm0306lmtfc30.ns901.net:63943/thc/policyenforcer/pages/loginB2C.jsf",
            "https://c1nm0305lmkyd30.ns901.net/kyudob2nmto/jsp/authenticationB2NOTPEN.jsp",
            "https://c1nm0307lmtfo30.ns901.net:56643/tho/policyenforcer/pages/loginB2O.jsf",
            "jdbc:oracle:thin:@mn-rac-ret-scan.ns901.net:1800/TLRMTO1_SVC",
            "https://ol-sit.ns901.net",
            "https://eacc-nsi-idp.worldline-solutions.com/api",
            "https://qa.nsandi.com/") {
    };

    private final String baseUrlB2C;
    private final String baseUrlB2N;
    private final String baseUrlB2O;
    private final String dataBaseAddress;
    private final String baseUrlPT1;
    private final String eaccUrl;
    private final String BaseUrlMWS;
}
