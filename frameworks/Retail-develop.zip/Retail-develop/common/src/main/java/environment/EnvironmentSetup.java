package environment;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EnvironmentSetup {

    private final EnvironmentType defaultEnvironment = EnvironmentType.MTI;
    private EnvironmentType selectedEnvironment;

    public EnvironmentType getEnvironment() {
        selectedEnvironment = determineEnvironment();
        return selectedEnvironment;
    }

    private EnvironmentType determineEnvironment() {
        EnvironmentType environmentType = defaultEnvironment;
        try {
            environmentType = EnvironmentType.valueOf(System.getProperty("env").toUpperCase());
            log.info("Selected environment is " + environmentType);
        } catch (IllegalArgumentException ignore) {
            System.err.println("Unknow environment type, defaulting to " + environmentType);
        } catch (NullPointerException ignore) {
            System.err.println("No environment type specified, defaulting to " + environmentType);
        }
        return environmentType;
    }

    public String getBaseUrlB2C() {
        return selectedEnvironment.getBaseUrlB2C();
    }

    public String getBaseUrlB2N() {
        return selectedEnvironment.getBaseUrlB2N();
    }

    public String getDataBaseAddress() {
        return selectedEnvironment.getDataBaseAddress();
    }
}
