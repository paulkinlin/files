package environment;

public class EnvironmentFactory {

    private static EnvironmentSetup environmentSetup = new EnvironmentSetup();

    public static EnvironmentType getEnvironment() {
        return environmentSetup.getEnvironment();
    }
}
