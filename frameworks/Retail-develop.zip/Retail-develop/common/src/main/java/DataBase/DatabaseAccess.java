package DataBase;

import org.sql2o.Sql2o;

import static environment.EnvironmentFactory.getEnvironment;

public class DatabaseAccess {

    public Sql2o sql2o;
    private final String dataBasePass = System.getenv("dataBasePass");

    public DatabaseAccess() {
        this.sql2o = new Sql2o(getEnvironment().getDataBaseAddress(), "Test01", dataBasePass);
    }
}
