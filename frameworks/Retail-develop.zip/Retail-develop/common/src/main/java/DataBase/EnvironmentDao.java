package DataBase;

import org.sql2o.Connection;

public class EnvironmentDao {
    DatabaseAccess databaseAccess = new DatabaseAccess();
    public String getBusinessDate() {
        final String query = "SELECT max(BUSDAT) from cwd36";
        try (Connection connection = databaseAccess.sql2o.open()) {
            return connection.createQuery(query).executeAndFetchFirst(String.class);
        }
    }
}
