package nsi.AuthenticationUtils;

import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.HttpClient;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static io.restassured.config.HttpClientConfig.httpClientConfig;

@Slf4j
public class DBEPUserRegistrar extends BaseWLConnector {

    private static final String SCOPE_OPENID = "openid";
    private static final String RESPONSE_TYPE_CODE = "code";
    private static final String CLIENT_ID = "B2C-IPE";
    private static final int OTP_PHONE_NUMBER = 1;
    private static final int OTP_PASSWORD = 123;
    private static final String VALIDATE_ACTION = "validate";
    private static final String RSA_DEVICE_PRINT = "version=3.5.1_4&pm_fpua=mozilla/5.0 (windows nt 6.1) applewebkit/537.36 (khtml, like gecko) chrome/27.0.1453.116 safari/537.36|5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36|Win32&pm_fpsc=32|1440|900|860&pm_fpsw=|pdf&pm_fptz=0&pm_fpln=lang=en-GB|syslang=|userlang=&pm_fpjv=1&pm_fpco=1&pm_fpasw=pepflashplayer|internal-remoting-viewer|ppgooglenaclpluginchrome|pdf|nppdf32|npauthz|npspwrap|npican|npgoogleupdate3|npjp2|npswf32_11_6_602_171|npdeployjava1&pm_fpan=Netscape&pm_fpacn=Mozilla&pm_fpol=true&pm_fposp=&pm_fpup=&pm_fpsaw=1440&pm_fpspd=32&pm_fpsbd=&pm_fpsdx=&pm_fpsdy=&pm_fpslx=&pm_fpsly=&pm_fpsfse=&pm_fpsui=&pm_os=Windows&pm_brmjv=27&pm_br=Chrome&pm_inpt=&pm_expt=";

    public DBEPUserRegistrar() {
        super();
    }

    public DBEPUserRegistrar(String proxyHost, int proxyPort) {
        super(proxyHost, proxyPort);
    }

    @SneakyThrows
    public void register(String userId, String userName, String userPassword) {
        AbstractHttpClient httpClient = new DefaultHttpClient();

        startSession(httpClient, userId);

        Map<String, String> cookies = extractCookies(httpClient);

        confirmUsernameAndPassword(userId, userName, userPassword, cookies);
        chooseOtpPhoneNumber(cookies);
        String pin = selectPinNumber(cookies);
        setPinNumber(pin, cookies);
        confirmPinNumber(pin, cookies);
    }

    @SneakyThrows
    private void startSession(HttpClient httpClient, String userId) {
        log.info("Start session");
        Response authResponse = given()
                .config(new RestAssuredConfig().httpClient(httpClientConfig()
                        .httpClientFactory(() -> httpClient)
                        .setParam(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY)))
                .pathParam("scope", SCOPE_OPENID)
                .pathParam("request", createToken(userId))
                .pathParam("response_type", RESPONSE_TYPE_CODE)
                .pathParam("client_id", CLIENT_ID)
                .formParam("rsaDevicePrint", RSA_DEVICE_PRINT)
                .when()
                .log().uri()
                .redirects().follow(true)
                .get("https://eacc-nsi-idp.worldline-solutions.com/auth/realms/NsiIdp/protocol/openid-connect/auth?scope={scope}&request={request}&response_type={response_type}&client_id={client_id}");
        log.info("Response status: {}", authResponse.getStatusCode());
    }

    private void confirmUsernameAndPassword(String userId, String userName, String userPassword, Map<String, String> cookies) {
        log.info("Confirm username and password");
        Response response = given()
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("uciValue", userId)
                .formParam("surnameValue", userName)
                .formParam("passwordValue", userPassword)
                .formParam("rsaDevicePrint", RSA_DEVICE_PRINT)
                .when()
                .log().uri()
                .post("https://eacc-nsi-idp.worldline-solutions.com/api/login");
        log.info("Response status: {}", response.getStatusCode());

        followRedirect(response, cookies);
    }

    private void chooseOtpPhoneNumber(Map<String, String> cookies) {
        log.info("Choose OTP phone number");
        Response response = given()
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("numberChosenId", OTP_PHONE_NUMBER)
                .when()
                .log().uri()
                .post("https://eacc-nsi-idp.worldline-solutions.com/api/otpChoosePhoneNumber");
        log.info("Response status: {}", response.getStatusCode());

        followRedirect(response, cookies);
    }

    private String selectPinNumber(Map<String, String> cookies) {
        log.info("Select PIN number");
        Response response = given()
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("otp", OTP_PASSWORD)
                .formParam("action", VALIDATE_ACTION)
                .formParam("rsaDevicePrint", RSA_DEVICE_PRINT)
                .when()
                .log().uri()
                .post("https://eacc-nsi-idp.worldline-solutions.com/api/otp");
        log.info("Response status: {}", response.getStatusCode());

        Response redirectResponse = followRedirect(response, cookies).getResponse();

        return pickPinNumber(redirectResponse);
    }

    private void setPinNumber(String pin, Map<String, String> cookies) {
        log.info("Set PIN number");
        Response response = given()
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("pin", pin)
                .formParam("rsaDevicePrint", RSA_DEVICE_PRINT)
                .when()
                .log().uri()
                .post("https://eacc-nsi-idp.worldline-solutions.com/api/pin/setting");
        log.info("Response status: {}", response.getStatusCode());

        followRedirect(response, cookies);
    }

    private void confirmPinNumber(String pin, Map<String, String> cookies) {
        log.info("Confirm PIN number");
        Response response = given()
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("pin", pin)
                .formParam("rsaDevicePrint", RSA_DEVICE_PRINT)
                .when()
                .log().uri()
                .post("https://eacc-nsi-idp.worldline-solutions.com/api/pin/confirm");
        log.info("Response status: {}", response.getStatusCode());

        followRedirect(response, cookies);
    }
}
