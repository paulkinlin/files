package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

public class PT1_1_14_GetNominatedBankAccountSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want nominated bank account for account id {string}")
    public void getNominatedBankAccountForAccountId(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Response contains accountIdent {string}, bank name {string} and accountId type {string}")
    public void validateAccountDetails(String accountIdent, String bankName, String accountIdType) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(accountIdent, baseSteps.response.body().path("nominatedAccountId")),
                () -> assertEquals(bankName, baseSteps.response.body().path("nominatedBankName")),
                () -> assertEquals(accountIdType, baseSteps.response.body().path("nominatedAccountIdType"))
        );
    }
}