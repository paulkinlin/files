package nsi.utils;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum AssertMessages {

    RESPONSE_VALIDATION_FAILURE("Response validation failure");

    private String text;

    @Override
    public String toString() {
        return this.text;
    }
}