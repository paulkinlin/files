package nsi.utils;

import com.google.gson.Gson;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;
import lombok.extern.slf4j.Slf4j;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.util.Map;

import static nsi.utils.GeneratePublicKey.generatePublicKey;
import static org.junit.Assert.*;

@Slf4j
public class AuthenticationUtils {


    private static RSAPublicKey publicKey;
    private static final String PAYLOAD = "\\src\\test\\resources\\pt1\\templates\\payload.json";

    static {
        try {
            publicKey = generatePublicKey();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Generate the encrypted token
     * @param uci of the selected customer
     */
    public static String generateEncryptedToken(String uci) throws IOException, ParseException, JOSEException {
        Gson gson = new Gson();
        String rootPath = System.getProperty("user.dir");
        Reader reader = Files.newBufferedReader(Paths.get(rootPath + PAYLOAD));
        Map mappedPayLoad = gson.fromJson(reader, Map.class);
        ((Map)((Map)mappedPayLoad.get("claims")).get("userinfo")).put("user_id", uci);
        JWTClaimsSet jwtClaims = new JWTClaimsSet.Builder(JWTClaimsSet.parse(mappedPayLoad)).build();
        JWEHeader header = new JWEHeader(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM);
        EncryptedJWT jwt = new EncryptedJWT(header, jwtClaims);
        RSAEncrypter encrypter = new RSAEncrypter(publicKey);
        encrypter.getJCAContext().setProvider(BouncyCastleProviderSingleton.getInstance());
        jwt.encrypt(encrypter);
        return jwt.serialize();
    }

    public static String generateAccessToken(String encryptedToken){
        String accessToken = "";

        try {
            final ProcessBuilder pb = new ProcessBuilder(
                    "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                    "-Command",
                    "sh src/test/java/nsi/get_dbep_token_windows.sh",
                    encryptedToken
            );

            pb.redirectErrorStream(true);
            File outputLog = new File("outputLog.log");
            File errorLog = new File("errorFile.log");
            pb.redirectError(errorLog);
            pb.redirectOutput(outputLog);

            final Process p = pb.start();
            log.info("Bash script execution in progress for encryptedToken: " + encryptedToken);
            assertTrue(p.waitFor() >=0);

            accessToken = new String(Files.readAllBytes(Paths.get("token.txt")));

        } catch (
                IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return accessToken;
    }


}
