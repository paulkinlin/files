package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PT1_1_4_GetMarketingPreferencesSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want marketing preferences for a customer id {string}")
    public void marketingPreferencesForCustomer(String customerId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("customerId", customerId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Set customerId {string}")
    public void setAccountType(String customerId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.queryParam("customerId", customerId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("I validate getMarketingPreferences {string} and {string} and {string}")
    public void validateChannelAndAgreement(String channel, String consentAgreementIndicator, String consentType) {
        List<String> channelList = Arrays.asList(channel.split(", "));
        List<String> consentTypeList = Arrays.asList(consentType.split(", "));
        List<Boolean> consentAgreementIndicatorList = Arrays.stream(consentAgreementIndicator.split(", "))
                .map(Boolean::valueOf).collect(Collectors.toList());

        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> IntStream.range(0, channelList.size())
                        .forEach(index -> assertEquals(channelList.get(index),
                                baseSteps.response.body().path("preferences[" + index + "].channel"))),
                () -> IntStream.range(0, consentTypeList.size())
                        .forEach(index -> assertEquals(consentTypeList.get(index),
                                baseSteps.response.body().path("preferences[" + index + "].consentType"))),
                () -> IntStream.range(0, consentAgreementIndicatorList.size())
                        .forEach(index -> assertEquals(consentAgreementIndicatorList.get(index),
                                baseSteps.response.body().path("preferences[" + index + "].consentAgreementIndicator")))
        );
    }
}