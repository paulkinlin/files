package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.util.ArrayList;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_7_ListPBSpecificTransactionDetailsSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Response contains bondNumberRange {string} and bondRangeValue {string}")
    public void validateBondNumberRangeAndBondRangeValue(String bondNumberRange, String bondRangeValue) {
        ArrayList<Map<String, String>> transactionDetailsList = baseSteps.response.body().path("transactionDetails");
        transactionDetailsList.forEach(transactionMapDetails -> {
            assertAll("Response does not contains ",
                    () -> assertEquals(bondNumberRange, transactionMapDetails.get("bondNumberRange")),
                    () -> assertEquals(bondRangeValue, transactionMapDetails.get("bondRangeValue"))
            );
        });
    }

    @Given("I want list premium bond specific transaction for the account id {string}")
    public void listPBSpecificTransactionForAccount(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("I want list premium bond specific transaction for the transaction Id {string}")
    public void listPBSpecificTransactionForTransaction(String transactionId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("dbTechnicalId", transactionId);
            return ctx.next(requestSpec, responseSpec);
        });
    }
}
