package nsi;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Hooks {

    @Before
    public void setup(Scenario sc) {
        log.info("Start scenario: {}", sc.getName());
        RestAssured.reset();
    }

    @After
    public void exit() {

        java.io.File pin = new java.io.File("pin.html");
        java.io.File code = new java.io.File("code.txt");
        java.io.File cookiejar = new java.io.File("cookiejar");
        java.io.File token = new java.io.File("token.txt");

        if((pin).exists()){
            pin.delete();
        }

        if((code).exists()){
            code.delete();
        }

        if((cookiejar).exists()){
            cookiejar.delete();
        }

        if((token).exists()){
            token.delete();
        }

    }
}
