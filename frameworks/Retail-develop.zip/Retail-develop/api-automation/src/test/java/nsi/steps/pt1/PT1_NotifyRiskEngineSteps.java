package nsi.steps.pt1;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.apache.commons.lang3.RandomStringUtils;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

@Slf4j
public class PT1_NotifyRiskEngineSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Update request body template with bodyparam {string} having length {int} {string} characters")
    public void setRequestBodyDefaultsNotifyRiskEngineValuesAndBodyparamLengthLength(String bodyparam, int length, String chartype ) throws IOException {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.getBody();
            return ctx.next(requestSpec, responseSpec);
        });

        String value = chartype.equals("alphanumeric") ? RandomStringUtils.randomNumeric(length) : RandomStringUtils.randomAlphanumeric(length);
        baseSteps.replaceBodyFieldValue(bodyparam, value);
    }
}
