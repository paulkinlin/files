package nsi.steps.pt1;

import io.cucumber.java.en.When;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

public class PT1_1_9_UpdateAccountPreferencesSteps {

    @Inject
    private BaseSteps baseSteps;

    @When("Set request body parameters {booleanOrString} {booleanOrString} and accountId as pathParam")
    public void setBodyAndPathParameters(Object paperlessNotification, Object textNotification) throws IOException {
        baseSteps.getAccountId();
        baseSteps.requestSpecification.body(baseSteps.getPayload("accountPreferences.json"));
        baseSteps.replaceBodyFieldValue("paperlessNotification", paperlessNotification);
        baseSteps.replaceBodyFieldValue("textNotification", textNotification);
    }
}
