package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.SneakyThrows;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

public class PT1_15_ValidateDepositDebitCardSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want to update path param with transactionId")
    public void updatePathParamWithTransactionId() {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("transactionId", baseSteps.dbTechnicalId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("I want to update path param with transactionId {string}")
    public void updatePathParamWithTransactionId(String transactionId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("transactionId", transactionId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @SneakyThrows
    @And("I want to retrieve transactionId from response")
    public void retrieveTransactionIdFromResponse() {
        baseSteps.dbTechnicalId = baseSteps.response.body().path("transactionId");
        baseSteps.setBaseRequest("BASEHEADERS");
    }
}
