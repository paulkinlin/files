package nsi.AuthenticationUtils;

import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.HttpClient;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;

import java.security.SecureRandom;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static io.restassured.config.HttpClientConfig.httpClientConfig;

@Slf4j
public class DBEPTokenFactory extends BaseWLConnector {

    private static final String SCOPE_OPENID = "openid";
    private static final String RESPONSE_TYPE_CODE = "code";
    private static final String CLIENT_ID = "B2C-IPE";
    private static final String CLIENT_SECRET = "7fc60de5-8ecd-4727-b05d-96ca514b5b27";
    private static final String WL_AUTHORIZATION_TOKEN = "eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..SKqYJRERJENA6YmK6ip5WA.HoEEBckmWwqW0c59Stq17zR86w-5JDXgLDJq47Rul6lqlLR8N16gFMYCT2zAt2Wf2-QvZiOoCjl6mDJmX69C_CgSQ8n1K6AHkX2KLqP5E1FXiBVYWRuikfzxwa9S0a8pUZP8l6zdThIoyjn8eOJgPiOsz7Lz2bCyO7CtGh7ODxsvLFksSAOWNtbnGDxMmUpBnrysF0d6dvA8jLisZ3LEw4fWCbkpqAVkN4ytr40sc_15cvZ1Nt3tk27gB_xdqO11HGuJ7HvH3jEnntZdTHpPoOaAYJTTVL4WlaASvriPC-M8GZ4qRIZumx9ohxzWVDlSsJSfOev1smzWFDE9V1ltsChMTWs2MFuXqonKY91LBAARqrSiH0AFBX8DqPLmkudU4M2IqHODojOGzA7VMxMTN2YY6bI0ryzS1-ljCTuw4NLg1CSj1YEMB6h93dutnIACDgQAEcbC9mSmA8j99egkSRG-mh9pQzWzGcxFK3kyjU5gCVVkhEJ_11eDL2R03wokp-wNE4_QCD5LVnbvZcB4JDlWhN2YeJ4cOhQP0gWrJAMf2QcWBKA-qR9col8zp7eixq3zUiesWMaXCsY7fgWnA902mcRtvdKXJIm6rwy6b3MEhfLWqwWvPwZDdWe2rX8xm4ILeYY0pu78Eq4B2S-gvluXnNQV04v_QE-PFjD8z7LufbJq5ECXyI5QpYuBoO9SoUZgqzfSnFGsYAcRj3etd7DJnpM5EmBab32f2Np-8MLRVBjt7-QSeYnpQNU9Q5vmm8bQjLHEKndP9LXfI1x07JTFjjrCLwmxOxkppickA98FUehqoU-reS6xGjV_JiGJlESzC1m2ePnat_Eek3jdSNmrIKLUS9Pwa4QwVrg2pevgM9bkILcpcp_ehIqgr8N-oP4lyOg6mfCWx51Wdl8_X9seJi6BjjcxfrJrdAeCmQLznDi-NDwvHsX6y5lmZYxA5T0HhTr0V3d9p_VkjBbSskmT403SynU2qv9t2Ix8nMi2foy3hpsumKvB-JZuMlkpkAQ98jJzRKG_4rRYuw9ZEb5BAbIQX9Epidd_4W5bPIj5FVqlg-pzVIQKBPgkTE8ioyDvpD09pjAjcBscAREgXgRUXtET1k2S2BbnSJmBkX9gQeTFi7PImdiju-IEIo8WfHHSaN_UiNOIoU3g3hhNEgPuZT_tLSZTdDUlANuYaDek4YzJYfnBIoZQyfojwzCR4LNDbczQkx6zPb5vTuHr-Qhz7POyvhRDSJoQ7CVQOf0rPFhPNNu_pM1Qy_ckYVDIxDwyJTByC_n6h2oQfCLo43pma1BvSHahSUo8WRipnUjFKYYAyc8ehNcAQvysLW3geK94KL9UMREHKSbAnDkfc1zQvE12GXlXY9g2Qyr4WTZknsSun8JuB2Y3E3I0yQEAWixBh-B09hYrIpiXEZ9EWLFUG7u0hXfUBaKfhZMGe6JzMQIBybJpwZWl5e14GTz3i67UCLRV35fTEPiTJ18BcrTRXu5JzP0YdxeOjkrpWlpxDSBFeGp1Ed9hpAnPinPEy6CpR4jQxyXO4vUE5HLxPQ65WMHPTehfwEEKBAGzecw.ScbIjrpYXTWuYh82D7Cb0w";
    private static final String GRANT_TYPE_AUTH_CODE = "authorization_code";
    private static final String STATE = "RD_hiDm5Bb7_FKNxz5nDWKmhBp4bzCIVobmY9xnRLXA.0TkHV4wZixU.B2C-IPE";
    private static final String CODE_VERIFIER = "YLWZNfrThK8WyupeBiP6S.s64k9HCJYTOlkXNeNN-7uXE9Uv4Gc7yO1xSxMiIs9TT.TwddK9QHTvehRJ1871zTxVzq_dxJII0EYl4Vpjv6G6beMTcX6nHBHEuQ3QD7~e";
    private static final String GRANT_TYPE_CLIENT_CREDENTIALS = "client_credentials";
    private static final String DBEP_TOKEN_TYPE = "END_USER_FROM_TENANT";
    private static final String DBEP_EXTERNAL_TOKEN_TYPE = "nsi_customer_authentication";
    private static final String DBEP_KEY_ID = "9ddaa96c-f5e9-41e7-97f1-800a40c53660";
    private static final String DBEP_AUTHORIZATION = "Basic bW9iaWxlX2F1dGg6bW9iaWxlX2F1dGhfcGFzc3dvcmQ=";
    private static final String NSANDI_ADDRESS = "https://www.nsandi.com";
    private static final String RSA_DEVICE_PRINT = "version=3.5.1_4&pm_fpua=mozilla/5.0 (windows nt 6.1) applewebkit/537.36 (khtml, like gecko) chrome/27.0.1453.116 safari/537.36|5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36|Win32&pm_fpsc=32|1440|900|860&pm_fpsw=|pdf&pm_fptz=0&pm_fpln=lang=en-GB|syslang=|userlang=&pm_fpjv=1&pm_fpco=1&pm_fpasw=pepflashplayer|internal-remoting-viewer|ppgooglenaclpluginchrome|pdf|nppdf32|npauthz|npspwrap|npican|npgoogleupdate3|npjp2|npswf32_11_6_602_171|npdeployjava1&pm_fpan=Netscape&pm_fpacn=Mozilla&pm_fpol=true&pm_fposp=&pm_fpup=&pm_fpsaw=1440&pm_fpspd=32&pm_fpsbd=&pm_fpsdx=&pm_fpsdy=&pm_fpslx=&pm_fpsly=&pm_fpsfse=&pm_fpsui=&pm_os=Windows&pm_brmjv=27&pm_br=Chrome&pm_inpt=&pm_expt=";

    public DBEPTokenFactory() {
        super();
    }

    public DBEPTokenFactory(String proxyHost, int proxyPort) {
        super(proxyHost, proxyPort);
    }

    @SneakyThrows
    public String getDBEPToken(String userId) {
        AbstractHttpClient httpClient = new DefaultHttpClient();

        String pin = getPin(httpClient, userId);

        Map<String, String> cookies = extractCookies(httpClient);

        String code = getCode(pin, cookies);
        String wlAccessToken = getWLAccessToken(code, cookies);
        return getDBEPAccessToken(wlAccessToken, cookies);
    }

    @SneakyThrows
    private String getPin(HttpClient httpClient, String userId) {
        log.info("Getting pin");
        Response pinResponse = given()
                .config(new RestAssuredConfig().httpClient(httpClientConfig()
                        .httpClientFactory(() -> httpClient)
                        .setParam(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY)))
                .pathParam("scope", SCOPE_OPENID)
                .pathParam("request", createToken(userId))
                .pathParam("response_type", RESPONSE_TYPE_CODE)
                .pathParam("client_id", CLIENT_ID)
                .when()
                .log().uri()
                .redirects().follow(true)
                .get("https://eacc-nsi-idp.worldline-solutions.com/auth/realms/NsiIdp/protocol/openid-connect/auth?scope={scope}&request={request}&response_type={response_type}&client_id={client_id}");
        log.info("Response status: {}", pinResponse.getStatusCode());

        return pickPinNumber(pinResponse);
    }

    private String getCode(String pin, Map<String, String> cookies) {
        log.info("Getting code");
        Response codeRedirectResponse = given()
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("pin", pin)
                .formParam("rsaDevicePrint", RSA_DEVICE_PRINT)
                .when()
                .log().uri()
                .post("https://eacc-nsi-idp.worldline-solutions.com/api/pin");
        log.info("Response status: {}. Expecting 302 for POST request", codeRedirectResponse.getStatusCode());

        RedirectResponse redirectResponse = followRedirect(codeRedirectResponse, cookies);

        String codePart = redirectResponse.getLocation().substring(redirectResponse.getLocation().indexOf("code="));
        String code = codePart.substring("code=".length(), codePart.contains("&") ? codePart.indexOf("&") : codePart.length());
        log.info("Received code: {}", code);
        return code;
    }

    private String getWLAccessToken(String code, Map<String, String> cookies) {
        log.info("Getting WL access token");
        Response wlAccessTokenResponse = given()
                .header("Authorization", WL_AUTHORIZATION_TOKEN)
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .formParam("grant_type", GRANT_TYPE_AUTH_CODE)
                .formParam("client_id", CLIENT_ID)
                .formParam("client_secret", CLIENT_SECRET)
                .formParam("redirect_uri", NSANDI_ADDRESS)
                .formParam("code", code)
                .formParam("state", STATE)
                .formParam("nonce", generateNonce())
                .formParam("code_verifier", CODE_VERIFIER)
                .when()
                .log().uri()
                .redirects().follow(true)
                .post("https://eacc-nsi-idp.worldline-solutions.com/auth/realms/NsiIdp/protocol/openid-connect/token");
        log.info("Response status: {}", wlAccessTokenResponse.getStatusCode());

        String wlAccessToken = wlAccessTokenResponse.getBody().jsonPath().getString("access_token");
        log.info("WL access token: {}", wlAccessToken);
        return wlAccessToken;
    }

    private String getDBEPAccessToken(String wlAccessToken, Map<String, String> cookies) {
        log.info("Getting DBEP access token");
        Response dbepAccessTokenResponse = given()
                .header("Authorization", DBEP_AUTHORIZATION)
                .contentType(ContentType.URLENC)
                .cookies(cookies)
                .pathParam("key_id", DBEP_KEY_ID)
                .formParam("grant_type", GRANT_TYPE_CLIENT_CREDENTIALS)
                .formParam("scope")
                .formParam("token_type", DBEP_TOKEN_TYPE)
                .formParam("external_token_type", DBEP_EXTERNAL_TOKEN_TYPE)
                .formParam("external_token", wlAccessToken)
                .when()
                .log().uri()
                .redirects().follow(true)
                .post("https://api.nsiuat.dxp.delivery/core/authentication/api/v1/token?KeyId={key_id}");
        log.info("Response status: {}", dbepAccessTokenResponse.getStatusCode());

        String dbepAccessToken = dbepAccessTokenResponse.getBody().jsonPath().getString("access_token");
        log.info("DBEP access token: {}", dbepAccessToken);
        return dbepAccessToken;
    }

    private String generateNonce(){
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < 22; i++) {
            stringBuilder.append(secureRandom.nextInt(10));
        }
        return stringBuilder.toString();
    }
}
