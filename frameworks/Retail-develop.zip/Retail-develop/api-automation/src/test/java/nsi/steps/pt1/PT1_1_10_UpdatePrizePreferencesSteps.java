package nsi.steps.pt1;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.io.IOException;
@Slf4j
public class PT1_1_10_UpdatePrizePreferencesSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body with Payment Option {string}, Notification Option {string} and Reinvestment Switch {booleanValue}")
    public void setRequestBodyForUpdatePrizePreferences(String paymentOption, String notificationOption, Boolean reinvestmentSwitch) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("updatePrizePreferences.json"));
        baseSteps.replaceBodyFieldValue("prizePaymentOption", paymentOption);
        baseSteps.replaceBodyFieldValue("prizeNotificationOption", notificationOption);
        baseSteps.replaceBodyFieldValue("prizeReinvestmentSwitch", reinvestmentSwitch);
    }
}
