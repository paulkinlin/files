package nsi.steps.pt1;

import io.cucumber.java.en.And;
import nsi.configuration.EndPoints;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

public class PT1_AllAPIEndpointsUnauthorizedSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Call {string} on the service for {string} endpoint with fake path params")
    public void callServiceWithFakePathParams(String requestMethod, String endpoint) {
        String finalEndpoint = EndPoints.valueOf(endpoint).getEndpoint().replaceAll("\\{([^/]*)", "fake");
        baseSteps.chooseRequestMethod(requestMethod, finalEndpoint);
    }
}
