package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.junit.Assert;
import org.picocontainer.annotations.Inject;

@Slf4j
public class PT1_1_3_ListTransactionsSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want to list transactions for account id {string}")
    public void listTransactionsForAccountId(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("List of transactions start date as {string} and end date as {string}")
    public void listTransactionsAccountingDates(String startDate, String endDate) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.queryParam("startAccountingDate", startDate);
            requestSpec.queryParam("endAccountingDate", endDate);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Response contains transaction count {int}")
    public void validateTransactionCount(Integer transactionCount) {
        Assert.assertEquals(transactionCount, baseSteps.response.body().path("accountTransactions.size()"));
    }

    @And("Response contains account number {string}")
    public void validateAccountNumber(String accountNumber) {
        Assert.assertEquals(accountNumber, baseSteps.response.body().path("accountNumber"));
    }

}
