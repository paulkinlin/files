package nsi.AuthenticationUtils;

import io.restassured.response.Response;
import lombok.experimental.Delegate;

public class RedirectResponse {

    @Delegate
    private Response response;
    private String location;

    public RedirectResponse(Response response, String location) {
        this.response = response;
        this.location = location;
    }

    public String getLocation() {
        return location;
    }

    public Response getResponse() {
        return response;
    }
}
