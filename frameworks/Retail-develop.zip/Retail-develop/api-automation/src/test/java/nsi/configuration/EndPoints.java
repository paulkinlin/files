package nsi.configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum EndPoints {

    //--------------- PT1 ENDPOINTS ------------------
    HEADROOM("account/v2/customers/accounts/{accountId}/headroom"),
    PRIZEPREFERENCES("account/v1/customers/premium-bonds-accounts/{premiumBondId}/prize-preferences"),
    LISTPORTFOLIO("customer/v3/customers/accounts"),
    MARKETINGPREFERENCES("customer/v1/customers/marketing-preferences"),
    AUTHTOKEN("https://login.nsiuat.dxp.delivery/api/token-gen/encrypted/?format=JSON"),
    LISTTRANSACTIONS("account/v3/accounts/{accountId}/transactions"),
    CUSTOMERDETAILS("customer/v2/customers"),
    CUSTOMERPERSONALPREFERENCES("customer/v1/customers/accounts/{accountId}/preference/{preferenceKey}"),
    PROXYDETAILS("account/v1/customers/proxies"),
    NOMINATEDBANKACCOUNT("account/v1/customers/accounts/{accountId}/nominated-bank-account"),
    PRODUCTDETAILS("product/v3/accounts/{accountId}/product"),
    ACCOUNTPREFERENCES("account/v1/customers/accounts/{accountId}/preferences"),
    PORTFOLIOBALANCES("account/v1/portfolio/balances"),
    ACCOUNTBALANCES("account/v1/customers/accounts/{accountId}/balances"),
    LISTPBPECIFICTRANSACTIONDETAILS("account/v2/customers/premium-bonds-accounts/{accountId}/transactions/{dbTechnicalId}/details"),
    GETPBACCOUNTSPECIFICINFORMATION("/account/v2/customers/premium-bonds-accounts/{accountId}"),
    LISTPENDINGWITHDRAWAL("/payment/v1/customers/accounts/{accountId}/pending-withdrawals"),
    INITIATEWITHDRAWAL("payment/v1/customers/accounts/{accountId}/withdrawals"),
    UPDATEPRIZEPREFERENCES("account/v1/customers/premium-bonds-accounts/{accountId}/prize-preferences"),
    VALIDATEDEPOSITDEBITCARD("payment/v1/customers/accounts/debit-card-deposits/{transactionId}/validate"),
    INITIATEDEPOSITCREDITCARD("payment/v1/customers/accounts/{accountId}/debit-card-deposits"),
    BANKCONTACTDETAILS("utility/v1/banks/{sortCode}/contact-details"),
    VALIDATEBANKACCOUNTEXISTS("utility/v1/nbd/exists"),
    DELETEPIN("/authenticator/delete?uci={UCI}"),
    NOTIFYRISKENGINE("risk-fraud/v1/customers/notify-risk-engine"),
    SENDSMS("/messaging/v1/sms"),
    ANALYZETRANSACTIONFORRISK("/risk-fraud/v1/customers/analyze-transaction-for-risk"),
    PROXY("http://10.18.2.19:8080"),

    //--------------- PT2 ENDPOINTS ------------------
    ADDCUSTOMERTAXDETAILSFORSPECIFICCUSTOMER("/customer/v1/customers/{customerId}/tax-details"),
    THIRDPARTYTAXDATA("/daily-banking-third-parties/v3/thrid-party-tax-data"),
    DELETECUSTOMERTAXDETAILS("/customer/v1/customers/tax-details/{taxDetailsId}"),
    ADDCUSTOMERTAXDETAILS("/customer/v1/customers/tax-details"),
    THIRDPARTYCONTACTDATA("/daily-banking-third-parties/v3/third-party-contact-data"),
    UPDATERESIDENTIALADDRESS("/customer/v1/customers/residential-address/{addressId}"),
    UPDATECUSTOMERTAXDETAILS("/customer/v1/customers/tax-details/{taxDetailsId}"),
    ADDEMAILADDRESS("/customer/v1/customers/email-addresses"),
    UPDATEEMAILADDRESS("/customer/v1/customers/email-addresses/{emailAddressId}"),
    SETCALLCONTEXT("/customer/v1/call-context"),
    VALIDATECUSTOMERREGISTERED("/customer/v1/customers/validate-customer-registered");


    private final String endpoint;
}
