package nsi.steps.pt1;

import io.cucumber.java.en.And;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class PT1_19_ProxyDetailsSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Response contains client title {string}, first name {string} last name {string} and authority {string}")
    public void validateCustomerDetailsResponse(String title, String firstName, String lastName, String authorityType) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(title, baseSteps.response.body().path("proxies[0].clientTitle")),
                () -> assertEquals(firstName, baseSteps.response.body().path("proxies[0].clientFirstName")),
                () -> assertEquals(lastName, baseSteps.response.body().path("proxies[0].clientLastname")),
                () -> assertEquals(authorityType, baseSteps.response.body().path("proxies[0].authorityType"))
        );
    }

    @And("Response is an empty proxy array")
    public void validateEmptyProxyArray() {
        ArrayList<String> proxiesArray = baseSteps.response.body().path("proxies");
        assertTrue(proxiesArray.isEmpty());
    }
}