package nsi.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class GeneratePublicKey {

    private static final String PUBLIC_KEY = "\\src\\test\\resources\\pt1\\templates\\public_key.txt";

    /**
     * Change public key to RSAPublicKey type
     */
    public static RSAPublicKey generatePublicKey() throws IOException, GeneralSecurityException {
        String rootPath = System.getProperty("user.dir");
        String key = new String(Files.readAllBytes(Paths.get(rootPath + PUBLIC_KEY)))
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PUBLIC KEY-----", "");
        byte[] encodedKey = Base64.getDecoder().decode(key);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encodedKey);
        return (RSAPublicKey) keyFactory.generatePublic(keySpec);
    }
}
