package nsi.steps;

import com.google.gson.Gson;
import com.nimbusds.jose.JOSEException;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.filter.Filter;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import nsi.AuthenticationUtils.DBEPTokenFactory;
import nsi.AuthenticationUtils.DBEPUserRegistrar;
import nsi.configuration.EndPoints;
import nsi.configuration.HeadersType;
import nsi.utils.AssertMessages;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import static environment.EnvironmentFactory.getEnvironment;
import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j
public class BaseSteps {
    private final Map<String, String> requestHeaders = new HashMap<>();
    private HashMap<String, String> requestBody;
    private Filter logFilter;
    private Scenario scenario;
    private StringBuilder requestBuilderLogs;
    private StringBuilder responseBuilderLogs;
    public RequestSpecification requestSpecification;
    public ExtractableResponse<Response> response;
    public String authToken, accountId, dbTechnicalId, taxDetailsId, addressId, emailAddressId, callRefId, customerId;

    @Given("Generate access token for uci {string}")
    public void generate_access_token_for_uci(String uci) throws ParseException, JOSEException, IOException {
        authToken = new DBEPTokenFactory("10.18.2.19", 8080).getDBEPToken(uci);
        RestAssured.reset();
        System.out.println("accessToken: " + authToken);
    }

    @Given("Register UCI {string} with surname {string}")
    public void registerUCI(String uci, String surname) {
        new DBEPUserRegistrar("10.18.2.19", 8080).register(uci, surname, System.getenv("userPass"));
        RestAssured.reset();
    }

    /**
     * Saves headers located in property file to a HashMap
     *
     * @param file a file located in headers package
     */
    @Given("Set scenario headers from {string}")
    public void setScenarioHeadersFromFile(String file) throws IOException {
        Properties properties = new Properties();
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(file)) {
            properties.load(inputStream);
        }
        properties.forEach((key, value) -> requestHeaders.put((String) key, (String) value));
    }

    /**
     * checks response status code received with expected
     */

    @Then("Validate that response status code is {int}")
    public void validateStatusCode(int expectedStatusCode) {
        assertEquals(expectedStatusCode, response.statusCode());
    }

    /**
     * checks error code and error desc
     */

    @And("I validate the error {string} and {string}")
    public void validateErrorCodeAndDescription(String errorCode, String errorDescription) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(errorCode, response.body().path("errorCode")),
                () -> assertEquals(errorDescription, response.body().path("errorDescription"))
        );
    }

    @And("I validate response body contains description {string}")
    public void validateResponseBodyDescription(String description) {
        assertEquals(description, response.body().path("description"));
    }

    /**
     * Setting headers and base URL to requestSpecification variable
     *
     * @param headerProperties a file located in headers package
     */
    @Given("Set base request with headers {string}")
    public void setBaseRequest(String headerProperties) throws IOException {
        setScenarioHeadersFromFile(HeadersType.valueOf(headerProperties).getHeaders());

        requestSpecification = given().log().all()
                .headers(getRequestHeaders())
                .baseUri(getEnvironment().getBaseUrlPT1());
    }

    @Given("Set base request with plain headers {string}")
    public void setBaseRequestPlainHeaders(String headerProperties) throws IOException {
        setScenarioHeadersFromFile(HeadersType.valueOf(headerProperties).getHeaders());
        requestHeaders.forEach((key, value) -> {
            if (value.equals("__UUID")) {
                requestHeaders.put(key, UUID.randomUUID().toString());
            }
        });
        requestSpecification = given().log().all()
                .headers(requestHeaders)
                .baseUri(getEnvironment().getBaseUrlPT1());
    }

    @Given("Set base request for delete user pin")
    public void deleteUserPin() throws IOException {
        setScenarioHeadersFromFile(HeadersType.valueOf("DELETEPINHEADERS").getHeaders());

        requestSpecification = given().log().all()
                .proxy("10.18.2.19", 8080)
                .baseUri(getEnvironment().getEaccUrl());
    }

    @Given("Set base request for DBEP service endpoints")
    public void setDBEPServiceBaseRequest() throws IOException {
        setScenarioHeadersFromFile(HeadersType.valueOf("DBEPTHIRDPARTYHEADERS").getHeaders());

        requestSpecification = given().log().all()
                .proxy("10.18.2.19", 8080)
//                Not sure what is the base url yet. for now leaving it as below.
                .baseUri(getEnvironment().getEaccUrl());
    }

    @Given("Set base request and pass accountId from another uci")
    public void setBaseRequestAndAccountId() throws IOException {
        if (accountId == null) {
            accountId = response.body().path("accounts.accountId[0]");
        }
        setScenarioHeadersFromFile(HeadersType.valueOf("BASEHEADERS").getHeaders());
        requestSpecification = given().log().all()
                .headers(getRequestHeaders())
                .baseUri(getEnvironment().getBaseUrlPT1())
                .filter((requestSpec, responseSpec, ctx) -> {
                    requestSpec.pathParam("accountId", accountId);
                    return ctx.next(requestSpec, responseSpec);
                });
    }

    @Given("Replace path param {string} to {string}")
    public void setPathParamWithValue(String param, String value) {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam(param, value);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Replace header {string} with value {string}")
    public void replaceHeaderWithValue(String header, String value) {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.replaceHeader(header, value);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    public void setBaseRequestForAuthToken() throws IOException {
        setScenarioHeadersFromFile(HeadersType.valueOf("AUTHTOKEN").getHeaders());
        requestSpecification = given().log().all()
                .headers(requestHeaders)
                .proxy(EndPoints.valueOf("PROXY").getEndpoint())
                .body(getPayload("authToken.json"));
    }

    protected Map<String, String> getRequestHeaders() {
        requestHeaders.forEach((key, value) -> {
            if (value.equals("__UUID")) {
                requestHeaders.put(key, UUID.randomUUID().toString());
            }
        });
        requestHeaders.put("Authorization", "Bearer " + authToken);
        return requestHeaders;
    }

    /**
     * Running selected request on selected endpoint and write logs
     *
     * @param requestMethod selected request method
     * @param endpoint      selected endpoint
     */
    @When("Call {string} on the service for {string} endpoint")
    public void retrieveStandardEndpoint(String requestMethod, String endpoint) {
        String finalEndpoint = EndPoints.valueOf(endpoint).getEndpoint();
        chooseRequestMethod(requestMethod, finalEndpoint);
    }

    /**
     * Running selected request on selected endpoint without {accountId} path param and write logs
     *
     * @param requestMethod selected request method
     * @param endpoint      selected endpoint
     */
    @When("Call {string} on the service for {string} endpoint with missing {string} path param")
    public void retrieveMissingAccoundIdEndpoint(String requestMethod, String endpoint, String pathParam) {
        String finalEndpoint = EndPoints.valueOf(endpoint).getEndpoint().replace("{" + pathParam + "}", "");
        chooseRequestMethod(requestMethod, finalEndpoint);
    }

    public void chooseRequestMethod(String requestMethod, String endpoint) {
        switch (requestMethod) {
            case "GET":
                getService(endpoint);
                break;
            case "POST":
                postService(endpoint);
                break;
            case "PUT":
                putService(endpoint);
                break;
            case "DELETE":
                deleteService(endpoint);
                break;
        }
    }

    public void getService(String endpoint) {
        response = requestSpecification
                .when()
                .filter(logFilter)
                .get(endpoint)
                .then()
                .extract();
        writeLogsToCucumberReport();
    }

    public void postService(String endpoint) {
        response = requestSpecification
                .when()
                .filter(logFilter)
                .post(endpoint)
                .then()
                .extract();
        writeLogsToCucumberReport();
    }

    public void putService(String endpoint) {
        response = requestSpecification
                .when()
                .log().all()
                .filter(logFilter)
                .put(endpoint)
                .then()
                .extract();
        writeLogsToCucumberReport();
    }

    public void deleteService(String endpoint) {
        response = requestSpecification
                .when()
                .log().all()
                .filter(logFilter)
                .delete(endpoint)
                .then()
                .extract();
        writeLogsToCucumberReport();
    }

    @But("Header {string} is not passed")
    public void headerIsNotPassed(String header) {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.removeHeader(header);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("I want to retrieve accountId from service")
    public void getAccountId() throws IOException {
        accountId = response.body().path("accounts.accountId[0]");
        setBaseRequest("BASEHEADERS");
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("I want to retrieve {string} Id from service")
    public void retrieveIdFromThirdPartyService(String requiredId) {
//        Not sure of the exact body path. Leaving it as below for now.
        switch (requiredId) {
            case "TAXDETIALS":
                taxDetailsId = response.body().path("");
                break;
            case "ADDRESSID":
                addressId = response.body().path("");
                break;
            case "EMAILADDRESSID":
                emailAddressId = response.body().path("");
                break;
            case "CALLREFERENCEID":
                callRefId = response.body().path("");
                break;
            case "CUSTOMERID":
                customerId = response.body().path("");
        }
    }

    @Given("I want to retrieve premiumBondId from service")
    public void getPremiumBondId() throws IOException {
        accountId = response.path("accounts.find { it.bankProductCommercialWording == '%s' }.accountId", "Premium Bonds");
        setBaseRequest("BASEHEADERS");
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("premiumBondId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("I want to retrieve accountId for {string} product")
    public void getProductAccountId(String productName) throws IOException {
        accountId = response.path("accounts.find { it.bankProductCommercialWording == '%s' }.accountId", productName);
        log.info("Selected accountId: " + accountId);
        setBaseRequest("BASEHEADERS");
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("I want to set pathParam {string} to retrieved Id")
    public void setTaxDetailsIdPathParam(String requiredId) throws IOException {
        setBaseRequest("BASEHEADERS");
        switch (requiredId) {
            case "TAXDETAILSID":
                setPathParamWithValue("taxDetailsId", taxDetailsId);
                break;
            case "ADDRESSID":
                setPathParamWithValue("addressId", addressId);
                break;
            case "EMAILADDRESSID":
                setPathParamWithValue("emailAddressId", emailAddressId);
                break;
        }
    }

    @Given("I want to change path param {string} to {string}")
    public void changePathParam(String pathParam, String changeValue) {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam(pathParam, changeValue);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Set account type {string}")
    public void setAccountType(String accountType) {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.queryParam("accountType", accountType);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("I want to retrieve transactionId from service")
    public void getTransactionId() throws IOException {
        dbTechnicalId = response.body().path("accountTransactions[0].dbTechnicalId");
        setBaseRequest("BASEHEADERS");
    }

    @Given("Set accountId and dbTechnicalId as path params")
    public void setAccountIdAndDbTechnicalId() {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId).pathParam("dbTechnicalId", dbTechnicalId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Given("Set request body template {string}")
    public void setRequestBody(String templateName) throws IOException {
        requestSpecification.body(getPayload(templateName));
    }

    @And("Update request body template with {string} as {string}")
    public void updateRequestBodyValue(String bodyparam, String value) throws IOException {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.getBody();
            return ctx.next(requestSpec, responseSpec);
        });
        replaceBodyFieldValue(bodyparam, value);
    }

    @And("Remove request body template parameter {string}")
    public void removeRequestBodyParameter(String bodyparam) throws IOException {
        requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.getBody();
            return ctx.next(requestSpec, responseSpec);
        });
        removeBodyField(bodyparam);
    }

    public void replaceBodyFieldValue(String fieldName, Object value) {
        requestSpecification = requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            String payLoad = requestSpec.getBody().toString();
            Gson gson = new Gson();
            Map mappedPayLoad = gson.fromJson(payLoad, Map.class);
            mappedPayLoad.put(fieldName, value);
            requestSpec.body(mappedPayLoad);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    public void removeBodyField(String fieldName) {
        requestSpecification = requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            String payload = requestSpec.getBody().toString();
            Gson gson = new Gson();
            Map mappedPayload = gson.fromJson(payload, Map.class);
            mappedPayload.remove(fieldName);
            requestSpec.body(mappedPayload);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    public HashMap<String, String> getPayload(String fileName) throws IOException {
        String rootPath = System.getProperty("user.dir");
        Path filePath = Paths.get(getPathToPayload() + fileName);
        Reader reader = Files.newBufferedReader(Paths.get(rootPath + filePath));
        Gson gson = new Gson();
        requestBody = gson.fromJson(reader, HashMap.class);
        return requestBody;
    }

    @Before(order = 3)
    public void before(Scenario scenario) {
        this.scenario = scenario;
        logFilter = ((requestSpec, responseSpec, ctx) -> {
            Response response = ctx.next(requestSpec, responseSpec);
            requestBuilderLogs = new StringBuilder();
            requestBuilderLogs.append("\nRequest method: " + requestSpec.getMethod() + "\n");
            requestBuilderLogs.append("Request URI: " + requestSpec.getURI() + "\n");
            requestBuilderLogs.append("Form Params: " + requestSpec.getFormParams() + "\n");
            requestBuilderLogs.append("Request Params: " + requestSpec.getRequestParams() + "\n");
            requestBuilderLogs.append("Headers: " + requestSpec.getHeaders() + "\n");
            requestBuilderLogs.append("Cookies: " + requestSpec.getCookies() + "\n");
            requestBuilderLogs.append("Proxy: " + requestSpec.getProxySpecification() + "\n");
            requestBuilderLogs.append("Body: " + requestSpec.getBody() + "\n");
            requestBuilderLogs.append("*************************************************************");
            responseBuilderLogs = new StringBuilder();
            responseBuilderLogs.append("\nStatus Code: " + response.getStatusCode() + "\n");
            responseBuilderLogs.append("Status Line: " + response.getStatusLine() + "\n");
            responseBuilderLogs.append("Response Cookies: " + response.getDetailedCookies() + "\n");
            responseBuilderLogs.append("Response Content Type: " + response.getContentType() + "\n");
            responseBuilderLogs.append("Response Headers " + response.getHeaders() + "\n");
            responseBuilderLogs.append("Response Body: " + "\n" + response.getBody().prettyPrint() + "\n");
            return response;
        });
    }

    protected void writeLogsToCucumberReport() {
        scenario.write("\n" + "API Request:" + requestBuilderLogs
                + "\n" + "API Response:" + responseBuilderLogs);
    }

    private String getPathToPayload() {
        String[] splittedScenarioId = scenario.getId().split("/");
        String ptNumber = splittedScenarioId[splittedScenarioId.length - 1].substring(0, 3).toLowerCase();
        return "\\src\\test\\resources\\" + ptNumber + "\\templates\\";
    }
}
