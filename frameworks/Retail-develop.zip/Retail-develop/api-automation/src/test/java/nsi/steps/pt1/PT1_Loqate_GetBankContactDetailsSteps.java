package nsi.steps.pt1;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j
public class PT1_Loqate_GetBankContactDetailsSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want to set path param with sortCode {string}")
    public void updatePathParamWithTransactionId(String sortcode) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("sortCode", sortcode);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @Then("Response contain bank {string} and branch {string}")
    public void responseContainsBankAndBranch(String bank, String branch) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(bank, baseSteps.response.body().path("bank")),
                () -> assertEquals(branch, baseSteps.response.body().path("branch"))
        );
    }
}
