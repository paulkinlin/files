#!/bin/bash
#CURL_PARAMS_1=$1
CURL_PARAMS_1="--proxy 10.18.9.40:8080"
echo "==>###Init variables"
# Configuration
SCOPE="openid"
RESPONSE_TYPE="code"
GRANT_TYPE="authorization_code"

# Security
STATE="RD_hiDm5Bb7_FKNxz5nDWKmhBp4bzCIVobmY9xnRLXA.0TkHV4wZixU.B2C-IPE"
NONCE="LeF3gLZKu8ySzD6yaqQp-g"
CODE_VERIFIER="YLWZNfrThK8WyupeBiP6S.s64k9HCJYTOlkXNeNN-7uXE9Uv4Gc7yO1xSxMiIs9TT.TwddK9QHTvehRJ1871zTxVzq_dxJII0EYl4Vpjv6G6beMTcX6nHBHEuQ3QD7~e"
WL_AUTHORIZATION_TOKEN="eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..SKqYJRERJENA6YmK6ip5WA.HoEEBckmWwqW0c59Stq17zR86w-5JDXgLDJq47Rul6lqlLR8N16gFMYCT2zAt2Wf2-QvZiOoCjl6mDJmX69C_CgSQ8n1K6AHkX2KLqP5E1FXiBVYWRuikfzxwa9S0a8pUZP8l6zdThIoyjn8eOJgPiOsz7Lz2bCyO7CtGh7ODxsvLFksSAOWNtbnGDxMmUpBnrysF0d6dvA8jLisZ3LEw4fWCbkpqAVkN4ytr40sc_15cvZ1Nt3tk27gB_xdqO11HGuJ7HvH3jEnntZdTHpPoOaAYJTTVL4WlaASvriPC-M8GZ4qRIZumx9ohxzWVDlSsJSfOev1smzWFDE9V1ltsChMTWs2MFuXqonKY91LBAARqrSiH0AFBX8DqPLmkudU4M2IqHODojOGzA7VMxMTN2YY6bI0ryzS1-ljCTuw4NLg1CSj1YEMB6h93dutnIACDgQAEcbC9mSmA8j99egkSRG-mh9pQzWzGcxFK3kyjU5gCVVkhEJ_11eDL2R03wokp-wNE4_QCD5LVnbvZcB4JDlWhN2YeJ4cOhQP0gWrJAMf2QcWBKA-qR9col8zp7eixq3zUiesWMaXCsY7fgWnA902mcRtvdKXJIm6rwy6b3MEhfLWqwWvPwZDdWe2rX8xm4ILeYY0pu78Eq4B2S-gvluXnNQV04v_QE-PFjD8z7LufbJq5ECXyI5QpYuBoO9SoUZgqzfSnFGsYAcRj3etd7DJnpM5EmBab32f2Np-8MLRVBjt7-QSeYnpQNU9Q5vmm8bQjLHEKndP9LXfI1x07JTFjjrCLwmxOxkppickA98FUehqoU-reS6xGjV_JiGJlESzC1m2ePnat_Eek3jdSNmrIKLUS9Pwa4QwVrg2pevgM9bkILcpcp_ehIqgr8N-oP4lyOg6mfCWx51Wdl8_X9seJi6BjjcxfrJrdAeCmQLznDi-NDwvHsX6y5lmZYxA5T0HhTr0V3d9p_VkjBbSskmT403SynU2qv9t2Ix8nMi2foy3hpsumKvB-JZuMlkpkAQ98jJzRKG_4rRYuw9ZEb5BAbIQX9Epidd_4W5bPIj5FVqlg-pzVIQKBPgkTE8ioyDvpD09pjAjcBscAREgXgRUXtET1k2S2BbnSJmBkX9gQeTFi7PImdiju-IEIo8WfHHSaN_UiNOIoU3g3hhNEgPuZT_tLSZTdDUlANuYaDek4YzJYfnBIoZQyfojwzCR4LNDbczQkx6zPb5vTuHr-Qhz7POyvhRDSJoQ7CVQOf0rPFhPNNu_pM1Qy_ckYVDIxDwyJTByC_n6h2oQfCLo43pma1BvSHahSUo8WRipnUjFKYYAyc8ehNcAQvysLW3geK94KL9UMREHKSbAnDkfc1zQvE12GXlXY9g2Qyr4WTZknsSun8JuB2Y3E3I0yQEAWixBh-B09hYrIpiXEZ9EWLFUG7u0hXfUBaKfhZMGe6JzMQIBybJpwZWl5e14GTz3i67UCLRV35fTEPiTJ18BcrTRXu5JzP0YdxeOjkrpWlpxDSBFeGp1Ed9hpAnPinPEy6CpR4jQxyXO4vUE5HLxPQ65WMHPTehfwEEKBAGzecw.ScbIjrpYXTWuYh82D7Cb0w"

KEY_ID="9ddaa96c-f5e9-41e7-97f1-800a40c53660"

# Client
CLIENT_ID="B2C-IPE"
CLIENT_SECRET="7fc60de5-8ecd-4727-b05d-96ca514b5b27"

REQUEST_PT1=$1

echo "==>###Get code"
curl -c cookiejar -L "https://eacc-nsi-idp.worldline-solutions.com/auth/realms/NsiIdp/protocol/openid-connect/auth?scope=${SCOPE}&request=${REQUEST_PT1}&response_type=${RESPONSE_TYPE}&client_id=${CLIENT_ID}" $CURL_PARAMS_1 > pin.html

for i in 1 2 3 4 5 6
do
        pin="$pin $(cat pin.html | grep ">$i<" | sed "s/.*'\([0-9]\)'.*/\1/")"
done

gen_pin=$(echo $pin | sed 's/ //g')
echo "==>Entered pin: $gen_pin"

curl --trace code.txt --cookie cookiejar -c cookiejar -L 'https://eacc-nsi-idp.worldline-solutions.com/api/pin' \
        -H "Referer: https://eacc-nsi-idp.worldline-solutions.com/api/pin;jsessionid=$(cat cookiejar | grep JSESSIONID | sed 's/.*JSESSIONID[[:blank:]]//')" \
        -H "Origin: https://eacc-nsi-idp.worldline-solutions.com" \
        --data "pin=$gen_pin" \
        --data "rsaDevicePrint=version=3.5.1_4&pm_fpua=mozilla/5.0 (windows nt 6.1) applewebkit/537.36 (khtml, like gecko) chrome/27.0.1453.116 safari/537.36|5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36|Win32&pm_fpsc=32|1440|900|860&pm_fpsw=|pdf&pm_fptz=0&pm_fpln=lang=en-GB|syslang=|userlang=&pm_fpjv=1&pm_fpco=1&pm_fpasw=pepflashplayer|internal-remoting-viewer|ppgooglenaclpluginchrome|pdf|nppdf32|npauthz|npspwrap|npican|npgoogleupdate3|npjp2|npswf32_11_6_602_171|npdeployjava1&pm_fpan=Netscape&pm_fpacn=Mozilla&pm_fpol=true&pm_fposp=&pm_fpup=&pm_fpsaw=1440&pm_fpspd=32&pm_fpsbd=&pm_fpsdx=&pm_fpsdy=&pm_fpslx=&pm_fpsly=&pm_fpsfse=&pm_fpsui=&pm_os=Windows&pm_brmjv=27&pm_br=Chrome&pm_inpt=&pm_expt=" \
        ${CURL_PARAMS_1} > /dev/null

code=$(cat code.txt | grep state=state | grep code | sed 's/.*code=//' | sed "s/'//")
echo "==>Retrived code: $code"
echo "==>###Retrive WL token"
access_token=$(curl --cookie cookiejar --location --request POST 'https://eacc-nsi-idp.worldline-solutions.com/auth/realms/NsiIdp/protocol/openid-connect/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--header "Authorization: Bearer ${WL_AUTHORIZATION_TOKEN}" \
--data-urlencode "grant_type=${GRANT_TYPE}" \
--data-urlencode "client_id=${CLIENT_ID}" \
--data-urlencode "client_secret=${CLIENT_SECRET}" \
--data-urlencode 'redirect_uri=https://www.nsandi.com' \
--data-urlencode "code=$code" \
--data-urlencode "state=${STATE}" \
--data-urlencode "nonce=${NONCE}" \
--data-urlencode "code_verifier=${CODE_VERIFIER}" \
$CURL_PARAMS_1 | python -c 'import sys, json; print(json.load(sys.stdin)["access_token"])')

echo "==>Access WL token: $access_token"

echo "###Get DBEP Token"
access_dbeb_token=$(curl --location --request POST "https://api.nsiuat.dxp.delivery/core/authentication/api/v1/token?KeyId=${KEY_ID}" \
--header "apiKey: ${KEY_ID}" \
--header "KeyId: ${KEY_ID}" \
--header 'Authorization: Basic bW9iaWxlX2F1dGg6bW9iaWxlX2F1dGhfcGFzc3dvcmQ=' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--header 'Expect:' \
--header 'Accept: */*' \
--header 'Connection: keep-alive' \
--header 'Host: api.nsiuat.dxp.delivery' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode 'scope=' \
--data-urlencode 'token_type=END_USER_FROM_TENANT' \
--data-urlencode 'external_token_type=nsi_customer_authentication' \
--data-urlencode "external_token=${access_token}" \
$CURL_PARAMS_1 | python -c 'import sys, json; print(json.load(sys.stdin)["access_token"])')

echo $access_dbeb_token > token.txt

echo "==>Access DBEB token: $access_dbeb_token"
rm pin.html
rm code.txt
rm cookiejar

