package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.junit.Assert;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

import static utils.DateUtils.getFakeBusinessDateForApiRequest;
import static utils.DateUtils.getBusinessDateForApiRequest;

@Slf4j
public class PT1_1_11_InitiateWithdrawalSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("I want to initiate withdrawal for amount {floatOrNull} with nominated account {string}, roll number {string}, customer name {string}, account type {string}")
    public void setRequestBodyForUpdatePrizePreferences(Object amountValue, String accountId,
                                                        String rollNumber, String customerName,
                                                        String accountType) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("initiateWithdrawal.json"));

        baseSteps.replaceBodyFieldValue("amountValue", amountValue);
        baseSteps.replaceBodyFieldValue("nominatedAccountId", accountId);
        baseSteps.replaceBodyFieldValue("nominatedCustomerName", customerName);
        baseSteps.replaceBodyFieldValue("nominatedAccountType", accountType);
        baseSteps.replaceBodyFieldValue("nominatedRollNumber", rollNumber);
        baseSteps.replaceBodyFieldValue("withdrawalDate", getBusinessDateForApiRequest());
    }

    @And("I validate the initiate withdrawal transactionId")
    public void validateInitiateWithdrawalTransactionId() {
        Assert.assertNotNull(baseSteps.response.body().path("transactionId"));
    }

    @Given("I want to initiate withdrawal for amount {floatOrNull} with nominated account {string}, roll number {string}, customer name {string}, account type {string} and fake withdrawalDate")
    public void i_want_to_initiate_withdrawal_for_amount_with_nominated_account_roll_number_customer_name_account_type_and_fake_withdrawalDate(Object amountValue, String accountId,
                                                                                                                                               String rollNumber, String customerName,
                                                                                                                                               String accountType) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("initiateWithdrawal.json"));

        baseSteps.replaceBodyFieldValue("amountValue", amountValue);
        baseSteps.replaceBodyFieldValue("nominatedAccountId", accountId);
        baseSteps.replaceBodyFieldValue("nominatedCustomerName", customerName);
        baseSteps.replaceBodyFieldValue("nominatedAccountType", accountType);
        baseSteps.replaceBodyFieldValue("nominatedRollNumber", rollNumber);
        baseSteps.replaceBodyFieldValue("withdrawalDate", getFakeBusinessDateForApiRequest());
    }
}