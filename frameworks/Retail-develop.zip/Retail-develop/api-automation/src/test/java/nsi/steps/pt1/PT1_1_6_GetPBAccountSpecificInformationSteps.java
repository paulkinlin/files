package nsi.steps.pt1;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_6_GetPBAccountSpecificInformationSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Response contains bondNumberRange {string} and bondRangeValue {string} and eligibilityDate {string}")
    public void validateBondNumberRangeAndBondRangeValue(String bondNumberRange, String bondRangeValue, String eligibilityDate) {
            assertAll("Response does not contains ",
                    () -> assertEquals(bondNumberRange, baseSteps.response.body().path("bondRecordDetails[0].bondRange")),
                    () -> assertEquals(bondRangeValue, baseSteps.response.body().path("bondRecordDetails[0].bondRangeValue")),
                    () -> assertEquals(eligibilityDate,baseSteps.response.body().path("bondRecordDetails[0].eligibilityDate"))
            );
        }
}
