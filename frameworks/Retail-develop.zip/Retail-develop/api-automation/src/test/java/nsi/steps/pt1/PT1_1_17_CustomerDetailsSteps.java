package nsi.steps.pt1;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_17_CustomerDetailsSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Response contains client title {string}, first name {string} and last name {string}")
    public void validateCustomerDetailsTitleResponse(String title, String firstName, String lastName) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(title, baseSteps.response.body().path("clientTitle")),
                () -> assertEquals(firstName, baseSteps.response.body().path("clientFirstName")),
                () -> assertEquals(lastName, baseSteps.response.body().path("clientLastName"))
        );
    }
}