package nsi.utils;

import io.cucumber.java.ParameterType;

public class ParameterTypes {

    @ParameterType(value = "true|TRUE|True|false|FALSE|False|null")
    public Boolean booleanValue(String value) {
        return value.equals("null") ? null : Boolean.valueOf(value);
    }

    @ParameterType(value = "true|false|abc|^$")
    public <V> V booleanOrString(String value) {
        if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
            return (V) Boolean.valueOf(value);
        }
        return (V) value;
    }

    @ParameterType(value = "\\d+|\\d+\\.\\d*|null")
    public Float floatOrNull(String value) {
        return value.equals("null") ? null : Float.parseFloat(value);
    }

    @ParameterType(value = "\\d+|\\d+\\.\\d*|")
    public Number amountValue(String value) {
        if (value.isEmpty()) {
            return null;
        } else if (value.contains(".")) {
            return Double.parseDouble(value);
        } else {
            return Integer.parseInt(value);
        }
    }
}
