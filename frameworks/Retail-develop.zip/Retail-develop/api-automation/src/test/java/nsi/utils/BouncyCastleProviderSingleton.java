package nsi.utils;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.security.Provider;

public class BouncyCastleProviderSingleton {

    private static BouncyCastleProvider bouncyCastleProvider;

    private BouncyCastleProviderSingleton(){

    }

    public static Provider getInstance(){
        if(bouncyCastleProvider != null) {
            return bouncyCastleProvider;
        } else {
            bouncyCastleProvider = new BouncyCastleProvider();
            return bouncyCastleProvider;
        }
    }

}
