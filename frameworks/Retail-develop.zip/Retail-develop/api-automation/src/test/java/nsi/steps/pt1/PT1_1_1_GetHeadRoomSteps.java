package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_1_GetHeadRoomSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want current headroom for a customer account {string}")
    public void headRoomForCustomer(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("I validate getHeadRoom currency is {string} and headroom is {string}")
    public void validateGetHeadRoomCurrencyAndHeadRoom(String currency, String headRoom) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(currency, baseSteps.response.body().path("currency")),
                () -> assertEquals(headRoom, baseSteps.response.body().path("currentHeadroom").toString())
        );
    }
}