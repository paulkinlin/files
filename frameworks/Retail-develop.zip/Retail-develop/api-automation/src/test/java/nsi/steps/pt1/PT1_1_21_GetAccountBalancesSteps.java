package nsi.steps.pt1;

import io.cucumber.java.en.And;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;


import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PT1_1_21_GetAccountBalancesSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Response contains current balance {int}, current currency {string}, current sign {string}, available balance {int}, available currency {string}, available sign {string}")
    public void validateAccountBalancesResponse(Integer currentBalance, String currentCurrency,
                                                String currentSign, Integer availableBalance,
                                                String availableCurrency, String availableSign) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(currentBalance, baseSteps.response.body().path("currentBalance")),
                () -> assertEquals(currentCurrency, baseSteps.response.body().path("currentBalanceCurrency")),
                () -> assertEquals(currentSign, baseSteps.response.body().path("currentBalanceMovementSign")),
                () -> assertEquals(availableBalance, baseSteps.response.body().path("availableBalance")),
                () -> assertEquals(availableCurrency, baseSteps.response.body().path("availableBalanceCurrency")),
                () -> assertEquals(availableSign, baseSteps.response.body().path("availableBalanceMovementSign")),
                () -> assertEquals(currentBalance, baseSteps.response.body().path("currentBalance"))
        );
    }
}