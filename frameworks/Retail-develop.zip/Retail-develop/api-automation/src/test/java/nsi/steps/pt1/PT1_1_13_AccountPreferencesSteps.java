package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_13_AccountPreferencesSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want account preferences for account id {string}")
    public void accountPrefForAccountId(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Response contains paperless {booleanValue} and text {booleanValue}")
    public void validateCustomerDetailsTitleResponse(Boolean paperless, Boolean text) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(paperless, baseSteps.response.body().path("paperlessNotification")),
                () -> assertEquals(text, baseSteps.response.body().path("textNotification"))
        );
    }
}