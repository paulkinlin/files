package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_20_GetPortfolioBalancesSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want to retrieve accountId for {string} for GetPortfolioBalances")
    public void getProductAccountId(String productName) {
        baseSteps.accountId = baseSteps.response.path("accounts.find { it.bankProductCommercialWording == '%s' }.accountId", productName);
        log.info("Selected accountId: " + baseSteps.accountId);
    }

    @And("Response contains current balance {int}, current currency {string}, current sign {string}, account type {string}, available balance {int}, available currency {string}, available sign {string}")
    public void validatePortfolioBalancesResponse(int currentBalance,
                                                  String currentCurrency, String currentSign,
                                                  String accountType, int availableBalance,
                                                  String availableCurrency, String availableSign) {
        List<Map<Object, Object>> listOfMapsWithBalances = new ArrayList<>(baseSteps.response.body().path("balances"));
        listOfMapsWithBalances.forEach(map -> {
            if (map.get("accountId").equals(baseSteps.accountId)) {
                assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                        () -> assertEquals(currentBalance, map.get("currentBalance")),
                        () -> assertEquals(currentCurrency, map.get("currentBalanceCurrency")),
                        () -> assertEquals(currentSign, map.get("currentBalanceMovementSign")),
                        () -> assertEquals(accountType, map.get("accountType")),
                        () -> assertEquals(availableBalance, map.get("availableBalance")),
                        () -> assertEquals(availableCurrency, map.get("availableBalanceCurrency")),
                        () -> assertEquals(availableSign, map.get("availableBalanceMovementSign"))
                );
            }
        });
    }
}