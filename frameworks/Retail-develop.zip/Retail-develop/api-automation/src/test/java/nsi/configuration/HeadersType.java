package nsi.configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum HeadersType {

    //--------------- COMMON HEADERS ---------------
    BASEHEADERS("common/headers/headersList.properties"),
    EXPIREDTOKEN("common/headers/expiredToken.properties"),

    //--------------- PT1 HEADERS ------------------
    AUTHTOKEN("pt1/headers/PT1-0.0-GetAuthToken.properties"),
    LOQATEHEADERS("pt1/headers/loqateHeadersList.properties"),
    DELETEPINHEADERS("pt1/headers/deletePinHeadersList.properties"),
    SMSHEADERS("pt1/headers/smsHeadersList.properties"),

    //--------------- PT2 HEADERS ------------------
    EMPTYAUTHTOKENFIELD("pt2/headers/emptyAuthorizationFieldProperty.properties");

    private final String headers;
}
