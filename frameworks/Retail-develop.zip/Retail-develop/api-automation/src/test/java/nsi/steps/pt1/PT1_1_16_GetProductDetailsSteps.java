package nsi.steps.pt1;

import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.junit.Assert;
import org.picocontainer.annotations.Inject;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_16_GetProductDetailsSteps {

    @Inject
    private BaseSteps baseSteps;

    @Then("Response contains product name {string}, interest rate {floatOrNull} and account number {string}")
    public void validateResponseProductNameInterestRateAccountNumber(String productName, Object interestRate,
                                                                     String nationalAccountNumber) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(productName, baseSteps.response.body().path("bankProductCommercialWording")),
                () -> assertEquals(nationalAccountNumber, baseSteps.response.body().path("nationalAccountNumber"))
        );
        if (interestRate == null) {
            Assert.assertNull(baseSteps.response.body().path("interestRate"));
        } else {
            Assert.assertEquals(interestRate, baseSteps.response.body().path("interestRate"));
        }
    }
}