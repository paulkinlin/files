package nsi.steps.pt2;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

@Slf4j
public class PT2_7_SetCallContextSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body with retrieved callRef and update UCI as {string} callStatus as {string} actionCode as {string}")
    public void setRequestBodyWithCallRefUCICallStatusActionCode(String UCI, String callStatus, String actionCode) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("setCallContext.json"));
        baseSteps.replaceBodyFieldValue("UCI", baseSteps.callRefId);
        baseSteps.replaceBodyFieldValue("accessToken", baseSteps.authToken);
        baseSteps.replaceBodyFieldValue("UCI", UCI);
        baseSteps.replaceBodyFieldValue("callStatus", callStatus);
        baseSteps.replaceBodyFieldValue("actionCode", actionCode);
    }
}
