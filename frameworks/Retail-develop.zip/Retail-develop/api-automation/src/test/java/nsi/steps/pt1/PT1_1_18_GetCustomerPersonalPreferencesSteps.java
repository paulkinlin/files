package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nsi.steps.BaseSteps;
import org.junit.Assert;
import org.picocontainer.annotations.Inject;

public class PT1_1_18_GetCustomerPersonalPreferencesSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want customer personal preferences with preference key {string}")
    public void customerPersonalPreferencesKey(String preferenceKey) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("preferenceKey", preferenceKey);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Response personal preference value is {string}")
    public void validatePersonalPreferencesValue(String personalPreferencesValue) {
        Assert.assertEquals(personalPreferencesValue, baseSteps.response.body().path("preferenceValue"));
    }
}
