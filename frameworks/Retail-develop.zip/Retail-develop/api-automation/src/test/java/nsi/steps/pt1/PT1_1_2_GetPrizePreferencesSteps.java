package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@Slf4j
public class PT1_1_2_GetPrizePreferencesSteps {
    String productId;
    @Inject
    private BaseSteps baseSteps;

    @And("I validate getPrizePreferences response contains {booleanValue} {string} and {string}")
    public void validatePrizePreferencesResponse(Boolean reinvest, String payment, String notification) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(reinvest, baseSteps.response.body().path("prizeReinvestmentSwitch")),
                () -> assertEquals(payment, baseSteps.response.body().path("prizePaymentOption")),
                () -> assertEquals(notification, baseSteps.response.body().path("prizeNotificationOption"))
        );
    }

    @Given("I want prize preferences for a customer account {string}")
    public void prizePrefsForCustomer(String productName) throws IOException {
        productId = baseSteps.response.path("accounts.find { it.bankProductCommercialWording == '%s' }.accountId", productName);
        baseSteps.setBaseRequest("BASEHEADERS");
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("premiumBondId", productId);
            return ctx.next(requestSpec, responseSpec);
        });
    }
}