package nsi.steps.pt2;

import io.cucumber.java.en.And;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;
import java.io.IOException;

import static utils.StringUtils.generateTextWhenParamEqualsString;

public class PT2_1_10a_UpdateResidentialAddressSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body parameters with ResidentialAddress as {string} {string} {string} {string} {string} {string} {string}")
    public void set_request_body_parameters_with_ResidentialAddress_as_countryCode_postCode(String addressLine1, String townName, String countryCode, String postCode, String addressLine2, String addressLine3, String addressLine4) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("residentialAddress.json"));
        baseSteps.replaceBodyFieldValue("addressLine1", generateTextWhenParamEqualsString(addressLine1, 201));
        baseSteps.replaceBodyFieldValue("townName", generateTextWhenParamEqualsString(townName, 201));
        baseSteps.replaceBodyFieldValue("countryCode", generateTextWhenParamEqualsString(countryCode, 201));
        baseSteps.replaceBodyFieldValue("postCode", generateTextWhenParamEqualsString(postCode, 201));
        baseSteps.replaceBodyFieldValue("addressLine2", generateTextWhenParamEqualsString(addressLine2, 201));
        baseSteps.replaceBodyFieldValue("addressLine3", generateTextWhenParamEqualsString(addressLine3, 201));
        baseSteps.replaceBodyFieldValue("addressLine4", generateTextWhenParamEqualsString(addressLine4, 201));
    }
}
