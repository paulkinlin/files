package nsi.AuthenticationUtils;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.jwk.RSAKey;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.AbstractHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static io.restassured.RestAssured.given;
import static io.restassured.config.HttpClientConfig.httpClientConfig;
import static java.util.stream.Collectors.toMap;

@Slf4j
public abstract class BaseWLConnector {

    private static final String SCOPE_OPENID = "openid";
    private static final String RESPONSE_TYPE_CODE = "code";
    private static final String CLIENT_ID = "B2C-IPE";
    private static final String PIN_CODE_CHALLENGE = "iM7pN3-W6yEeqDY3w6h4ZQICoP_fUxaH4qel-scuKxM";
    private static final String NSANDI_ADDRESS = "https://www.nsandi.com";
    private static final String CHALLENGE_METHOD_S256 = "S256";

    private static final String WL_PUBLIC_KEY_PEM_FILENAME = "wl-publickey.pem";
    private static final String LOCATION_HEADER = "Location";

    public BaseWLConnector() {
        RestAssured.config = restAssuredConfig();
    }

    public BaseWLConnector(String proxyHost, int proxyPort) {
        this();
        RestAssured.proxy(proxyHost, proxyPort);
    }

    protected Map<String, String> extractCookies(AbstractHttpClient httpClient) {
        return httpClient.getCookieStore().getCookies().stream().collect(toMap(Cookie::getName, Cookie::getValue));
    }

    @SneakyThrows
    protected String createToken(String userId) {
        InputStream wlPublicKeyInputStream = getClass().getClassLoader().getResourceAsStream(WL_PUBLIC_KEY_PEM_FILENAME);
        RSAPublicKey wlRsaPublicKey = readPublicKey(wlPublicKeyInputStream);
        RSAKey wlPublicJWK = new RSAKey.Builder(wlRsaPublicKey).build();

        Map<String, Object> tokenParameters = new HashMap<>();
        tokenParameters.put("client_id", CLIENT_ID);
        tokenParameters.put("response_type", RESPONSE_TYPE_CODE);
        tokenParameters.put("scope", SCOPE_OPENID);
        tokenParameters.put("redirect_uri", NSANDI_ADDRESS);
        tokenParameters.put("code_challenge", PIN_CODE_CHALLENGE);
        tokenParameters.put("code_challenge_method", CHALLENGE_METHOD_S256);

        Map<String, Object> userinfo = new HashMap<>();
        userinfo.put("user_id", userId);
        userinfo.put("auth_factor", Collections.emptyList());

        Map<String, Object> jwtClaims = new HashMap<>();
        jwtClaims.put("userinfo", userinfo);

        tokenParameters.put("claims", jwtClaims);

        JWEHeader jweHeader = new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM).contentType("JWT").build();
        JWEObject jweObject = new JWEObject(jweHeader, new Payload(tokenParameters));
        jweObject.encrypt(new RSAEncrypter(wlPublicJWK));

        return jweObject.serialize().replaceAll("\\+", "-").replaceAll("=", "");
    }

    @SneakyThrows
    private RSAPublicKey readPublicKey(InputStream in) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            String key = reader.lines().collect(Collectors.joining(System.lineSeparator()));

            String publicKeyPEM = key
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replaceAll(System.lineSeparator(), "")
                    .replace("-----END PUBLIC KEY-----", "");

            byte[] encoded = Base64.getDecoder().decode(publicKeyPEM);

            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
            return (RSAPublicKey) keyFactory.generatePublic(keySpec);
        }
    }

    protected RedirectResponse followRedirect(Response post, Map<String, String> cookies) {
        int statusCode = post.getStatusCode();
        String location = post.getHeader(LOCATION_HEADER);
        Response nextRedirectResponse = null;

        while (statusCode >= 301 && statusCode <= 307) {
            log.info("Getting next redirect");
            nextRedirectResponse = given()
                    .cookies(cookies)
                    .when()
                    .log().uri()
                    .redirects().follow(false)
                    .get(location);
            statusCode = nextRedirectResponse.getStatusCode();
            location = nextRedirectResponse.getHeaders().hasHeaderWithName(LOCATION_HEADER) ? nextRedirectResponse.getHeader(LOCATION_HEADER) : location;
            log.info("Response status: {}", statusCode);
        }

        return new RedirectResponse(nextRedirectResponse, location);
    }

    protected String pickPinNumber(Response response) {
        List<String> pinInputValues = response.getBody().htmlPath().getList("'**'.findAll { it.@type == 'button'}", String.class);
        Map<Integer, Integer> pinValuesMap = IntStream.range(0, pinInputValues.size()).boxed().collect(toMap(it -> Integer.parseInt(pinInputValues.get(it)), Function.identity()));

        String pin = "" + pinValuesMap.get(2) + pinValuesMap.get(4) + pinValuesMap.get(1) + pinValuesMap.get(2) + pinValuesMap.get(9) + pinValuesMap.get(9);
        log.info("Pin: {}", pin);
        return pin;
    }

    private RestAssuredConfig restAssuredConfig() {
        return RestAssuredConfig.config().httpClient(httpClientConfig().dontReuseHttpClientInstance());
    }
}
