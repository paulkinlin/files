package nsi.steps.pt2;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

@Slf4j
public class PT2_1b_AddCustomerTaxDetailsForSpecificCustomerSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body with taxpayerIdentificationNumber {string} and taxResidenceCountryCode {string}")
    public void setRequestBodyWithIdentificationNumberCountryCode(String taxpayerIdentificationNumber, String taxResidenceCountryCode) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("addCustomerTaxDetailsForSpecificCustomer.json"));
        baseSteps.replaceBodyFieldValue("taxpayerIdentificationNumber", taxpayerIdentificationNumber);
        baseSteps.replaceBodyFieldValue("taxResidenceCountryCode", taxResidenceCountryCode);
    }
}
