package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

public class PT1_1_8_ListPendingWithdrawalSteps {

    @Inject
    private BaseSteps baseSteps;

    @Given("I want to get list of pending payments for account id {string}")
    public void listTransactionsForAccountId(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }

    @And("Response contains amount {int}, transactionDate {string}, nominatedAccountId {string}, nominatedCustomerName {string}, paymentType {string}, and status {string}")
    public void validateDetailResponse(Integer amount, String transactionDate, String nominatedAccountId,
                                       String nominatedCustomerName, String paymentType, String status) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(amount, baseSteps.response.body().path("pendingPayments[0].amount")),
                () -> assertTrue(baseSteps.response.body().path("pendingPayments[0].transactionId").toString().matches("^[A-Z0-9]{16}$")),
                () -> assertEquals(transactionDate, baseSteps.response.body().path("pendingPayments[0].transactionDate")),
                () -> assertEquals(nominatedAccountId, baseSteps.response.body().path("pendingPayments[0].nominatedAccountId")),
                () -> assertEquals(nominatedCustomerName, baseSteps.response.body().path("pendingPayments[0].nominatedCustomerName")),
                () -> assertEquals(paymentType, baseSteps.response.body().path("pendingPayments[0].paymentType")),
                () -> assertEquals(status, baseSteps.response.body().path("pendingPayments[0].status"))
        );
    }

    @And("Response is an empty pending withdrawals array")
    public void validateEmptyProxyArray() {
        ArrayList<String> pendingWithdrawalsArray = baseSteps.response.body().path("pendingPayments");
        assertTrue(pendingWithdrawalsArray.isEmpty());
    }
}