package nsi.steps.pt2;

import io.cucumber.java.en.And;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

public class PT2_12a_UpdateCustomerTaxDetailsSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body with taxType {string} and taxPayerIdentificationNumber {string}")
    public void setRequestBodyWithTaxDetails(String taxType, String taxPayerIdentificationNumber) throws IOException {
        baseSteps.replaceBodyFieldValue("taxType", taxType);
        baseSteps.replaceBodyFieldValue("taxPayerIdentificationNumber", taxPayerIdentificationNumber);
    }
}
