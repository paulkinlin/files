package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

@Slf4j
public class PT1_1_12_InitiateDepositDebitCardSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body with amountValue {amountValue} and channel {string}")
    public void setRequestBodyWithAmountValueAMOUNTAndChannel(Number amount, String channel) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("initiateDepositDebitCard.json"));
        baseSteps.replaceBodyFieldValue("channel", channel);
        baseSteps.replaceBodyFieldValue("amountValue", amount);
    }

    @Given("I want to place a deposit for account id {string}")
    public void placeDebitForAccountId(String accountId) {
        baseSteps.requestSpecification.filter((requestSpec, responseSpec, ctx) -> {
            requestSpec.pathParam("accountId", accountId);
            return ctx.next(requestSpec, responseSpec);
        });
    }
}
