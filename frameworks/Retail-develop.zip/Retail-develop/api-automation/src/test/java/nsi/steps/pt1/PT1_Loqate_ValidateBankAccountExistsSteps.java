package nsi.steps.pt1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import nsi.utils.AssertMessages;
import org.picocontainer.annotations.Inject;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j
public class PT1_Loqate_ValidateBankAccountExistsSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("Set request body with accountNumber {string} and sortCode {string}")
    public void setRequestBodyWithAmountValueAMOUNTAndChannel(String accountNumber, String sortCode) throws IOException {
        baseSteps.requestSpecification
                .body(baseSteps.getPayload("validateBankAccountExists.json"));
        baseSteps.replaceBodyFieldValue("accountNumber", accountNumber);
        baseSteps.replaceBodyFieldValue("sortCode", sortCode);
    }

    @Then("Response contain bankName {string} and branch {string}")
    public void responseContainsBankAndBranch(String bank, String branch) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(bank, baseSteps.response.body().path("bank")),
                () -> assertEquals(branch, baseSteps.response.body().path("branch"))
        );
    }

    @Then("Response contain isCorrect {booleanValue} and status information {string}")
    public void responseContainsIsCorrectAndStatusInfo(Boolean isCorrect, String statusInfo) {
        assertAll(AssertMessages.RESPONSE_VALIDATION_FAILURE.toString(),
                () -> assertEquals(isCorrect, baseSteps.response.body().path("isCorrect")),
                () -> assertEquals(statusInfo, baseSteps.response.body().path("statusInformation"))
        );
    }
}
