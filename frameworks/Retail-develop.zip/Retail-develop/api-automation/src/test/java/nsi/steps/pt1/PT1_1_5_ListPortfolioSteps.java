package nsi.steps.pt1;

import io.cucumber.java.en.And;
import lombok.extern.slf4j.Slf4j;
import nsi.steps.BaseSteps;
import org.junit.Assert;
import org.picocontainer.annotations.Inject;

@Slf4j
public class PT1_1_5_ListPortfolioSteps {

    @Inject
    private BaseSteps baseSteps;

    @And("ListPortfolio response contains account number {string}, bank product {string}, account relation {string}, authority type {string} and access type {string}")
    public void listPortfolioForAccount(String accountNumber, String bankProduct, String accountRelation, String authorityType, String accessType) {
        int accountSize = baseSteps.response.body().path("accounts.size()");
        for (int i = 0; i < accountSize; i++) {
            if (baseSteps.response.body().path("accounts[" + i + "].accountNumber").equals(accountNumber)) {
                Assert.assertEquals(bankProduct, baseSteps.response.body().path("accounts[" + i + "].bankProduct"));
                Assert.assertEquals(accountRelation, baseSteps.response.body().path("accounts[" + i + "].accountRelation"));
                if (!authorityType.equals("NULL")) {
                    Assert.assertEquals(authorityType, baseSteps.response.body().path("accounts[" + i + "].authorityType"));
                }
                Assert.assertEquals(accessType, baseSteps.response.body().path("accounts[" + i + "].accessType"));
                break;
            }
        }
    }
}