# NS&I Marketing website automation
Main goal of this set is to verify functionality of marketing website - nsandi.com
## Run mws automated tests
`mvn clean verify -Dcucumber.filter.tags="@MWS`
## Run chatbot automated tests
`mvn clean verify -Dcucumber.filter.tags="@MWS and @CHATBOT"`