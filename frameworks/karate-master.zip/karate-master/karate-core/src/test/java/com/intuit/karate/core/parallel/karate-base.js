function fn() {   
  return { functionFromKarateBase: function(){ return 'fromKarateBase'; } };
}
