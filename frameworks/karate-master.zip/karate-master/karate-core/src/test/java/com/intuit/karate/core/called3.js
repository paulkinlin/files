function fn() {
  var A = '2';
  var B = '3';
  return {
    varA: A,
    varB: B
  };
}
