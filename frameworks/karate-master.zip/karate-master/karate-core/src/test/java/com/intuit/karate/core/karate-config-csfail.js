function fn() {  
  karate.callSingle('call-single-fail-called.feature');
  return {};
}
