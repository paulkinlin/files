function fn() {
  return { 'test-id': java.lang.System.currentTimeMillis() + '' };
}
