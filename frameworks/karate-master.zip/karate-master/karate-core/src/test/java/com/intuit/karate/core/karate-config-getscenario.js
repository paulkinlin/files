function fn() {
  var config = {};
  config.data = karate.scenario;
  return config;
}
