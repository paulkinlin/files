console.log('global.js called');
