function fn() {
  return { variableFromKarateBase: functionFromKarateBase() };
}
