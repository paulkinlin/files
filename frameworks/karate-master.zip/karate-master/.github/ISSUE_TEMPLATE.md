IMPORTANT: If you have a general question please use Stack Overflow instead where Karate has a dedicated "tag": https://stackoverflow.com/questions/tagged/karate

If you are sure you have found a bug, please make sure you follow the instructions here: https://github.com/intuit/karate/wiki/How-to-Submit-an-Issue
