# Distributed Testing

Please refer to the wiki: [Distributed Testing](https://github.com/intuit/karate/wiki/Distributed-Testing).

# Docker

How to run Web-UI tests using Docker without even Java or Maven installed.

Please refer to the wiki: [Docker](https://github.com/intuit/karate/wiki/Docker).

# Gradle

This project also has a sample [`build.gradle`](build.gradle). Also see the wiki: [Gradle](https://github.com/intuit/karate/wiki/Gradle).