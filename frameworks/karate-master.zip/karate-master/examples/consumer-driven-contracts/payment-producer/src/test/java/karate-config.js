function() {
  return { paymentServiceUrl: karate.properties['payment.service.url'] }
}
