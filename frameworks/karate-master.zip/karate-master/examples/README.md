# Karate Examples

These are designed to be stand-alone Maven projects that you can use as a reference or as a starting point. Some such as [`jobserver`](jobserver) and [`gatling`](gatling) have Gradle build files as well.